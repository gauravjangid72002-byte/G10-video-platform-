/*
# Create Video Sharing Platform Schema (Multi-User with Auth)

## Overview
Creates a YouTube-like video sharing platform with channels, videos, comments, likes, and subscriptions.
Users authenticate via Supabase email/password auth. Each user gets a channel profile.

## New Tables

1. **channels** - User profiles/channels (extends auth.users)
   - id (uuid, PK, references auth.users)
   - name (text) - channel display name
   - handle (text, unique) - @handle for the channel
   - avatar_url (text) - profile picture URL
   - banner_url (text) - channel banner image
   - bio (text) - channel description
   - created_at (timestamp)

2. **videos** - Uploaded videos
   - id (uuid, PK)
   - channel_id (uuid, FK -> channels) - owner of the video
   - title (text)
   - description (text)
   - thumbnail_url (text) - thumbnail image URL
   - video_url (text) - video file URL
   - category (text) - category tag
   - views (integer, default 0) - view count
   - created_at (timestamp)

3. **comments** - Comments on videos
   - id (uuid, PK)
   - video_id (uuid, FK -> videos, cascade delete)
   - channel_id (uuid, FK -> channels) - commenter
   - text (text) - comment content
   - created_at (timestamp)

4. **video_likes** - Like tracking for videos
   - id (uuid, PK)
   - video_id (uuid, FK -> videos, cascade delete)
   - channel_id (uuid, FK -> channels) - who liked
   - created_at (timestamp)
   - UNIQUE(video_id, channel_id) - one like per video per user

5. **subscriptions** - Channel subscriptions
   - id (uuid, PK)
   - subscriber_id (uuid, FK -> channels) - who subscribes
   - channel_id (uuid, FK -> channels) - who is subscribed to
   - created_at (timestamp)
   - UNIQUE(subscriber_id, channel_id) - one subscription per pair

## Security
- All tables have RLS enabled
- Channels: anyone can view (public profiles), users can only update their own
- Videos: anyone can view (public content), only channel owner can insert/update/delete
- Comments: anyone can view, only commenter can delete, authenticated can insert
- Likes: anyone can view, authenticated can insert/delete their own
- Subscriptions: anyone can view, authenticated can insert/delete their own
- Owner columns default to auth.uid() where applicable
*/

-- Channels table (extends auth.users)
CREATE TABLE IF NOT EXISTS channels (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  handle text UNIQUE NOT NULL,
  avatar_url text,
  banner_url text,
  bio text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE channels ENABLE ROW LEVEL SECURITY;

-- Videos table
CREATE TABLE IF NOT EXISTS videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  thumbnail_url text,
  video_url text NOT NULL,
  category text DEFAULT 'General',
  views integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE videos ENABLE ROW LEVEL SECURITY;

-- Comments table
CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  text text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

-- Video likes table
CREATE TABLE IF NOT EXISTS video_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(video_id, channel_id)
);

ALTER TABLE video_likes ENABLE ROW LEVEL SECURITY;

-- Subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscriber_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(subscriber_id, channel_id)
);

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- ============ CHANNELS POLICIES ============
DROP POLICY IF EXISTS "channels_public_select" ON channels;
CREATE POLICY "channels_public_select" ON channels FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "channels_owner_insert" ON channels;
CREATE POLICY "channels_owner_insert" ON channels FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "channels_owner_update" ON channels;
CREATE POLICY "channels_owner_update" ON channels FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============ VIDEOS POLICIES ============
-- Videos are publicly viewable (anon can read)
DROP POLICY IF EXISTS "videos_public_select" ON videos;
CREATE POLICY "videos_public_select" ON videos FOR SELECT
  TO anon, authenticated USING (true);

-- Only the channel owner can insert videos
DROP POLICY IF EXISTS "videos_owner_insert" ON videos;
CREATE POLICY "videos_owner_insert" ON videos FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = channel_id);

-- Only the channel owner can update their videos
DROP POLICY IF EXISTS "videos_owner_update" ON videos;
CREATE POLICY "videos_owner_update" ON videos FOR UPDATE
  TO authenticated USING (auth.uid() = channel_id) WITH CHECK (auth.uid() = channel_id);

-- Only the channel owner can delete their videos
DROP POLICY IF EXISTS "videos_owner_delete" ON videos;
CREATE POLICY "videos_owner_delete" ON videos FOR DELETE
  TO authenticated USING (auth.uid() = channel_id);

-- ============ COMMENTS POLICIES ============
DROP POLICY IF EXISTS "comments_public_select" ON comments;
CREATE POLICY "comments_public_select" ON comments FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "comments_auth_insert" ON comments;
CREATE POLICY "comments_auth_insert" ON comments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = channel_id);

DROP POLICY IF EXISTS "comments_owner_delete" ON comments;
CREATE POLICY "comments_owner_delete" ON comments FOR DELETE
  TO authenticated USING (auth.uid() = channel_id);

-- ============ VIDEO LIKES POLICIES ============
DROP POLICY IF EXISTS "likes_public_select" ON video_likes;
CREATE POLICY "likes_public_select" ON video_likes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "likes_auth_insert" ON video_likes;
CREATE POLICY "likes_auth_insert" ON video_likes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = channel_id);

DROP POLICY IF EXISTS "likes_owner_delete" ON video_likes;
CREATE POLICY "likes_owner_delete" ON video_likes FOR DELETE
  TO authenticated USING (auth.uid() = channel_id);

-- ============ SUBSCRIPTIONS POLICIES ============
DROP POLICY IF EXISTS "subs_public_select" ON subscriptions;
CREATE POLICY "subs_public_select" ON subscriptions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "subs_auth_insert" ON subscriptions;
CREATE POLICY "subs_auth_insert" ON subscriptions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = subscriber_id);

DROP POLICY IF EXISTS "subs_owner_delete" ON subscriptions;
CREATE POLICY "subs_owner_delete" ON subscriptions FOR DELETE
  TO authenticated USING (auth.uid() = subscriber_id);

-- ============ INDEXES ============
CREATE INDEX IF NOT EXISTS idx_videos_channel_id ON videos(channel_id);
CREATE INDEX IF NOT EXISTS idx_videos_category ON videos(category);
CREATE INDEX IF NOT EXISTS idx_videos_created_at ON videos(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comments_video_id ON comments(video_id);
CREATE INDEX IF NOT EXISTS idx_likes_video_id ON video_likes(video_id);
CREATE INDEX IF NOT EXISTS idx_subs_channel_id ON subscriptions(channel_id);
CREATE INDEX IF NOT EXISTS idx_subs_subscriber_id ON subscriptions(subscriber_id);
