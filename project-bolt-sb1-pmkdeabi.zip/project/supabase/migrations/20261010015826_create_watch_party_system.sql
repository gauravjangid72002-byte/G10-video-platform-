/*
# Create Watch Party System

## Overview
Adds tables for private watch party rooms where users can watch videos together
in sync with a live chat. Uses Supabase Realtime for syncing playback state
and chat messages.

## New Table: watch_party_rooms
- id (uuid, PK)
- host_id (uuid, FK -> channels) — who created the room
- video_id (uuid, FK -> videos) — the video being watched
- room_code (text, unique) — short 6-char code for inviting friends
- playback_time (numeric, default 0) — current playback position in seconds
- is_playing (boolean, default false) — whether the video is playing
- last_sync_at (timestamptz) — when playback state was last updated
- created_at (timestamptz)

## New Table: watch_party_messages
- id (uuid, PK)
- room_id (uuid, FK -> watch_party_rooms, cascade delete)
- sender_id (uuid, FK -> channels) — who sent the message
- text (text) — message content
- created_at (timestamptz)

## Security
- watch_party_rooms: public SELECT (room code is shared), authenticated INSERT
  with ownership check, owner-only UPDATE/DELETE.
- watch_party_messages: public SELECT (chat is visible to all room members),
  authenticated INSERT with ownership check.
- Realtime enabled on both tables for live sync and chat.
*/

CREATE TABLE IF NOT EXISTS watch_party_rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  host_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  room_code text UNIQUE NOT NULL,
  playback_time numeric NOT NULL DEFAULT 0,
  is_playing boolean NOT NULL DEFAULT false,
  last_sync_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE watch_party_rooms ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "rooms_public_select" ON watch_party_rooms;
CREATE POLICY "rooms_public_select" ON watch_party_rooms FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "rooms_auth_insert" ON watch_party_rooms;
CREATE POLICY "rooms_auth_insert" ON watch_party_rooms FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = host_id);

DROP POLICY IF EXISTS "rooms_owner_update" ON watch_party_rooms;
CREATE POLICY "rooms_owner_update" ON watch_party_rooms FOR UPDATE
  TO authenticated USING (auth.uid() = host_id) WITH CHECK (auth.uid() = host_id);

DROP POLICY IF EXISTS "rooms_owner_delete" ON watch_party_rooms;
CREATE POLICY "rooms_owner_delete" ON watch_party_rooms FOR DELETE
  TO authenticated USING (auth.uid() = host_id);

CREATE TABLE IF NOT EXISTS watch_party_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES watch_party_rooms(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  text text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE watch_party_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "messages_public_select" ON watch_party_messages;
CREATE POLICY "messages_public_select" ON watch_party_messages FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "messages_auth_insert" ON watch_party_messages;
CREATE POLICY "messages_auth_insert" ON watch_party_messages FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = sender_id);

ALTER PUBLICATION supabase_realtime ADD TABLE watch_party_rooms;
ALTER PUBLICATION supabase_realtime ADD TABLE watch_party_messages;

CREATE INDEX IF NOT EXISTS idx_party_rooms_video_id ON watch_party_rooms(video_id);
CREATE INDEX IF NOT EXISTS idx_party_messages_room_id ON watch_party_messages(room_id);
