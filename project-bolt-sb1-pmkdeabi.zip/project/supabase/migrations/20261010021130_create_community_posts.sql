/*
# Create Community Posts System

## Overview
Allows creators to post text updates, images, and polls to their channel page.
Viewers can vote on polls. Posts appear in a Community tab on each channel.

## New Table: community_posts
- id (uuid, PK)
- channel_id (uuid, FK -> channels, cascade delete) — the creator who posted
- post_type (text) — 'text' | 'image' | 'poll'
- text_content (text, nullable) — the post body text
- image_url (text, nullable) — image URL for image posts
- poll_question (text, nullable) — question for poll posts
- poll_options (jsonb, nullable) — array of option strings
- created_at (timestamptz)

## New Table: community_poll_votes
- id (uuid, PK)
- post_id (uuid, FK -> community_posts, cascade delete)
- voter_id (uuid, FK -> channels) — who voted
- option_index (int) — which option they voted for
- created_at (timestamptz)
- UNIQUE(post_id, voter_id) — one vote per person per poll

## Security
- community_posts: public SELECT, authenticated INSERT with ownership check,
  owner-only UPDATE/DELETE.
- community_poll_votes: public SELECT, authenticated INSERT with ownership check
  on voter_id, voter can DELETE their own vote (to change it).
*/

CREATE TABLE IF NOT EXISTS community_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  post_type text NOT NULL DEFAULT 'text',
  text_content text,
  image_url text,
  poll_question text,
  poll_options jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE community_posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "posts_public_select" ON community_posts;
CREATE POLICY "posts_public_select" ON community_posts FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "posts_auth_insert" ON community_posts;
CREATE POLICY "posts_auth_insert" ON community_posts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = channel_id);

DROP POLICY IF EXISTS "posts_owner_update" ON community_posts;
CREATE POLICY "posts_owner_update" ON community_posts FOR UPDATE
  TO authenticated USING (auth.uid() = channel_id) WITH CHECK (auth.uid() = channel_id);

DROP POLICY IF EXISTS "posts_owner_delete" ON community_posts;
CREATE POLICY "posts_owner_delete" ON community_posts FOR DELETE
  TO authenticated USING (auth.uid() = channel_id);

CREATE TABLE IF NOT EXISTS community_poll_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
  voter_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  option_index int NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, voter_id)
);

ALTER TABLE community_poll_votes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "votes_public_select" ON community_poll_votes;
CREATE POLICY "votes_public_select" ON community_poll_votes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "votes_auth_insert" ON community_poll_votes;
CREATE POLICY "votes_auth_insert" ON community_poll_votes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = voter_id);

DROP POLICY IF EXISTS "votes_voter_delete" ON community_poll_votes;
CREATE POLICY "votes_voter_delete" ON community_poll_votes FOR DELETE
  TO authenticated USING (auth.uid() = voter_id);

CREATE INDEX IF NOT EXISTS idx_community_posts_channel_id ON community_posts(channel_id);
CREATE INDEX IF NOT EXISTS idx_community_poll_votes_post_id ON community_poll_votes(post_id);
