/*
# Create Copyright Management System

## Overview
Implements a full copyright management system with:
1. Content ID / duplicate video detection — stores content match records
   flagged during upload for review.
2. Copyright claims — creators can file claims against videos, and video owners
   can submit counter-notifications.
3. 3-Strike policy — channels accumulate strikes from resolved claims; after
   3 strikes a channel is flagged as restricted.

## New Table: content_matches
- id (uuid, PK)
- video_id (uuid, FK -> videos, cascade delete) — the uploaded video being checked
- match_video_id (uuid, FK -> videos, cascade delete) — the potentially matched existing video
- match_score (numeric, 0-100) — similarity score
- status (text) — 'pending' | 'confirmed' | 'dismissed' | 'resolved'
- created_at (timestamptz)

## New Table: copyright_claims
- id (uuid, PK)
- video_id (uuid, FK -> videos, cascade delete) — the video being claimed against
- claimant_id (uuid, FK -> channels) — who filed the claim
- reason (text) — description of the copyright issue
- claim_type (text) — 'duplicate' | 'content_id' | 'manual'
- status (text) — 'pending' | 'approved' | 'rejected' | 'counter_notified' | 'resolved'
- counter_text (text, nullable) — counter-notification text from video owner
- counter_submitted_at (timestamptz, nullable)
- resolved_at (timestamptz, nullable)
- created_at (timestamptz)

## New Table: copyright_strikes
- id (uuid, PK)
- channel_id (uuid, FK -> channels, cascade delete) — the channel that received the strike
- claim_id (uuid, FK -> copyright_claims, cascade delete) — the claim that caused the strike
- reason (text) — why the strike was issued
- status (text) — 'active' | 'expired' | 'appealed'
- created_at (timestamptz)

## Changes to channels table
- strike_count (int, default 0) — running count of active strikes
- is_restricted (boolean, default false) — true when 3+ strikes accumulated

## Security
- content_matches: public SELECT, authenticated INSERT, owner-of-checked-video UPDATE.
- copyright_claims: public SELECT, authenticated INSERT with ownership check on
  claimant_id, video owner can UPDATE (for counter-notification).
- copyright_strikes: public SELECT, authenticated INSERT (auto from resolved claims).
- channels: existing policies cover the new columns.
*/

ALTER TABLE channels ADD COLUMN IF NOT EXISTS strike_count int NOT NULL DEFAULT 0;
ALTER TABLE channels ADD COLUMN IF NOT EXISTS is_restricted boolean NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS content_matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  match_video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  match_score numeric(5,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE content_matches ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "matches_public_select" ON content_matches;
CREATE POLICY "matches_public_select" ON content_matches FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "matches_auth_insert" ON content_matches;
CREATE POLICY "matches_auth_insert" ON content_matches FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "matches_auth_update" ON content_matches;
CREATE POLICY "matches_auth_update" ON content_matches FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS copyright_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  claimant_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  reason text NOT NULL DEFAULT '',
  claim_type text NOT NULL DEFAULT 'manual',
  status text NOT NULL DEFAULT 'pending',
  counter_text text,
  counter_submitted_at timestamptz,
  resolved_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE copyright_claims ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "claims_public_select" ON copyright_claims;
CREATE POLICY "claims_public_select" ON copyright_claims FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "claims_auth_insert" ON copyright_claims;
CREATE POLICY "claims_auth_insert" ON copyright_claims FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = claimant_id);

DROP POLICY IF EXISTS "claims_auth_update" ON copyright_claims;
CREATE POLICY "claims_auth_update" ON copyright_claims FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS copyright_strikes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  claim_id uuid NOT NULL REFERENCES copyright_claims(id) ON DELETE CASCADE,
  reason text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE copyright_strikes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "strikes_public_select" ON copyright_strikes;
CREATE POLICY "strikes_public_select" ON copyright_strikes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "strikes_auth_insert" ON copyright_strikes;
CREATE POLICY "strikes_auth_insert" ON copyright_strikes FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "strikes_auth_update" ON copyright_strikes;
CREATE POLICY "strikes_auth_update" ON copyright_strikes FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_content_matches_video_id ON content_matches(video_id);
CREATE INDEX IF NOT EXISTS idx_claims_video_id ON copyright_claims(video_id);
CREATE INDEX IF NOT EXISTS idx_claims_claimant_id ON copyright_claims(claimant_id);
CREATE INDEX IF NOT EXISTS idx_strikes_channel_id ON copyright_strikes(channel_id);
