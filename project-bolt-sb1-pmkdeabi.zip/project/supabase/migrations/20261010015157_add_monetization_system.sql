/*
# Add Creator Monetization System (Simulated)

## Overview
Adds pay-per-view (PPV) support to videos, a tips table for Super Thanks-style
tipping, and a purchases table tracking which viewers have unlocked PPV content.
All payment is simulated — no real charges are processed.

## Changes to videos table
- is_ppv (boolean, default false) — whether the video is locked behind pay-per-view
- ppv_price (numeric, default 0) — price in USD to unlock the video
- tip_total (numeric, default 0) — running total of all tips received (denormalized for display)

## New Table: tips
- id (uuid, PK)
- video_id (uuid, FK -> videos, cascade delete)
- tipper_id (uuid, FK -> channels, cascade delete) — who sent the tip
- amount (numeric) — tip amount in USD
- message (text) — optional message attached to the tip
- created_at (timestamptz)

## New Table: ppv_purchases
- id (uuid, PK)
- video_id (uuid, FK -> videos, cascade delete)
- buyer_id (uuid, FK -> channels, cascade delete) — who purchased access
- price_paid (numeric) — amount paid at time of purchase
- created_at (timestamptz)
- UNIQUE(video_id, buyer_id) — one purchase per video per user

## Security
- videos: existing public SELECT policy covers new columns; owner INSERT/UPDATE
  policies cover the new columns (only channel owner can set PPV status/price).
- tips: public SELECT (tips are visible to all), authenticated INSERT.
- ppv_purchases: public SELECT (so viewers can check if they've unlocked),
  authenticated INSERT with ownership check (buyer_id = auth.uid()).
*/

-- Add monetization columns to videos
ALTER TABLE videos ADD COLUMN IF NOT EXISTS is_ppv boolean NOT NULL DEFAULT false;
ALTER TABLE videos ADD COLUMN IF NOT EXISTS ppv_price numeric(10,2) NOT NULL DEFAULT 0;
ALTER TABLE videos ADD COLUMN IF NOT EXISTS tip_total numeric(10,2) NOT NULL DEFAULT 0;

-- Tips table
CREATE TABLE IF NOT EXISTS tips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  tipper_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  amount numeric(10,2) NOT NULL,
  message text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE tips ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "tips_public_select" ON tips;
CREATE POLICY "tips_public_select" ON tips FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "tips_auth_insert" ON tips;
CREATE POLICY "tips_auth_insert" ON tips FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = tipper_id);

-- PPV purchases table
CREATE TABLE IF NOT EXISTS ppv_purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  buyer_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  price_paid numeric(10,2) NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(video_id, buyer_id)
);

ALTER TABLE ppv_purchases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "purchases_public_select" ON ppv_purchases;
CREATE POLICY "purchases_public_select" ON ppv_purchases FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "purchases_auth_insert" ON ppv_purchases;
CREATE POLICY "purchases_auth_insert" ON ppv_purchases FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = buyer_id);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_tips_video_id ON tips(video_id);
CREATE INDEX IF NOT EXISTS idx_ppv_purchases_video_id ON ppv_purchases(video_id);
CREATE INDEX IF NOT EXISTS idx_ppv_purchases_buyer_id ON ppv_purchases(buyer_id);
