/*
# Increment View Count Function

Creates a SECURITY DEFINER function to safely increment a video's view count.
This bypasses RLS so anon users (browsing without login) can increment views.
The function only increments, never reads sensitive data.
*/

CREATE OR REPLACE FUNCTION increment_video_views(video_uuid uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE videos SET views = views + 1 WHERE id = video_uuid;
END;
$$;

GRANT EXECUTE ON FUNCTION increment_video_views(uuid) TO anon, authenticated;
