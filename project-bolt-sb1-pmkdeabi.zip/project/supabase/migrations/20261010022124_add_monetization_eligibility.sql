/*
# Add Monetization Eligibility Columns

## Overview
Adds watch_time_seconds and monetization_status columns to channels
to support the Creator Dashboard's monetization eligibility tracking.

## Changes to channels table
- watch_time_seconds (bigint, default 0) — total watch time across all videos
- monetization_status (text, default 'not_applied') — not_applied | pending | approved | rejected

## Security
No new RLS policies needed — columns are read via existing channel SELECT,
and updated via a SECURITY DEFINER function callable only by the channel owner.
*/

ALTER TABLE channels ADD COLUMN IF NOT EXISTS watch_time_seconds bigint NOT NULL DEFAULT 0;
ALTER TABLE channels ADD COLUMN IF NOT EXISTS monetization_status text NOT NULL DEFAULT 'not_applied';

-- Function for a channel owner to apply for monetization
CREATE OR REPLACE FUNCTION apply_for_monetization(target_channel_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only the channel owner can apply
  IF auth.uid() != target_channel_id THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  -- Check eligibility: minimum 20 subscribers and 3600 seconds (1 hour) watch time
  IF NOT EXISTS (
    SELECT 1 FROM channels
    WHERE id = target_channel_id
      AND subscriber_count >= 20
      AND watch_time_seconds >= 3600
  ) THEN
    RAISE EXCEPTION 'Eligibility requirements not met';
  END IF;

  UPDATE channels
  SET monetization_status = 'pending'
  WHERE id = target_channel_id AND monetization_status = 'not_applied';
END;
$$;

GRANT EXECUTE ON FUNCTION apply_for_monetization(uuid) TO authenticated;
