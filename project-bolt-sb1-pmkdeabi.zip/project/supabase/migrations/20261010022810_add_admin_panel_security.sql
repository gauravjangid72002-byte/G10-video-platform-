/*
# Admin Control Panel & Security Infrastructure

## Overview
Adds admin role column, monetization criteria table (dynamically editable),
rate limiting table, and SECURITY DEFINER functions for admin operations.
All privileged mutations go through functions that verify the caller is an admin.

## Changes to channels table
- role (text, default 'user') — 'user' | 'admin'
- is_blocked (boolean, default false) — blocked users can't perform actions
- blocked_reason (text, nullable)

## New Table: monetization_criteria
- id (uuid, PK)
- min_subscribers (int, default 20)
- min_watch_time_seconds (bigint, default 3600)
- updated_at (timestamptz)
- updated_by (uuid, nullable)
Singleton row (only one row with id = fixed UUID).

## New Table: rate_limit_log
- id (uuid, PK)
- identifier (text) — email or IP
- action (text) — 'login', 'api', etc.
- created_at (timestamptz)

## Security
- channels.role: column-level privilege — users CANNOT update their own role.
  Only the admin SECURITY DEFINER functions can set it.
- channels.is_blocked, blocked_reason: same protection.
- monetization_criteria: public SELECT, admin-only INSERT/UPDATE via function.
- rate_limit_log: only accessible via SECURITY DEFINER function (check_rate_limit).
- All admin actions go through SECURITY DEFINER functions that verify
  auth.uid() has role='admin'.
*/

-- Add role and blocking columns to channels
ALTER TABLE channels ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'user';
ALTER TABLE channels ADD COLUMN IF NOT EXISTS is_blocked boolean NOT NULL DEFAULT false;
ALTER TABLE channels ADD COLUMN IF NOT EXISTS blocked_reason text;

-- Column-level privileges: users canNOT update role, is_blocked, blocked_reason
REVOKE UPDATE ON channels FROM authenticated;
GRANT UPDATE (name, handle, avatar_url, banner_url, bio) ON channels TO authenticated;

-- Monetization criteria table (singleton)
CREATE TABLE IF NOT EXISTS monetization_criteria (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  min_subscribers int NOT NULL DEFAULT 20,
  min_watch_time_seconds bigint NOT NULL DEFAULT 3600,
  updated_at timestamptz DEFAULT now(),
  updated_by uuid REFERENCES channels(id) ON DELETE SET NULL
);

ALTER TABLE monetization_criteria ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "criteria_public_select" ON monetization_criteria;
CREATE POLICY "criteria_public_select" ON monetization_criteria FOR SELECT
  TO anon, authenticated USING (true);

-- Insert default singleton row
INSERT INTO monetization_criteria (id, min_subscribers, min_watch_time_seconds)
VALUES ('00000000-0000-0000-0000-000000000001', 20, 3600)
ON CONFLICT (id) DO NOTHING;

-- Rate limit log table
CREATE TABLE IF NOT EXISTS rate_limit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  identifier text NOT NULL,
  action text NOT NULL DEFAULT 'login',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE rate_limit_log ENABLE ROW LEVEL SECURITY;
-- No policies: only accessible via SECURITY DEFINER functions

CREATE INDEX IF NOT EXISTS idx_rate_limit_identifier_action_time
  ON rate_limit_log(identifier, action, created_at);

-- ============================================================
-- SECURITY DEFINER FUNCTIONS
-- ============================================================

-- Check if current user is admin
CREATE OR REPLACE FUNCTION is_current_user_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM channels
    WHERE id = auth.uid() AND role = 'admin' AND is_blocked = false
  );
$$;

GRANT EXECUTE ON FUNCTION is_current_user_admin() TO authenticated;

-- Check if current user is blocked
CREATE OR REPLACE FUNCTION is_current_user_blocked()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM channels
    WHERE id = auth.uid() AND is_blocked = true
  );
$$;

GRANT EXECUTE ON FUNCTION is_current_user_blocked() TO authenticated;

-- Get current monetization criteria
CREATE OR REPLACE FUNCTION get_monetization_criteria()
RETURNS TABLE (min_subscribers int, min_watch_time_seconds bigint)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT min_subscribers, min_watch_time_seconds
  FROM monetization_criteria
  LIMIT 1;
$$;

GRANT EXECUTE ON FUNCTION get_monetization_criteria() TO authenticated, anon;

-- Update monetization criteria (admin only)
CREATE OR REPLACE FUNCTION update_monetization_criteria(
  p_min_subscribers int,
  p_min_watch_time_seconds bigint
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM channels
    WHERE id = auth.uid() AND role = 'admin' AND is_blocked = false
  ) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  IF p_min_subscribers IS NULL OR p_min_subscribers < 0 OR p_min_subscribers > 1000000 THEN
    RAISE EXCEPTION 'Invalid subscriber minimum';
  END IF;

  IF p_min_watch_time_seconds IS NULL OR p_min_watch_time_seconds < 0 OR p_min_watch_time_seconds > 999999999 THEN
    RAISE EXCEPTION 'Invalid watch time minimum';
  END IF;

  UPDATE monetization_criteria
  SET min_subscribers = p_min_subscribers,
      min_watch_time_seconds = p_min_watch_time_seconds,
      updated_at = now(),
      updated_by = auth.uid()
  WHERE id = '00000000-0000-0000-0000-000000000001';
END;
$$;

REVOKE EXECUTE ON FUNCTION update_monetization_criteria FROM anon;
GRANT EXECUTE ON FUNCTION update_monetization_criteria TO authenticated;

-- Approve monetization application (admin only)
CREATE OR REPLACE FUNCTION admin_approve_monetization(target_channel_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM channels
    WHERE id = auth.uid() AND role = 'admin' AND is_blocked = false
  ) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  UPDATE channels
  SET monetization_status = 'approved'
  WHERE id = target_channel_id AND monetization_status = 'pending';
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_approve_monetization FROM anon;
GRANT EXECUTE ON FUNCTION admin_approve_monetization TO authenticated;

-- Reject monetization application (admin only)
CREATE OR REPLACE FUNCTION admin_reject_monetization(target_channel_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM channels
    WHERE id = auth.uid() AND role = 'admin' AND is_blocked = false
  ) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  UPDATE channels
  SET monetization_status = 'rejected'
  WHERE id = target_channel_id AND monetization_status = 'pending';
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_reject_monetization FROM anon;
GRANT EXECUTE ON FUNCTION admin_reject_monetization TO authenticated;

-- Block a user (admin only)
CREATE OR REPLACE FUNCTION admin_block_channel(
  target_channel_id uuid,
  p_reason text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM channels
    WHERE id = auth.uid() AND role = 'admin' AND is_blocked = false
  ) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  -- Cannot block another admin
  IF EXISTS (
    SELECT 1 FROM channels
    WHERE id = target_channel_id AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Cannot block an admin';
  END IF;

  UPDATE channels
  SET is_blocked = true, blocked_reason = LEFT(p_reason, 500)
  WHERE id = target_channel_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_block_channel FROM anon;
GRANT EXECUTE ON FUNCTION admin_block_channel TO authenticated;

-- Unblock a user (admin only)
CREATE OR REPLACE FUNCTION admin_unblock_channel(target_channel_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM channels
    WHERE id = auth.uid() AND role = 'admin' AND is_blocked = false
  ) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  UPDATE channels
  SET is_blocked = false, blocked_reason = NULL
  WHERE id = target_channel_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_unblock_channel FROM anon;
GRANT EXECUTE ON FUNCTION admin_unblock_channel TO authenticated;

-- Set channel role (admin only)
CREATE OR REPLACE FUNCTION admin_set_channel_role(
  target_channel_id uuid,
  p_role text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM channels
    WHERE id = auth.uid() AND role = 'admin' AND is_blocked = false
  ) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  IF p_role NOT IN ('user', 'admin') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;

  UPDATE channels SET role = p_role WHERE id = target_channel_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_set_channel_role FROM anon;
GRANT EXECUTE ON FUNCTION admin_set_channel_role TO authenticated;

-- Check rate limit (internal helper)
-- Returns true if under limit, false if rate limited
CREATE OR REPLACE FUNCTION check_rate_limit(
  p_identifier text,
  p_action text,
  p_max_count int,
  p_window_seconds int
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count int;
BEGIN
  SELECT COUNT(*) INTO v_count
  FROM rate_limit_log
  WHERE identifier = p_identifier
    AND action = p_action
    AND created_at > now() - (p_window_seconds || ' seconds')::interval;

  IF v_count >= p_max_count THEN
    RETURN false;
  END IF;

  INSERT INTO rate_limit_log (identifier, action)
  VALUES (p_identifier, p_action);

  RETURN true;
END;
$$;

REVOKE EXECUTE ON FUNCTION check_rate_limit FROM anon;
GRANT EXECUTE ON FUNCTION check_rate_limit TO authenticated;

-- Allow admins to read all channels (for admin panel)
-- We add a policy so admins can SELECT all channels
DROP POLICY IF EXISTS "channels_admin_select_all" ON channels;
CREATE POLICY "channels_admin_select_all" ON channels FOR SELECT
  TO authenticated USING (
    auth.uid() = id
    OR EXISTS (
      SELECT 1 FROM channels c
      WHERE c.id = auth.uid() AND c.role = 'admin'
    )
  );
