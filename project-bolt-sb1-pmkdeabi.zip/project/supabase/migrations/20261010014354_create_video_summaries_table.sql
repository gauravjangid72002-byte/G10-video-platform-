/*
# Create Video Summaries Table

## Purpose
Stores AI-generated summaries and auto-chapters for videos so they can be
cached and reused without regenerating on every view.

## New Table: video_summaries
- id (uuid, PK)
- video_id (uuid, FK -> videos, unique, cascade delete) — one summary per video
- summary (text) — short AI-generated paragraph summarizing key points
- chapters (jsonb) — array of { title, start_time, description } objects
- key_points (jsonb) — array of string bullet points
- created_at (timestamptz)

## Security
- RLS enabled.
- Public read (anon + authenticated) since videos are public content.
- Only authenticated users can insert (the edge function uses service role,
  but we keep the policy permissive for the authenticated role).
*/
CREATE TABLE IF NOT EXISTS video_summaries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid NOT NULL UNIQUE REFERENCES videos(id) ON DELETE CASCADE,
  summary text NOT NULL DEFAULT '',
  chapters jsonb NOT NULL DEFAULT '[]'::jsonb,
  key_points jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE video_summaries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "summaries_public_select" ON video_summaries;
CREATE POLICY "summaries_public_select" ON video_summaries FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "summaries_auth_insert" ON video_summaries;
CREATE POLICY "summaries_auth_insert" ON video_summaries FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "summaries_auth_update" ON video_summaries;
CREATE POLICY "summaries_auth_update" ON video_summaries FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);
