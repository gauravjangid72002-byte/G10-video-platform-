/*
# Create Creator Analytics System

## Overview
Adds a daily analytics table for tracking per-channel metrics over time,
plus earnings-related columns on the channels table. This powers the
Creator Dashboard with historical charts and real-time statistics.

## New Table: daily_analytics
- id (uuid, PK)
- channel_id (uuid, FK -> channels, cascade delete)
- date (date) — the day this snapshot covers
- total_views (bigint) — cumulative views at end of day
- total_subscribers (int) — cumulative subscribers at end of day
- total_earnings (numeric) — cumulative earnings at end of day
- new_views (int) — views gained that day
- new_subscribers (int) — subscribers gained that day
- new_earnings (numeric) — earnings gained that day
- video_count (int) — total videos at end of day
- created_at (timestamptz)

## Changes to channels table
- total_earnings (numeric, default 0) — lifetime earnings
- available_balance (numeric, default 0) — withdrawable balance
- lifetime_views (bigint, default 0) — convenience column for quick reads

## Security
- daily_analytics: channel owner can SELECT/INSERT/UPDATE their own rows.
*/

ALTER TABLE channels ADD COLUMN IF NOT EXISTS total_earnings numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE channels ADD COLUMN IF NOT EXISTS available_balance numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE channels ADD COLUMN IF NOT EXISTS lifetime_views bigint NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS daily_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  total_views bigint NOT NULL DEFAULT 0,
  total_subscribers int NOT NULL DEFAULT 0,
  total_earnings numeric(12,2) NOT NULL DEFAULT 0,
  new_views int NOT NULL DEFAULT 0,
  new_subscribers int NOT NULL DEFAULT 0,
  new_earnings numeric(12,2) NOT NULL DEFAULT 0,
  video_count int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE(channel_id, date)
);

ALTER TABLE daily_analytics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "analytics_owner_select" ON daily_analytics;
CREATE POLICY "analytics_owner_select" ON daily_analytics FOR SELECT
  TO authenticated USING (auth.uid() = channel_id);

DROP POLICY IF EXISTS "analytics_owner_insert" ON daily_analytics;
CREATE POLICY "analytics_owner_insert" ON daily_analytics FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = channel_id);

DROP POLICY IF EXISTS "analytics_owner_update" ON daily_analytics;
CREATE POLICY "analytics_owner_update" ON daily_analytics FOR UPDATE
  TO authenticated USING (auth.uid() = channel_id) WITH CHECK (auth.uid() = channel_id);

CREATE INDEX IF NOT EXISTS idx_daily_analytics_channel_date ON daily_analytics(channel_id, date);
