/*
# Add Shorts Support

## Overview
Adds an is_short boolean column to the videos table so short-form vertical
videos can be filtered into a dedicated Shorts feed. Shorts use the same
videos table — they're just flagged differently and displayed in a vertical
scrolling format.

## Changes to videos table
- is_short (boolean, default false) — whether this video is a Short

## Security
- The existing public SELECT policy already covers the new column.
- The existing authenticated INSERT policy already covers it (owner check
  on channel_id remains unchanged).
*/

ALTER TABLE videos ADD COLUMN IF NOT EXISTS is_short boolean NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS idx_videos_is_short ON videos(is_short);
