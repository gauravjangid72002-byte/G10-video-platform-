/*
# Create Increment Tip Total Function

Creates a SECURITY DEFINER function to safely add a tip amount to a video's
running tip_total column. This bypasses RLS so the tip insert + total update
can happen in sequence without exposing update permissions to all users.
*/

CREATE OR REPLACE FUNCTION increment_tip_total(video_uuid uuid, tip_amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE videos SET tip_total = tip_total + tip_amount WHERE id = video_uuid;
END;
$$;

GRANT EXECUTE ON FUNCTION increment_tip_total(uuid, numeric) TO authenticated;
