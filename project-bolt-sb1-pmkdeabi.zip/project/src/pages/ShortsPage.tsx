import { useState, useEffect, useRef, useCallback } from 'react';
import { Heart, MessageCircle, Share2, Zap, Plus, Music, Volume2, VolumeX, Play } from 'lucide-react';
import { supabase, type Video, type Channel } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { ClipCreator } from '@/components/ClipCreator';
import { formatViews, formatTimeAgo, formatNumber } from '@/lib/format';

export function ShortsPage() {
  const { channel, session } = useAuth();
  const { navigate } = useRouter();
  const [shorts, setShorts] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);
  const [muted, setMuted] = useState(true);
  const [showCreator, setShowCreator] = useState(false);
  const [likedShorts, setLikedShorts] = useState<Set<string>>(new Set());
  const [likeCounts, setLikeCounts] = useState<Record<string, number>>({});
  const [subscribed, setSubscribed] = useState<Record<string, boolean>>({});

  const containerRef = useRef<HTMLDivElement>(null);
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);

  useEffect(() => {
    async function fetchShorts() {
      const { data, error } = await supabase
        .from('videos')
        .select('*, channel:channels(*)')
        .eq('is_short', true)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error || !data) {
        setLoading(false);
        return;
      }

      const shortsData = data as Video[];
      setShorts(shortsData);

      // Fetch like counts for all shorts
      const counts: Record<string, number> = {};
      await Promise.all(
        shortsData.map(async (v) => {
          const { count } = await supabase
            .from('video_likes')
            .select('*', { count: 'exact', head: true })
            .eq('video_id', v.id);
          counts[v.id] = count ?? 0;
        })
      );
      setLikeCounts(counts);

      // Check liked status
      if (channel) {
        const liked = new Set<string>();
        const subs: Record<string, boolean> = {};
        await Promise.all(
          shortsData.map(async (v) => {
            const { data: existingLike } = await supabase
              .from('video_likes')
              .select('id')
              .eq('video_id', v.id)
              .eq('channel_id', channel.id)
              .maybeSingle();
            if (existingLike) liked.add(v.id);

            if (v.channel_id !== channel.id) {
              const { data: existingSub } = await supabase
                .from('subscriptions')
                .select('id')
                .eq('subscriber_id', channel.id)
                .eq('channel_id', v.channel_id)
                .maybeSingle();
              subs[v.channel_id] = !!existingSub;
            }
          })
        );
        setLikedShorts(liked);
        setSubscribed(subs);
      }

      setLoading(false);
    }
    fetchShorts();
  }, [channel]);

  // Intersection observer to detect active video
  useEffect(() => {
    if (!containerRef.current || shorts.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const index = Number((entry.target as HTMLElement).dataset.index);
          if (entry.isIntersecting && entry.intersectionRatio > 0.6) {
            setActiveIndex(index);
            // Play active video, pause others
            videoRefs.current.forEach((v, i) => {
              if (!v) return;
              if (i === index) {
                v.play().catch(() => {});
              } else {
                v.pause();
              }
            });
          }
        });
      },
      { threshold: [0.6] }
    );

    const items = containerRef.current.querySelectorAll('[data-index]');
    items.forEach((item) => observer.observe(item));

    return () => observer.disconnect();
  }, [shorts]);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const newMuted = !m;
      videoRefs.current.forEach((v) => {
        if (v) v.muted = newMuted;
      });
      return newMuted;
    });
  }, []);

  async function toggleLike(videoId: string) {
    if (!channel) return;
    const isLiked = likedShorts.has(videoId);
    if (isLiked) {
      await supabase.from('video_likes').delete().eq('video_id', videoId).eq('channel_id', channel.id);
      setLikedShorts((prev) => {
        const next = new Set(prev);
        next.delete(videoId);
        return next;
      });
      setLikeCounts((prev) => ({ ...prev, [videoId]: (prev[videoId] ?? 1) - 1 }));
    } else {
      await supabase.from('video_likes').insert({ video_id: videoId, channel_id: channel.id });
      setLikedShorts((prev) => new Set(prev).add(videoId));
      setLikeCounts((prev) => ({ ...prev, [videoId]: (prev[videoId] ?? 0) + 1 }));
    }
  }

  async function toggleSubscribe(channelId: string) {
    if (!channel) return;
    const isSubbed = subscribed[channelId];
    if (isSubbed) {
      await supabase.from('subscriptions').delete().eq('subscriber_id', channel.id).eq('channel_id', channelId);
      setSubscribed((prev) => ({ ...prev, [channelId]: false }));
    } else {
      await supabase.from('subscriptions').insert({ subscriber_id: channel.id, channel_id: channelId });
      setSubscribed((prev) => ({ ...prev, [channelId]: true }));
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-56px)]">
        <div className="w-10 h-10 border-4 border-white/20 border-t-red-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (shorts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-56px)] px-6 text-center">
        <div className="w-20 h-20 bg-red-600/20 rounded-2xl flex items-center justify-center mb-4">
          <Zap className="w-10 h-10 text-red-400" />
        </div>
        <h2 className="text-white text-xl font-bold mb-2">No Shorts yet</h2>
        <p className="text-gray-400 text-sm mb-6 max-w-xs">
          Be the first to create a Short! Record from your camera or upload a vertical video.
        </p>
        {session ? (
          <button
            onClick={() => setShowCreator(true)}
            className="flex items-center gap-2 px-6 py-3 rounded-full bg-red-600 text-white text-sm font-bold hover:bg-red-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Create a Short
          </button>
        ) : (
          <button
            onClick={() => navigate({ name: 'signin' })}
            className="flex items-center gap-2 px-6 py-3 rounded-full bg-red-600 text-white text-sm font-bold hover:bg-red-700 transition-colors"
          >
            Sign in to create
          </button>
        )}
        {showCreator && <ClipCreator onClose={() => setShowCreator(false)} />}
      </div>
    );
  }

  return (
    <>
      <div
        ref={containerRef}
        className="h-[calc(100vh-56px)] overflow-y-scroll snap-y snap-mandatory scrollbar-thin bg-black"
      >
        {shorts.map((short, index) => {
          const isActive = index === activeIndex;
          const isLiked = likedShorts.has(short.id);
          const likeCount = likeCounts[short.id] ?? 0;
          const ch = short.channel as Channel | undefined;
          const isOwn = channel?.id === short.channel_id;
          const isSubbed = subscribed[short.channel_id];

          return (
            <div
              key={short.id}
              data-index={index}
              className="snap-start h-full w-full flex items-center justify-center relative"
            >
              {/* Video */}
              <div className="relative h-full w-full max-w-[450px] flex items-center justify-center">
                <video
                  ref={(el) => { videoRefs.current[index] = el; }}
                  src={short.video_url}
                  loop
                  muted={muted}
                  playsInline
                  autoPlay={isActive}
                  className="h-full w-full object-cover"
                  poster={short.thumbnail_url ?? undefined}
                  onClick={() => {
                    const v = videoRefs.current[index];
                    if (v) {
                      if (v.paused) v.play();
                      else v.pause();
                    }
                  }}
                />

                {/* Gradient overlays for readability */}
                <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60 pointer-events-none" />

                {/* Mute toggle (top right) */}
                <button
                  onClick={toggleMute}
                  className="absolute top-4 right-4 p-2.5 bg-black/50 backdrop-blur-sm rounded-full hover:bg-black/70 transition-colors"
                >
                  {muted ? <VolumeX className="w-5 h-5 text-white" /> : <Volume2 className="w-5 h-5 text-white" />}
                </button>

                {/* Create button (top left) */}
                <button
                  onClick={() => setShowCreator(true)}
                  className="absolute top-4 left-4 flex items-center gap-1.5 px-3 py-2 bg-black/50 backdrop-blur-sm rounded-full hover:bg-black/70 transition-colors"
                >
                  <Plus className="w-4 h-4 text-white" />
                  <span className="text-white text-xs font-medium">New</span>
                </button>

                {/* Right action bar */}
                <div className="absolute right-3 bottom-24 flex flex-col items-center gap-5">
                  {/* Like */}
                  <button
                    onClick={() => toggleLike(short.id)}
                    disabled={!session}
                    className="flex flex-col items-center gap-1 group"
                  >
                    <div className="w-12 h-12 bg-black/40 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:bg-black/60 transition-colors">
                      <Heart
                        className={`w-6 h-6 transition-transform group-active:scale-90 ${
                          isLiked ? 'fill-red-500 text-red-500' : 'text-white'
                        }`}
                      />
                    </div>
                    <span className="text-white text-xs font-medium">{formatNumber(likeCount)}</span>
                  </button>

                  {/* Comment */}
                  <button
                    onClick={() => navigate({ name: 'watch', videoId: short.id })}
                    className="flex flex-col items-center gap-1 group"
                  >
                    <div className="w-12 h-12 bg-black/40 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:bg-black/60 transition-colors">
                      <MessageCircle className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-white text-xs font-medium">Comments</span>
                  </button>

                  {/* Share */}
                  <button
                    onClick={() => navigate({ name: 'watch', videoId: short.id })}
                    className="flex flex-col items-center gap-1 group"
                  >
                    <div className="w-12 h-12 bg-black/40 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:bg-black/60 transition-colors">
                      <Share2 className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-white text-xs font-medium">Share</span>
                  </button>
                </div>

                {/* Bottom info */}
                <div className="absolute bottom-0 left-0 right-16 p-4 space-y-3">
                  {/* Channel info */}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => navigate({ name: 'channel', channelId: short.channel_id })}
                      className="w-10 h-10 rounded-full overflow-hidden bg-white/10 flex-shrink-0 border-2 border-white/30"
                    >
                      {ch?.avatar_url && (
                        <img src={ch.avatar_url} alt="" className="w-full h-full object-cover" />
                      )}
                    </button>
                    <button
                      onClick={() => navigate({ name: 'channel', channelId: short.channel_id })}
                      className="text-white text-sm font-bold hover:opacity-80"
                    >
                      {ch?.name}
                    </button>
                    {!isOwn && (
                      <button
                        onClick={() => toggleSubscribe(short.channel_id)}
                        disabled={!session}
                        className={`px-3 py-1.5 rounded-full text-xs font-bold transition-colors ${
                          isSubbed
                            ? 'bg-white/20 text-white hover:bg-white/30'
                            : 'bg-red-600 text-white hover:bg-red-700'
                        } ${!session ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        {isSubbed ? 'Subscribed' : 'Subscribe'}
                      </button>
                    )}
                  </div>

                  {/* Title */}
                  <p className="text-white text-sm font-medium line-clamp-2">{short.title}</p>

                  {/* Meta */}
                  <div className="flex items-center gap-3 text-xs text-gray-300">
                    <span>{formatViews(short.views)} views</span>
                    <span>{formatTimeAgo(short.created_at)}</span>
                  </div>

                  {/* Music tag */}
                  <div className="flex items-center gap-2 text-white/80 text-xs">
                    <Music className="w-3.5 h-3.5" />
                    <span className="truncate">Original audio — {ch?.name}</span>
                  </div>
                </div>

                {/* Paused overlay */}
                {isActive && videoRefs.current[index]?.paused && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-16 h-16 bg-black/40 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <Play className="w-8 h-8 text-white fill-white ml-1" />
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {showCreator && <ClipCreator onClose={() => setShowCreator(false)} />}
    </>
  );
}
