import { useState, useEffect } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  FileText,
  Gavel,
  Check,
  X,
  Loader2,
  ArrowLeft,
  MessageSquareReply,
  TrendingUp,
  Clock,
} from 'lucide-react';
import {
  supabase,
  type Video,
  type CopyrightClaim,
  type CopyrightStrike,
  type Channel,
} from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { formatTimeAgo } from '@/lib/format';

type Tab = 'overview' | 'claims' | 'strikes';

export function CopyrightDashboard() {
  const { channel, session } = useAuth();
  const { navigate } = useRouter();
  const [tab, setTab] = useState<Tab>('overview');
  const [claims, setClaims] = useState<CopyrightClaim[]>([]);
  const [strikes, setStrikes] = useState<CopyrightStrike[]>([]);
  const [loading, setLoading] = useState(true);
  const [counterText, setCounterText] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState<string | null>(null);

  useEffect(() => {
    if (!channel) {
      setLoading(false);
      return;
    }
    loadData();
  }, [channel]);

  async function loadData() {
    if (!channel) return;
    setLoading(true);

    // Fetch claims where this channel is the claimant or the video owner
    const { data: claimsData } = await supabase
      .from('copyright_claims')
      .select('*, video:videos(*), claimant:channels!copyright_claims_claimant_id_fkey(*)')
      .or(`claimant_id.eq.${channel.id},video_id.in.(select id from videos where channel_id.eq.${channel.id})`)
      .order('created_at', { ascending: false });
    setClaims((claimsData as CopyrightClaim[]) ?? []);

    // Fetch strikes for this channel
    const { data: strikesData } = await supabase
      .from('copyright_strikes')
      .select('*, claim:copyright_claims(*, video:videos(*))')
      .eq('channel_id', channel.id)
      .order('created_at', { ascending: false });
    setStrikes((strikesData as CopyrightStrike[]) ?? []);

    setLoading(false);
  }

  async function submitCounter(claimId: string) {
    if (!channel) return;
    const text = counterText[claimId]?.trim();
    if (!text) return;
    setSubmitting(claimId);

    await supabase
      .from('copyright_claims')
      .update({
        status: 'counter_notified',
        counter_text: text,
        counter_submitted_at: new Date().toISOString(),
      })
      .eq('id', claimId);

    setSubmitting(null);
    setCounterText((prev) => ({ ...prev, [claimId]: '' }));
    loadData();
  }

  async function resolveClaim(claimId: string, approve: boolean) {
    if (!channel) return;
    setSubmitting(claimId);

    const newStatus = approve ? 'approved' : 'rejected';
    await supabase
      .from('copyright_claims')
      .update({
        status: newStatus,
        resolved_at: new Date().toISOString(),
      })
      .eq('id', claimId);

    if (approve) {
      // Create a strike against the video owner's channel
      const claim = claims.find((c) => c.id === claimId);
      if (claim?.video) {
        const videoOwnerChannelId = (claim.video as Video).channel_id;
        await supabase.from('copyright_strikes').insert({
          channel_id: videoOwnerChannelId,
          claim_id: claimId,
          reason: claim.reason,
          status: 'active',
        });

        // Increment strike count and check restriction
        const { data: ownerChannel } = await supabase
          .from('channels')
          .select('strike_count')
          .eq('id', videoOwnerChannelId)
          .maybeSingle();

        const newCount = (ownerChannel?.strike_count ?? 0) + 1;
        await supabase
          .from('channels')
          .update({ strike_count: newCount, is_restricted: newCount >= 3 })
          .eq('id', videoOwnerChannelId);
      }
    }

    setSubmitting(null);
    loadData();
  }

  if (!session || !channel) {
    return (
      <div className="px-6 py-20 text-center">
        <ShieldAlert className="w-12 h-12 text-gray-600 mx-auto mb-3" />
        <p className="text-white text-lg">Sign in to access the Copyright Dashboard</p>
        <button onClick={() => navigate({ name: 'signin' })} className="text-blue-400 mt-2 hover:underline">
          Sign in
        </button>
      </div>
    );
  }

  const activeStrikes = strikes.filter((s) => s.status === 'active');
  const pendingClaims = claims.filter((c) => c.status === 'pending');
  const counterNotified = claims.filter((c) => c.status === 'counter_notified');

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-11 h-11 bg-blue-600/20 rounded-xl flex items-center justify-center">
          <ShieldAlert className="w-6 h-6 text-blue-400" />
        </div>
        <div>
          <h1 className="text-white text-xl font-bold">Copyright Dashboard</h1>
          <p className="text-gray-400 text-sm">Manage claims, strikes, and content protection</p>
        </div>
      </div>

      {/* Strike status banner */}
      <div className={`rounded-xl p-4 mb-6 border ${
        activeStrikes.length >= 3
          ? 'bg-red-500/10 border-red-500/30'
          : activeStrikes.length >= 2
          ? 'bg-amber-500/10 border-amber-500/30'
          : activeStrikes.length >= 1
          ? 'bg-yellow-500/10 border-yellow-500/20'
          : 'bg-green-500/10 border-green-500/20'
      }`}>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <Gavel className={`w-5 h-5 ${
              activeStrikes.length >= 3 ? 'text-red-400' : activeStrikes.length >= 2 ? 'text-amber-400' : activeStrikes.length >= 1 ? 'text-yellow-400' : 'text-green-400'
            }`} />
            <div>
              <p className="text-white text-sm font-medium">
                {activeStrikes.length} active strike{activeStrikes.length !== 1 ? 's' : ''}
              </p>
              <p className="text-gray-400 text-xs">
                {activeStrikes.length >= 3
                  ? 'Your channel is restricted. Uploads are blocked.'
                  : activeStrikes.length >= 2
                  ? 'One more strike will restrict your channel.'
                  : activeStrikes.length >= 1
                  ? 'Your channel is in good standing with 1 warning.'
                  : 'Your channel is in good standing.'}
              </p>
            </div>
          </div>
          {/* Strike meter */}
          <div className="flex items-center gap-1.5">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${
                  i < activeStrikes.length
                    ? activeStrikes.length >= 3
                      ? 'bg-red-600 text-white'
                      : 'bg-amber-500 text-black'
                    : 'bg-white/10 text-gray-500'
                }`}
              >
                {i + 1}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 mb-6 bg-white/5 rounded-xl p-1 w-fit">
        {([
          { id: 'overview' as Tab, label: 'Overview', icon: TrendingUp },
          { id: 'claims' as Tab, label: 'Claims', icon: FileText },
          { id: 'strikes' as Tab, label: 'Strikes', icon: Gavel },
        ]).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              tab === t.id ? 'bg-white/10 text-white' : 'text-gray-400 hover:text-white'
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 text-blue-400 animate-spin" />
        </div>
      ) : (
        <>
          {/* Overview tab */}
          {tab === 'overview' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <StatCard
                icon={<FileText className="w-5 h-5 text-blue-400" />}
                label="Total Claims"
                value={claims.length}
                sub={`${pendingClaims.length} pending`}
                color="blue"
              />
              <StatCard
                icon={<Gavel className="w-5 h-5 text-amber-400" />}
                label="Active Strikes"
                value={activeStrikes.length}
                sub={`${strikes.length} total`}
                color="amber"
              />
              <StatCard
                icon={<MessageSquareReply className="w-5 h-5 text-purple-400" />}
                label="Counter-Notifications"
                value={counterNotified.length}
                sub={counterNotified.length > 0 ? 'Awaiting review' : 'None submitted'}
                color="purple"
              />

              {/* Recent activity */}
              <div className="sm:col-span-3 mt-2">
                <h3 className="text-white text-sm font-bold mb-3">Recent Activity</h3>
                <div className="space-y-2">
                  {claims.length === 0 && strikes.length === 0 ? (
                    <div className="text-center py-12 bg-white/5 rounded-xl">
                      <ShieldAlert className="w-10 h-10 text-gray-600 mx-auto mb-2" />
                      <p className="text-gray-400 text-sm">No copyright activity yet</p>
                      <p className="text-gray-600 text-xs mt-1">Claims and strikes will appear here.</p>
                    </div>
                  ) : (
                    [...claims.slice(0, 3), ...strikes.slice(0, 3)].slice(0, 5).map((item) => {
                      const isClaim = 'claim_type' in item;
                      return (
                        <div key={item.id} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl">
                          <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            isClaim ? 'bg-blue-600/20' : 'bg-amber-600/20'
                          }`}>
                            {isClaim ? <FileText className="w-4 h-4 text-blue-400" /> : <Gavel className="w-4 h-4 text-amber-400" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-white text-sm font-medium truncate">
                              {isClaim ? (item as CopyrightClaim).reason : (item as CopyrightStrike).reason}
                            </p>
                            <p className="text-gray-400 text-xs">{formatTimeAgo(item.created_at)}</p>
                          </div>
                          <span className={`text-xs px-2 py-1 rounded ${
                            isClaim ? 'bg-blue-600/20 text-blue-400' : 'bg-amber-600/20 text-amber-400'
                          }`}>
                            {isClaim ? (item as CopyrightClaim).status : (item as CopyrightStrike).status}
                          </span>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Claims tab */}
          {tab === 'claims' && (
            <div className="space-y-3">
              {claims.length === 0 ? (
                <div className="text-center py-12 bg-white/5 rounded-xl">
                  <FileText className="w-10 h-10 text-gray-600 mx-auto mb-2" />
                  <p className="text-gray-400 text-sm">No copyright claims</p>
                  <p className="text-gray-600 text-xs mt-1">Claims filed by or against you will appear here.</p>
                </div>
              ) : (
                claims.map((claim) => {
                  const isClaimant = claim.claimant_id === channel.id;
                  const isVideoOwner = claim.video?.channel_id === channel.id;
                  return (
                    <div key={claim.id} className="bg-white/5 rounded-xl border border-white/10 overflow-hidden">
                      <div className="p-4">
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <div className="flex items-start gap-3 flex-1 min-w-0">
                            <div className="w-10 h-10 rounded-lg overflow-hidden bg-black flex-shrink-0">
                              {claim.video?.thumbnail_url ? (
                                <img src={claim.video.thumbnail_url} alt="" className="w-full h-full object-cover" />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                  <FileText className="w-5 h-5 text-gray-600" />
                                </div>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-white text-sm font-medium truncate">{claim.video?.title ?? 'Unknown video'}</p>
                              <p className="text-gray-400 text-xs truncate">
                                {isClaimant ? 'Filed by you' : `Filed by ${claim.claimant?.name ?? 'unknown'}`}
                              </p>
                              <p className="text-gray-400 text-xs">{formatTimeAgo(claim.created_at)}</p>
                            </div>
                          </div>
                          <ClaimStatusBadge status={claim.status} />
                        </div>

                        <div className="bg-black/30 rounded-lg p-3 mb-3">
                          <p className="text-gray-300 text-xs">
                            <span className="text-gray-500">Reason: </span>
                            {claim.reason}
                          </p>
                          <p className="text-gray-300 text-xs mt-1">
                            <span className="text-gray-500">Type: </span>
                            {claim.claim_type === 'content_id' ? 'Content ID Match' : claim.claim_type === 'duplicate' ? 'Duplicate Content' : 'Manual Claim'}
                          </p>
                        </div>

                        {/* Counter-notification (video owner only, pending claims) */}
                        {isVideoOwner && claim.status === 'pending' && (
                          <div className="space-y-2">
                            <p className="text-white text-xs font-medium">Submit a counter-notification:</p>
                            <textarea
                              value={counterText[claim.id] ?? ''}
                              onChange={(e) => setCounterText((prev) => ({ ...prev, [claim.id]: e.target.value }))}
                              placeholder="Explain why you believe this claim is invalid..."
                              rows={2}
                              className="w-full bg-[#121212] border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500 resize-none"
                            />
                            <button
                              onClick={() => submitCounter(claim.id)}
                              disabled={!counterText[claim.id]?.trim() || submitting === claim.id}
                              className="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-600 text-white text-xs font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                            >
                              {submitting === claim.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <MessageSquareReply className="w-3.5 h-3.5" />}
                              Submit Counter
                            </button>
                          </div>
                        )}

                        {/* Show counter-notification if submitted */}
                        {claim.counter_text && (
                          <div className="bg-purple-600/10 border border-purple-500/20 rounded-lg p-3 mt-2">
                            <p className="text-purple-300 text-xs font-medium mb-1">Counter-notification:</p>
                            <p className="text-gray-300 text-xs">{claim.counter_text}</p>
                          </div>
                        )}

                        {/* Resolve buttons (claimant only, pending or counter_notified) */}
                        {isClaimant && (claim.status === 'pending' || claim.status === 'counter_notified') && (
                          <div className="flex gap-2 mt-3">
                            <button
                              onClick={() => resolveClaim(claim.id, true)}
                              disabled={submitting === claim.id}
                              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-600/80 text-white text-xs font-medium hover:bg-red-600 disabled:opacity-50 transition-colors"
                            >
                              <Check className="w-3.5 h-3.5" />
                              Approve & Issue Strike
                            </button>
                            <button
                              onClick={() => resolveClaim(claim.id, false)}
                              disabled={submitting === claim.id}
                              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white/10 text-white text-xs font-medium hover:bg-white/20 disabled:opacity-50 transition-colors"
                            >
                              <X className="w-3.5 h-3.5" />
                              Reject Claim
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* Strikes tab */}
          {tab === 'strikes' && (
            <div className="space-y-3">
              {strikes.length === 0 ? (
                <div className="text-center py-12 bg-white/5 rounded-xl">
                  <Gavel className="w-10 h-10 text-gray-600 mx-auto mb-2" />
                  <p className="text-gray-400 text-sm">No strikes on your channel</p>
                  <p className="text-gray-600 text-xs mt-1">Keep creating original content to maintain good standing.</p>
                </div>
              ) : (
                strikes.map((strike, i) => (
                  <div key={strike.id} className={`rounded-xl border p-4 ${
                    strike.status === 'active'
                      ? 'bg-amber-500/10 border-amber-500/30'
                      : 'bg-white/5 border-white/10'
                  }`}>
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 font-bold ${
                        strike.status === 'active' ? 'bg-amber-600/30 text-amber-400' : 'bg-white/10 text-gray-500'
                      }`}>
                        {i + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-white text-sm font-medium truncate">{strike.reason}</p>
                          <span className={`text-xs px-2 py-1 rounded flex-shrink-0 ${
                            strike.status === 'active' ? 'bg-amber-600/20 text-amber-400' : 'bg-white/10 text-gray-400'
                          }`}>
                            {strike.status}
                          </span>
                        </div>
                        {strike.claim?.video && (
                          <p className="text-gray-400 text-xs mt-1 truncate">
                            Video: {strike.claim.video.title}
                          </p>
                        )}
                        <p className="text-gray-500 text-xs mt-1 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatTimeAgo(strike.created_at)}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}

              {/* 3-strike policy info */}
              <div className="bg-blue-600/10 border border-blue-500/20 rounded-xl p-4 mt-4">
                <div className="flex items-start gap-3">
                  <ShieldAlert className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-white text-sm font-medium">3-Strike Policy</p>
                    <p className="text-gray-400 text-xs mt-1 leading-relaxed">
                      Channels receive strikes when copyright claims are approved. After 3 active strikes,
                      your channel becomes restricted and uploads are blocked. Strikes may expire over time
                      if no further violations occur. You can appeal strikes by submitting a counter-notification.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  sub,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  sub: string;
  color: string;
}) {
  const colorMap: Record<string, string> = {
    blue: 'bg-blue-600/20 text-blue-400',
    amber: 'bg-amber-600/20 text-amber-400',
    purple: 'bg-purple-600/20 text-purple-400',
  };
  return (
    <div className="bg-white/5 rounded-xl p-4 border border-white/10">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${colorMap[color]}`}>
        {icon}
      </div>
      <p className="text-white text-2xl font-bold">{value}</p>
      <p className="text-gray-400 text-xs">{label}</p>
      <p className="text-gray-500 text-xs mt-1">{sub}</p>
    </div>
  );
}

function ClaimStatusBadge({ status }: { status: string }) {
  const map: Record<string, { bg: string; text: string }> = {
    pending: { bg: 'bg-yellow-500/20', text: 'text-yellow-400' },
    approved: { bg: 'bg-red-500/20', text: 'text-red-400' },
    rejected: { bg: 'bg-gray-500/20', text: 'text-gray-400' },
    counter_notified: { bg: 'bg-purple-500/20', text: 'text-purple-400' },
    resolved: { bg: 'bg-green-500/20', text: 'text-green-400' },
  };
  const style = map[status] ?? map.pending;
  return (
    <span className={`text-xs px-2 py-1 rounded flex-shrink-0 ${style.bg} ${style.text}`}>
      {status.replace('_', ' ')}
    </span>
  );
}
