import { useState, useEffect } from 'react';
import { supabase, CATEGORIES, type Video } from '@/lib/supabase';
import { VideoCard } from '@/components/VideoCard';

export function HomePage() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('All');

  useEffect(() => {
    async function fetchVideos() {
      setLoading(true);
      let query = supabase
        .from('videos')
        .select('*, channel:channels(*)')
        .order('created_at', { ascending: false })
        .limit(30);

      if (activeCategory !== 'All') {
        query = query.eq('category', activeCategory);
      }

      const { data } = await query;
      setVideos((data as Video[]) ?? []);
      setLoading(false);
    }
    fetchVideos();
  }, [activeCategory]);

  return (
    <div className="px-6 py-4">
      <div className="flex gap-3 mb-6 overflow-x-auto scrollbar-hide pb-2">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
              activeCategory === cat
                ? 'bg-white text-black'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-video rounded-xl bg-white/10" />
              <div className="flex gap-3 mt-3">
                <div className="w-9 h-9 rounded-full bg-white/10" />
                <div className="flex-1">
                  <div className="h-3 bg-white/10 rounded w-full mb-2" />
                  <div className="h-3 bg-white/10 rounded w-2/3" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-8">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} />
          ))}
        </div>
      )}
    </div>
  );
}
