import { useState, useEffect } from 'react';
import { supabase, type Video } from '@/lib/supabase';
import { useRouter } from '@/context/RouterContext';
import { VideoCard } from '@/components/VideoCard';
import { Search as SearchIcon } from 'lucide-react';

export function SearchPage({ query }: { query: string }) {
  const { navigate } = useRouter();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function search() {
      setLoading(true);
      const { data } = await supabase
        .from('videos')
        .select('*, channel:channels(*)')
        .or(`title.ilike.%${query}%,description.ilike.%${query}%`)
        .order('views', { ascending: false })
        .limit(30);
      setVideos((data as Video[]) ?? []);
      setLoading(false);
    }
    search();
  }, [query]);

  return (
    <div className="px-6 py-4 max-w-5xl">
      <div className="flex items-center gap-2 mb-6">
        <SearchIcon className="w-5 h-5 text-gray-400" />
        <h1 className="text-white text-lg font-medium">
          Results for "{query}"
        </h1>
      </div>

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="animate-pulse flex gap-4">
              <div className="w-80 aspect-video rounded-xl bg-white/10" />
              <div className="flex-1">
                <div className="h-4 bg-white/10 rounded w-3/4 mb-2" />
                <div className="h-3 bg-white/10 rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : videos.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-gray-400 text-lg">No videos found</p>
          <p className="text-gray-500 text-sm mt-1">Try different keywords</p>
        </div>
      ) : (
        <div className="space-y-4">
          {videos.map((video) => (
            <div
              key={video.id}
              onClick={() => navigate({ name: 'watch', videoId: video.id })}
              className="flex flex-col sm:flex-row gap-4 cursor-pointer group"
            >
              <div className="sm:w-80 flex-shrink-0 aspect-video rounded-xl overflow-hidden bg-[#1a1a1a]">
                {video.thumbnail_url && (
                  <img
                    src={video.thumbnail_url}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform"
                  />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-white text-base font-medium line-clamp-2 group-hover:opacity-80">
                  {video.title}
                </h2>
                <p className="text-gray-400 text-xs mt-1">
                  {video.views.toLocaleString()} views • {new Date(video.created_at).toLocaleDateString()}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="w-6 h-6 rounded-full overflow-hidden bg-white/10">
                    {video.channel?.avatar_url && (
                      <img src={video.channel.avatar_url} alt="" className="w-full h-full object-cover" />
                    )}
                  </div>
                  <span className="text-gray-400 text-xs">{video.channel?.name}</span>
                </div>
                <p className="text-gray-400 text-sm mt-2 line-clamp-2">{video.description}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
