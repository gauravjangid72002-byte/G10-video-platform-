import { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  Users,
  Video as VideoIcon,
  DollarSign,
  Settings2,
  Check,
  X,
  Ban,
  Unlock,
  Loader2,
  TrendingUp,
  Clock,
  AlertTriangle,
  Search,
  Eye,
  Trash2,
  Save,
} from 'lucide-react';
import {
  supabase,
  type Channel,
  type Video,
  type MonetizationCriteria,
} from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { formatNumber, formatViews, formatTimeAgo } from '@/lib/format';
import { sanitizeText, sanitizeNumber, truncateText } from '@/lib/sanitize';

type Tab = 'criteria' | 'review' | 'users' | 'videos';

export function AdminPage() {
  const { channel, session } = useAuth();
  const { navigate } = useRouter();
  const [tab, setTab] = useState<Tab>('criteria');
  const [isAdmin, setIsAdmin] = useState(false);
  const [checkingAdmin, setCheckingAdmin] = useState(true);

  useEffect(() => {
    async function checkAdmin() {
      if (!session || !channel) {
        setCheckingAdmin(false);
        return;
      }
      const { data } = await supabase.rpc('is_current_user_admin');
      setIsAdmin(data === true);
      setCheckingAdmin(false);
    }
    checkAdmin();
  }, [session, channel]);

  if (checkingAdmin) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-red-400 animate-spin" />
      </div>
    );
  }

  if (!session || !channel || !isAdmin) {
    return (
      <div className="px-6 py-20 text-center">
        <ShieldCheck className="w-12 h-12 text-gray-600 mx-auto mb-3" />
        <p className="text-white text-lg">Access Denied</p>
        <p className="text-gray-400 text-sm mt-1">You need admin privileges to view this page.</p>
        <button onClick={() => navigate({ name: 'home' })} className="text-blue-400 mt-3 hover:underline text-sm">
          Go home
        </button>
      </div>
    );
  }

  const tabs: { id: Tab; label: string; icon: typeof Settings2 }[] = [
    { id: 'criteria', label: 'Monetization Criteria', icon: Settings2 },
    { id: 'review', label: 'Monetization Review', icon: DollarSign },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'videos', label: 'Content Management', icon: VideoIcon },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-11 h-11 bg-red-600/20 rounded-xl flex items-center justify-center">
          <ShieldCheck className="w-6 h-6 text-red-400" />
        </div>
        <div>
          <h1 className="text-white text-xl font-bold">Admin Control Panel</h1>
          <p className="text-gray-400 text-sm">Manage platform, users, and content</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto scrollbar-thin border-b border-white/10 pb-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
              tab === t.id ? 'bg-red-600/20 text-red-400 border border-red-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'criteria' && <CriteriaTab />}
      {tab === 'review' && <ReviewTab />}
      {tab === 'users' && <UsersTab />}
      {tab === 'videos' && <VideosTab />}
    </div>
  );
}

// ============================================================
// Tab 1: Dynamic Monetization Criteria
// ============================================================
function CriteriaTab() {
  const [criteria, setCriteria] = useState<MonetizationCriteria | null>(null);
  const [minSubs, setMinSubs] = useState(20);
  const [minWatchHours, setMinWatchHours] = useState(1);
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      const { data, error } = await supabase.rpc('get_monetization_criteria');
      if (data && data.length > 0) {
        const c = data[0];
        setCriteria({ min_subscribers: c.min_subscribers, min_watch_time_seconds: c.min_watch_time_seconds });
        setMinSubs(c.min_subscribers);
        setMinWatchHours(Math.round(c.min_watch_time_seconds / 3600 * 10) / 10);
      }
    }
    load();
  }, []);

  async function save() {
    setSaving(true);
    setError(null);
    setSavedMsg(false);

    const safeSubs = sanitizeNumber(minSubs, 0, 1000000);
    const safeWatchSeconds = Math.round(sanitizeNumber(minWatchHours, 0, 10000) * 3600);

    const { error: rpcError } = await supabase.rpc('update_monetization_criteria', {
      p_min_subscribers: safeSubs,
      p_min_watch_time_seconds: safeWatchSeconds,
    });

    setSaving(false);

    if (rpcError) {
      setError('Could not update criteria. Please try again.');
      return;
    }

    setCriteria({ min_subscribers: safeSubs, min_watch_time_seconds: safeWatchSeconds });
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 3000);
  }

  return (
    <div className="space-y-6">
      <div className="bg-white/5 rounded-2xl border border-white/10 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Settings2 className="w-5 h-5 text-red-400" />
          <h3 className="text-white text-sm font-bold">Monetization Eligibility Requirements</h3>
        </div>

        <p className="text-gray-400 text-sm mb-6">
          Set the minimum requirements creators must meet before they can apply for monetization.
          Changes take effect immediately across all creator dashboards.
        </p>

        <div className="space-y-5">
          {/* Min subscribers */}
          <div>
            <label className="flex items-center gap-2 text-white text-sm font-medium mb-2">
              <Users className="w-4 h-4 text-blue-400" />
              Minimum Subscribers
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                min={0}
                max={1000000}
                value={minSubs}
                onChange={(e) => setMinSubs(parseInt(e.target.value) || 0)}
                className="w-32 bg-[#121212] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-red-500"
              />
              <span className="text-gray-400 text-sm">subscribers</span>
            </div>
          </div>

          {/* Min watch time */}
          <div>
            <label className="flex items-center gap-2 text-white text-sm font-medium mb-2">
              <Clock className="w-4 h-4 text-green-400" />
              Minimum Watch Time
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                min={0}
                max={10000}
                step={0.1}
                value={minWatchHours}
                onChange={(e) => setMinWatchHours(parseFloat(e.target.value) || 0)}
                className="w-32 bg-[#121212] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-red-500"
              />
              <span className="text-gray-400 text-sm">hours</span>
            </div>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
            {error}
          </div>
        )}

        {savedMsg && (
          <div className="mt-4 p-3 bg-green-500/10 border border-green-500/30 rounded-lg text-green-400 text-sm flex items-center gap-2">
            <Check className="w-4 h-4" />
            Criteria updated successfully. All creator dashboards now reflect these requirements.
          </div>
        )}

        <button
          onClick={save}
          disabled={saving}
          className="mt-5 flex items-center gap-2 px-5 py-2.5 rounded-xl bg-red-600 text-white text-sm font-bold hover:bg-red-700 disabled:opacity-50 transition-colors"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saving ? 'Saving...' : 'Save Criteria'}
        </button>
      </div>

      {/* Current values preview */}
      {criteria && (
        <div className="bg-white/5 rounded-2xl border border-white/10 p-5">
          <h4 className="text-white text-sm font-bold mb-3">Current Requirements</h4>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-blue-600/10 rounded-xl p-4 border border-blue-500/20">
              <Users className="w-5 h-5 text-blue-400 mb-2" />
              <p className="text-white text-2xl font-bold">{criteria.min_subscribers}</p>
              <p className="text-gray-400 text-xs">Minimum subscribers</p>
            </div>
            <div className="bg-green-600/10 rounded-xl p-4 border border-green-500/20">
              <Clock className="w-5 h-5 text-green-400 mb-2" />
              <p className="text-white text-2xl font-bold">
                {Math.floor(criteria.min_watch_time_seconds / 3600)}h {Math.floor((criteria.min_watch_time_seconds % 3600) / 60)}m
              </p>
              <p className="text-gray-400 text-xs">Minimum watch time</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// Tab 2: Monetization Review & Approve
// ============================================================
function ReviewTab() {
  const { navigate } = useRouter();
  const [pending, setPending] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState<string | null>(null);

  const loadPending = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('channels')
      .select('*')
      .eq('monetization_status', 'pending')
      .order('created_at', { ascending: true });
    if (!error && data) {
      setPending(data as Channel[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadPending();
  }, [loadPending]);

  async function approve(channelId: string) {
    setActing(channelId);
    const { error } = await supabase.rpc('admin_approve_monetization', { target_channel_id: channelId });
    setActing(null);
    if (!error) {
      setPending((prev) => prev.filter((c) => c.id !== channelId));
    }
  }

  async function reject(channelId: string) {
    setActing(channelId);
    const { error } = await supabase.rpc('admin_reject_monetization', { target_channel_id: channelId });
    setActing(null);
    if (!error) {
      setPending((prev) => prev.filter((c) => c.id !== channelId));
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 text-red-400 animate-spin" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <DollarSign className="w-5 h-5 text-red-400" />
        <h3 className="text-white text-sm font-bold">Pending Monetization Applications</h3>
        {pending.length > 0 && (
          <span className="px-2 py-0.5 bg-amber-500/20 text-amber-400 text-xs font-medium rounded-full">
            {pending.length} pending
          </span>
        )}
      </div>

      {pending.length === 0 ? (
        <div className="text-center py-12 bg-white/5 rounded-xl">
          <Check className="w-10 h-10 text-green-600 mx-auto mb-2" />
          <p className="text-gray-400 text-sm">No pending applications</p>
          <p className="text-gray-600 text-xs mt-1">All caught up!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {pending.map((ch) => (
            <div key={ch.id} className="bg-white/5 rounded-xl border border-white/10 p-4 flex items-center gap-4">
              <button
                onClick={() => navigate({ name: 'channel', channelId: ch.id })}
                className="w-11 h-11 rounded-full overflow-hidden bg-white/10 flex-shrink-0"
              >
                {ch.avatar_url && <img src={ch.avatar_url} alt="" className="w-full h-full object-cover" />}
              </button>
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium">{ch.name}</p>
                <p className="text-gray-400 text-xs">{ch.handle}</p>
                <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Users className="w-3 h-3" /> {formatNumber(ch.subscriber_count ?? 0)} subs
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {Math.floor((ch.watch_time_seconds ?? 0) / 60)}m watch
                  </span>
                  <span>{formatNumber(ch.video_count ?? 0)} videos</span>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => approve(ch.id)}
                  disabled={acting === ch.id}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-green-600 text-white text-xs font-medium hover:bg-green-700 disabled:opacity-50 transition-colors"
                >
                  {acting === ch.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                  Approve
                </button>
                <button
                  onClick={() => reject(ch.id)}
                  disabled={acting === ch.id}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-600/20 text-red-400 text-xs font-medium hover:bg-red-600/30 border border-red-500/30 disabled:opacity-50 transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// Tab 3: User Management
// ============================================================
function UsersTab() {
  const { navigate } = useRouter();
  const [users, setUsers] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [acting, setActing] = useState<string | null>(null);

  const loadUsers = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('channels')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);
    if (!error && data) {
      setUsers(data as Channel[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  async function blockUser(channelId: string) {
    const reason = prompt('Reason for blocking?');
    if (reason === null) return;
    setActing(channelId);
    const safeReason = sanitizeText(reason);
    await supabase.rpc('admin_block_channel', {
      target_channel_id: channelId,
      p_reason: safeReason,
    });
    setActing(null);
    loadUsers();
  }

  async function unblockUser(channelId: string) {
    setActing(channelId);
    await supabase.rpc('admin_unblock_channel', { target_channel_id: channelId });
    setActing(null);
    loadUsers();
  }

  async function setRole(channelId: string, role: 'user' | 'admin') {
    setActing(channelId);
    await supabase.rpc('admin_set_channel_role', {
      target_channel_id: channelId,
      p_role: role,
    });
    setActing(null);
    loadUsers();
  }

  const filtered = users.filter((u) => {
    const q = search.toLowerCase();
    return u.name.toLowerCase().includes(q) || u.handle.toLowerCase().includes(q);
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 text-red-400 animate-spin" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Users className="w-5 h-5 text-red-400" />
        <h3 className="text-white text-sm font-bold">User Management</h3>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(sanitizeText(e.target.value))}
          placeholder="Search by name or handle..."
          className="w-full bg-[#121212] border border-white/10 rounded-lg pl-10 pr-4 py-2.5 text-white text-sm focus:outline-none focus:border-red-500"
        />
      </div>

      <div className="space-y-2">
        {filtered.map((ch) => (
          <div key={ch.id} className="bg-white/5 rounded-xl border border-white/10 p-3 flex items-center gap-3">
            <button
              onClick={() => navigate({ name: 'channel', channelId: ch.id })}
              className="w-10 h-10 rounded-full overflow-hidden bg-white/10 flex-shrink-0"
            >
              {ch.avatar_url && <img src={ch.avatar_url} alt="" className="w-full h-full object-cover" />}
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-white text-sm font-medium truncate">{ch.name}</p>
                {ch.role === 'admin' && (
                  <span className="px-1.5 py-0.5 bg-red-500/20 text-red-400 text-[10px] font-medium rounded">ADMIN</span>
                )}
                {ch.is_blocked && (
                  <span className="flex items-center gap-0.5 px-1.5 py-0.5 bg-red-500/20 text-red-400 text-[10px] font-medium rounded">
                    <Ban className="w-2.5 h-2.5" /> BLOCKED
                  </span>
                )}
                {ch.monetization_status === 'approved' && (
                  <span className="px-1.5 py-0.5 bg-green-500/20 text-green-400 text-[10px] font-medium rounded">MONETIZED</span>
                )}
              </div>
              <p className="text-gray-400 text-xs">{ch.handle} — {formatTimeAgo(ch.created_at)}</p>
              {ch.blocked_reason && (
                <p className="text-red-400/70 text-xs mt-0.5">Reason: {ch.blocked_reason}</p>
              )}
            </div>
            <div className="flex items-center gap-1.5 flex-shrink-0">
              {/* Role toggle */}
              <button
                onClick={() => setRole(ch.id, ch.role === 'admin' ? 'user' : 'admin')}
                disabled={acting === ch.id}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  ch.role === 'admin'
                    ? 'bg-white/10 text-gray-400 hover:bg-white/20'
                    : 'bg-purple-600/20 text-purple-400 hover:bg-purple-600/30 border border-purple-500/20'
                }`}
              >
                {ch.role === 'admin' ? 'Demote' : 'Make Admin'}
              </button>
              {/* Block/Unblock */}
              {ch.is_blocked ? (
                <button
                  onClick={() => unblockUser(ch.id)}
                  disabled={acting === ch.id}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-green-600/20 text-green-400 text-xs font-medium hover:bg-green-600/30 transition-colors"
                >
                  {acting === ch.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Unlock className="w-3 h-3" />}
                  Unblock
                </button>
              ) : (
                <button
                  onClick={() => blockUser(ch.id)}
                  disabled={acting === ch.id || ch.role === 'admin'}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-red-600/20 text-red-400 text-xs font-medium hover:bg-red-600/30 transition-colors disabled:opacity-30"
                >
                  {acting === ch.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Ban className="w-3 h-3" />}
                  Block
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-400 text-sm">No users found</p>
        </div>
      )}
    </div>
  );
}

// ============================================================
// Tab 4: Content Management
// ============================================================
function VideosTab() {
  const { navigate } = useRouter();
  const [videos, setVideos] = useState<(Video & { channel?: Channel })[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [acting, setActing] = useState<string | null>(null);

  const loadVideos = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('videos')
      .select('*, channel:channels(*)')
      .order('created_at', { ascending: false })
      .limit(50);
    if (!error && data) {
      setVideos(data as (Video & { channel?: Channel })[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadVideos();
  }, [loadVideos]);

  async function deleteVideo(videoId: string) {
    if (!confirm('Are you sure you want to take down this video? This action cannot be undone.')) return;
    setActing(videoId);
    const { error } = await supabase.from('videos').delete().eq('id', videoId);
    setActing(null);
    if (!error) {
      setVideos((prev) => prev.filter((v) => v.id !== videoId));
    }
  }

  const filtered = videos.filter((v) => {
    const q = search.toLowerCase();
    return v.title.toLowerCase().includes(q) || (v.channel?.name ?? '').toLowerCase().includes(q);
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 text-red-400 animate-spin" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <VideoIcon className="w-5 h-5 text-red-400" />
        <h3 className="text-white text-sm font-bold">Content Management</h3>
        <span className="text-gray-500 text-xs">— {filtered.length} videos</span>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(sanitizeText(e.target.value))}
          placeholder="Search by title or channel..."
          className="w-full bg-[#121212] border border-white/10 rounded-lg pl-10 pr-4 py-2.5 text-white text-sm focus:outline-none focus:border-red-500"
        />
      </div>

      <div className="space-y-2">
        {filtered.map((v) => (
          <div key={v.id} className="bg-white/5 rounded-xl border border-white/10 p-3 flex items-center gap-3">
            <div className="w-20 h-12 rounded-lg overflow-hidden bg-black flex-shrink-0">
              {v.thumbnail_url ? (
                <img src={v.thumbnail_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <VideoIcon className="w-4 h-4 text-gray-600" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-white text-sm font-medium truncate">{v.title}</p>
                {v.is_ppv && <span className="text-amber-400 text-[10px] bg-amber-500/10 px-1.5 py-0.5 rounded">PPV</span>}
                {v.is_short && <span className="text-red-400 text-[10px] bg-red-500/10 px-1.5 py-0.5 rounded">SHORT</span>}
              </div>
              <div className="flex items-center gap-3 text-xs text-gray-500 mt-0.5">
                <span>{v.channel?.name}</span>
                <span className="flex items-center gap-0.5"><Eye className="w-3 h-3" /> {formatViews(v.views)}</span>
                <span>{formatTimeAgo(v.created_at)}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <button
                onClick={() => navigate({ name: 'watch', videoId: v.id })}
                className="p-2 rounded-lg bg-white/10 text-gray-400 hover:text-white hover:bg-white/20 transition-colors"
                title="Watch video"
              >
                <Eye className="w-4 h-4" />
              </button>
              <button
                onClick={() => deleteVideo(v.id)}
                disabled={acting === v.id}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-red-600/20 text-red-400 text-xs font-medium hover:bg-red-600/30 transition-colors disabled:opacity-50"
                title="Take down video"
              >
                {acting === v.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                Takedown
              </button>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12">
          <VideoIcon className="w-10 h-10 text-gray-600 mx-auto mb-2" />
          <p className="text-gray-400 text-sm">No videos found</p>
        </div>
      )}
    </div>
  );
}
