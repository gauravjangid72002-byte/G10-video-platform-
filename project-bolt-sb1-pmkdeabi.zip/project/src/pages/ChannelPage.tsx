import { useState, useEffect } from 'react';
import { supabase, type Video, type Channel } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { VideoCard } from '@/components/VideoCard';
import { formatNumber, formatTimeAgo } from '@/lib/format';
import { Settings, Bell, ShieldAlert, Gavel, MessageSquare } from 'lucide-react';
import { CommunityPosts } from '@/components/CommunityPosts';

export function ChannelPage({ channelId }: { channelId: string }) {
  const { session, channel: myChannel } = useAuth();
  const { navigate } = useRouter();
  const [channelInfo, setChannelInfo] = useState<Channel | null>(null);
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [subscribed, setSubscribed] = useState(false);
  const [subscriberCount, setSubscriberCount] = useState(0);
  const [tab, setTab] = useState<'videos' | 'about' | 'community'>('videos');

  useEffect(() => {
    async function fetchChannel() {
      setLoading(true);

      const { data: ch } = await supabase
        .from('channels')
        .select('*')
        .eq('id', channelId)
        .maybeSingle();
      setChannelInfo(ch as Channel | null);

      const { data: vids } = await supabase
        .from('videos')
        .select('*, channel:channels(*)')
        .eq('channel_id', channelId)
        .order('created_at', { ascending: false });
      setVideos((vids as Video[]) ?? []);

      const { count } = await supabase
        .from('subscriptions')
        .select('*', { count: 'exact', head: true })
        .eq('channel_id', channelId);
      setSubscriberCount(count ?? 0);

      if (myChannel && channelId !== myChannel.id) {
        const { data: sub } = await supabase
          .from('subscriptions')
          .select('id')
          .eq('subscriber_id', myChannel.id)
          .eq('channel_id', channelId)
          .maybeSingle();
        setSubscribed(!!sub);
      }

      setLoading(false);
    }
    fetchChannel();
  }, [channelId, myChannel]);

  async function toggleSubscribe() {
    if (!myChannel || !channelInfo) return;
    if (subscribed) {
      await supabase
        .from('subscriptions')
        .delete()
        .eq('subscriber_id', myChannel.id)
        .eq('channel_id', channelId);
      setSubscribed(false);
      setSubscriberCount((c) => c - 1);
    } else {
      await supabase
        .from('subscriptions')
        .insert({ subscriber_id: myChannel.id, channel_id: channelId });
      setSubscribed(true);
      setSubscriberCount((c) => c + 1);
    }
  }

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-40 bg-white/10" />
        <div className="px-6 py-4">
          <div className="w-24 h-24 rounded-full bg-white/10" />
          <div className="h-6 bg-white/10 rounded w-48 mt-4" />
        </div>
      </div>
    );
  }

  if (!channelInfo) {
    return (
      <div className="px-6 py-20 text-center">
        <p className="text-white text-lg">Channel not found</p>
      </div>
    );
  }

  const isOwner = myChannel?.id === channelId;
  const strikeCount = channelInfo.strike_count ?? 0;
  const isRestricted = channelInfo.is_restricted ?? false;

  return (
    <div>
      {/* Strike banner */}
      {strikeCount > 0 && (
        <div className={`mx-6 mt-4 rounded-xl p-3 flex items-center gap-3 border ${
          isRestricted ? 'bg-red-500/10 border-red-500/30' : strikeCount >= 2 ? 'bg-amber-500/10 border-amber-500/30' : 'bg-yellow-500/10 border-yellow-500/20'
        }`}>
          <Gavel className={`w-5 h-5 flex-shrink-0 ${
            isRestricted ? 'text-red-400' : strikeCount >= 2 ? 'text-amber-400' : 'text-yellow-400'
          }`} />
          <div className="flex-1">
            <p className={`text-sm font-medium ${
              isRestricted ? 'text-red-400' : strikeCount >= 2 ? 'text-amber-400' : 'text-yellow-400'
            }`}>
              {isRestricted
                ? 'This channel is restricted due to copyright violations'
                : `${strikeCount} active copyright strike${strikeCount !== 1 ? 's' : ''}`}
            </p>
            <p className="text-gray-400 text-xs">
              {isRestricted
                ? 'Uploads are blocked until strikes are resolved.'
                : strikeCount >= 2
                ? 'One more strike will restrict this channel.'
                : 'Repeated violations may lead to channel restriction.'}
            </p>
          </div>
          {isOwner && (
            <button
              onClick={() => navigate({ name: 'copyright' })}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 text-white text-xs font-medium hover:bg-white/20 transition-colors flex-shrink-0"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              View Dashboard
            </button>
          )}
        </div>
      )}
      <div className="relative h-32 sm:h-48 bg-[#1a1a1a] overflow-hidden">
        {channelInfo.banner_url && (
          <img src={channelInfo.banner_url} alt="" className="w-full h-full object-cover" />
        )}
      </div>

      <div className="px-6 py-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="w-24 h-24 rounded-full overflow-hidden bg-white/10 flex-shrink-0 -mt-12 sm:-mt-16 border-4 border-[#0f0f0f]">
            {channelInfo.avatar_url && (
              <img src={channelInfo.avatar_url} alt="" className="w-full h-full object-cover" />
            )}
          </div>
          <div className="flex-1">
            <h1 className="text-white text-2xl font-bold">{channelInfo.name}</h1>
            <div className="flex flex-wrap items-center gap-2 text-gray-400 text-sm mt-1">
              <span>{channelInfo.handle}</span>
              <span>•</span>
              <span>{formatNumber(subscriberCount)} subscribers</span>
              <span>•</span>
              <span>{videos.length} videos</span>
            </div>
            {channelInfo.bio && (
              <p className="text-gray-300 text-sm mt-2 max-w-2xl line-clamp-2">{channelInfo.bio}</p>
            )}
          </div>
          <div className="flex items-center gap-2">
            {isOwner ? (
              <>
                <button
                  onClick={() => navigate({ name: 'upload' })}
                  className="px-4 py-2 bg-white text-black rounded-full text-sm font-medium hover:bg-white/90"
                >
                  Upload video
                </button>
                <button className="p-2 bg-white/10 rounded-full hover:bg-white/20">
                  <Settings className="w-5 h-5 text-white" />
                </button>
              </>
            ) : (
              session && (
                <button
                  onClick={toggleSubscribe}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium transition-colors ${
                    subscribed
                      ? 'bg-white/10 text-white hover:bg-white/20'
                      : 'bg-white text-black hover:bg-white/90'
                  }`}
                >
                  {subscribed && <Bell className="w-4 h-4" />}
                  {subscribed ? 'Subscribed' : 'Subscribe'}
                </button>
              )
            )}
          </div>
        </div>

        <div className="flex gap-6 mt-6 border-b border-white/10">
          <button
            onClick={() => setTab('videos')}
            className={`pb-3 text-sm font-medium border-b-2 transition-colors ${
              tab === 'videos' ? 'text-white border-white' : 'text-gray-400 border-transparent hover:text-white'
            }`}
          >
            Videos
          </button>
          <button
            onClick={() => setTab('community')}
            className={`flex items-center gap-1.5 pb-3 text-sm font-medium border-b-2 transition-colors ${
              tab === 'community' ? 'text-white border-white' : 'text-gray-400 border-transparent hover:text-white'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            Community
          </button>
          <button
            onClick={() => setTab('about')}
            className={`pb-3 text-sm font-medium border-b-2 transition-colors ${
              tab === 'about' ? 'text-white border-white' : 'text-gray-400 border-transparent hover:text-white'
            }`}
          >
            About
          </button>
        </div>

        {tab === 'videos' && (
          <div className="mt-6">
            {videos.length === 0 ? (
              <p className="text-gray-400 text-center py-20">No videos yet</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-8">
                {videos.map((v) => (
                  <VideoCard key={v.id} video={v} />
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'community' && (
          <CommunityPosts channelId={channelId} />
        )}

        {tab === 'about' && (
          <div className="mt-6 max-w-2xl">
            <h3 className="text-white text-lg font-medium mb-3">About</h3>
            <p className="text-gray-300 text-sm whitespace-pre-wrap">{channelInfo.bio || 'No description provided.'}</p>
            <div className="mt-6 space-y-2">
              <div className="flex items-center gap-3 text-sm">
                <span className="text-gray-400 w-32">Channel created</span>
                <span className="text-white">{formatTimeAgo(channelInfo.created_at)}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <span className="text-gray-400 w-32">Total videos</span>
                <span className="text-white">{videos.length}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <span className="text-gray-400 w-32">Subscribers</span>
                <span className="text-white">{formatNumber(subscriberCount)}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
