import { useState, useEffect } from 'react';
import { supabase, type Video } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { VideoCard } from '@/components/VideoCard';
import { History, ThumbsUp, PlaySquare } from 'lucide-react';

export function LibraryPage() {
  const { session, channel } = useAuth();
  const { navigate } = useRouter();
  const [likedVideos, setLikedVideos] = useState<Video[]>([]);
  const [myVideos, setMyVideos] = useState<Video[]>([]);
  const [subVideos, setSubVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'history' | 'liked' | 'subscriptions'>('history');

  useEffect(() => {
    if (!session || !channel) {
      setLoading(false);
      return;
    }

    async function fetchLibrary() {
      if (!channel) return;
      setLoading(true);

      // My videos (history proxy)
      const { data: myVids } = await supabase
        .from('videos')
        .select('*, channel:channels(*)')
        .eq('channel_id', channel.id)
        .order('created_at', { ascending: false });
      setMyVideos((myVids as Video[]) ?? []);

      // Liked videos
      const { data: liked } = await supabase
        .from('video_likes')
        .select('video:videos(*, channel:channels(*))')
        .eq('channel_id', channel.id)
        .order('created_at', { ascending: false });
      setLikedVideos((liked?.map((l: any) => l.video as Video)) ?? []);

      // Subscribed channel videos
      const { data: subs } = await supabase
        .from('subscriptions')
        .select('channel_id')
        .eq('subscriber_id', channel.id);

      if (subs && subs.length > 0) {
        const channelIds = subs.map((s: any) => s.channel_id);
        const { data: subVids } = await supabase
          .from('videos')
          .select('*, channel:channels(*)')
          .in('channel_id', channelIds)
          .order('created_at', { ascending: false })
          .limit(20);
        setSubVideos((subVids as Video[]) ?? []);
      } else {
        setSubVideos([]);
      }

      setLoading(false);
    }

    fetchLibrary();
  }, [session, channel]);

  if (!session) {
    return (
      <div className="px-6 py-20 text-center">
        <PlaySquare className="w-16 h-16 text-gray-600 mx-auto mb-3" />
        <p className="text-white text-lg">Sign in to see your library</p>
        <button
          onClick={() => navigate({ name: 'signin' })}
          className="text-blue-400 mt-2 hover:underline"
        >
          Sign in
        </button>
      </div>
    );
  }

  const tabs = [
    { id: 'history' as const, label: 'Your videos', icon: History, videos: myVideos },
    { id: 'liked' as const, label: 'Liked videos', icon: ThumbsUp, videos: likedVideos },
    { id: 'subscriptions' as const, label: 'Subscriptions', icon: PlaySquare, videos: subVideos },
  ];

  const activeTab = tabs.find((t) => t.id === tab)!;

  return (
    <div className="px-6 py-4">
      <h1 className="text-white text-xl font-bold mb-6">Library</h1>

      <div className="flex gap-3 mb-6">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              tab === t.id
                ? 'bg-white text-black'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-video rounded-xl bg-white/10" />
              <div className="h-3 bg-white/10 rounded w-3/4 mt-3" />
            </div>
          ))}
        </div>
      ) : activeTab.videos.length === 0 ? (
        <div className="text-center py-20">
          <activeTab.icon className="w-16 h-16 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400">No videos here yet</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-8">
          {activeTab.videos.map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      )}
    </div>
  );
}
