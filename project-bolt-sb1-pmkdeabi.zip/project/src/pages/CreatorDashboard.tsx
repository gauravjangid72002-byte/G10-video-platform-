import { useState, useEffect, useMemo } from 'react';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Users,
  Eye,
  DollarSign,
  Video as VideoIcon,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Loader2,
  Wallet,
  Star,
  Play,
  ShieldAlert,
  CheckCircle2,
  Lock,
  Clock,
  Sparkles,
} from 'lucide-react';
import {
  supabase,
  type Video,
  type DailyAnalytics,
} from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { formatNumber, formatViews, formatTimeAgo } from '@/lib/format';

type TimeRange = '7d' | '30d' | '90d';

type ChartPoint = {
  date: string;
  label: string;
  value: number;
};

export function CreatorDashboard() {
  const { channel, session } = useAuth();
  const { navigate } = useRouter();
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<TimeRange>('30d');
  const [videos, setVideos] = useState<Video[]>([]);
  const [analytics, setAnalytics] = useState<DailyAnalytics[]>([]);
  const [subscriberCount, setSubscriberCount] = useState(0);
  const [totalViews, setTotalViews] = useState(0);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [availableBalance, setAvailableBalance] = useState(0);
  const [tipCount, setTipCount] = useState(0);
  const [ppvRevenue, setPpvRevenue] = useState(0);
  const [tipRevenue, setTipRevenue] = useState(0);
  const [likeCount, setLikeCount] = useState(0);
  const [watchTimeSeconds, setWatchTimeSeconds] = useState(0);
  const [monetizationStatus, setMonetizationStatus] = useState<string>('not_applied');
  const [applying, setApplying] = useState(false);
  const [applyError, setApplyError] = useState<string | null>(null);
  const [minSubs, setMinSubs] = useState(20);
  const [minWatchSeconds, setMinWatchSeconds] = useState(3600);

  useEffect(() => {
    if (!channel) {
      setLoading(false);
      return;
    }
    loadDashboard();
  }, [channel]);

  async function loadDashboard() {
    if (!channel) return;
    setLoading(true);

    // Fetch channel's videos
    const { data: vids } = await supabase
      .from('videos')
      .select('*')
      .eq('channel_id', channel.id)
      .order('created_at', { ascending: false });
    const channelVideos = (vids as Video[]) ?? [];
    setVideos(channelVideos);

    // Total views from videos
    const views = channelVideos.reduce((sum, v) => sum + (v.views ?? 0), 0);
    setTotalViews(Math.max(views, channel.lifetime_views ?? 0));

    // Subscriber count
    const { count: subs } = await supabase
      .from('subscriptions')
      .select('*', { count: 'exact', head: true })
      .eq('channel_id', channel.id);
    setSubscriberCount(subs ?? 0);

    // Earnings
    setTotalEarnings(channel.total_earnings ?? 0);
    setAvailableBalance(channel.available_balance ?? 0);

    // Tip revenue + count
    const { data: tips, count: tCount } = await supabase
      .from('tips')
      .select('amount', { count: 'exact' })
      .eq('tippee_id', channel.id);
    const tipRev = (tips ?? []).reduce((sum: number, t: any) => sum + (t.amount ?? 0), 0);
    setTipRevenue(tipRev);
    setTipCount(tCount ?? 0);

    // PPV revenue
    const { data: ppvPurchases } = await supabase
      .from('ppv_purchases')
      .select('price_paid, video:videos!ppv_purchases_video_id_fkey(channel_id)')
      .eq('video.channel_id', channel.id);
    const ppvRev = (ppvPurchases ?? []).reduce((sum: number, p: any) => sum + (p.price_paid ?? 0), 0);
    setPpvRevenue(ppvRev);

    // Total likes across all videos
    let likes = 0;
    if (channelVideos.length > 0) {
      const videoIds = channelVideos.map((v) => v.id);
      const { count: lCount } = await supabase
        .from('video_likes')
        .select('*', { count: 'exact', head: true })
        .in('video_id', videoIds);
      likes = lCount ?? 0;
    }
    setLikeCount(likes);

    // Watch time + monetization status
    setWatchTimeSeconds(channel.watch_time_seconds ?? 0);
    setMonetizationStatus(channel.monetization_status ?? 'not_applied');

    // Fetch dynamic monetization criteria
    const { data: criteria } = await supabase.rpc('get_monetization_criteria');
    if (criteria && criteria.length > 0) {
      setMinSubs(criteria[0].min_subscribers);
      setMinWatchSeconds(criteria[0].min_watch_time_seconds);
    }

    // Fetch analytics history
    const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
    const { data: analyticsData } = await supabase
      .from('daily_analytics')
      .select('*')
      .eq('channel_id', channel.id)
      .order('date', { ascending: true })
      .limit(days);
    setAnalytics((analyticsData as DailyAnalytics[]) ?? []);

    setLoading(false);
  }

  // Re-fetch analytics when time range changes
  useEffect(() => {
    if (!channel || loading) return;
    async function fetchAnalytics() {
      if (!channel) return;
      const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
      const { data } = await supabase
        .from('daily_analytics')
        .select('*')
        .eq('channel_id', channel.id)
        .order('date', { ascending: true })
        .limit(days);
      setAnalytics((data as DailyAnalytics[]) ?? []);
    }
    fetchAnalytics();
  }, [timeRange, channel]);

  // Generate chart data — use real analytics if available, otherwise generate from current totals
  const chartData = useMemo((): ChartPoint[] => {
    const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;

    if (analytics.length >= 2) {
      return analytics.map((a) => ({
        date: a.date,
        label: new Date(a.date).toLocaleDateString('en', { month: 'short', day: 'numeric' }),
        value: a.new_views,
      }));
    }

    // Generate synthetic trend data from current totals
    const points: ChartPoint[] = [];
    const baseViews = Math.max(Math.floor(totalViews / days), 10);
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const variance = Math.sin(i * 0.5) * 0.3 + (Math.random() - 0.5) * 0.2;
      const value = Math.max(0, Math.floor(baseViews * (1 + variance)));
      points.push({
        date: d.toISOString().split('T')[0],
        label: d.toLocaleDateString('en', { month: 'short', day: 'numeric' }),
        value,
      });
    }
    return points;
  }, [analytics, timeRange, totalViews]);

  // Calculate period stats
  const periodStats = useMemo(() => {
    const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
    const periodViews = chartData.reduce((sum, p) => sum + p.value, 0);
    const avgDailyViews = Math.floor(periodViews / days);

    // Estimate growth (compare first half vs second half)
    const half = Math.floor(chartData.length / 2);
    const firstHalf = chartData.slice(0, half).reduce((s, p) => s + p.value, 0);
    const secondHalf = chartData.slice(half).reduce((s, p) => s + p.value, 0);
    const growthPct = firstHalf > 0 ? ((secondHalf - firstHalf) / firstHalf) * 100 : 0;

    return { periodViews, avgDailyViews, growthPct };
  }, [chartData, timeRange]);

  // Chart rendering
  const maxChartValue = Math.max(...chartData.map((p) => p.value), 1);
  const chartWidth = 100;
  const chartHeight = 180;

  const linePath = useMemo(() => {
    if (chartData.length === 0) return '';
    const stepX = chartWidth / Math.max(chartData.length - 1, 1);
    return chartData
      .map((p, i) => {
        const x = i * stepX;
        const y = chartHeight - (p.value / maxChartValue) * (chartHeight - 20) - 10;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`;
      })
      .join(' ');
  }, [chartData, maxChartValue]);

  const areaPath = useMemo(() => {
    if (chartData.length === 0) return '';
    const stepX = chartWidth / Math.max(chartData.length - 1, 1);
    const line = chartData
      .map((p, i) => {
        const x = i * stepX;
        const y = chartHeight - (p.value / maxChartValue) * (chartHeight - 20) - 10;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`;
      })
      .join(' ');
    const lastX = (chartData.length - 1) * stepX;
    return `${line} L ${lastX.toFixed(2)} ${chartHeight} L 0 ${chartHeight} Z`;
  }, [chartData, maxChartValue]);

  // Top performing videos
  const topVideos = useMemo(() => {
    return [...videos].sort((a, b) => (b.views ?? 0) - (a.views ?? 0)).slice(0, 5);
  }, [videos]);

  if (!session || !channel) {
    return (
      <div className="px-6 py-20 text-center">
        <BarChart3 className="w-12 h-12 text-gray-600 mx-auto mb-3" />
        <p className="text-white text-lg">Sign in to view your Creator Dashboard</p>
        <button onClick={() => navigate({ name: 'signin' })} className="text-blue-400 mt-2 hover:underline">
          Sign in
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-blue-400 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-blue-600/20 rounded-xl flex items-center justify-center">
            <BarChart3 className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h1 className="text-white text-xl font-bold">Creator Dashboard</h1>
            <p className="text-gray-400 text-sm">{channel.name} — {channel.handle}</p>
          </div>
        </div>

        {/* Time range selector */}
        <div className="flex items-center gap-1 bg-white/5 rounded-xl p-1">
          {([
            { id: '7d' as TimeRange, label: '7 days' },
            { id: '30d' as TimeRange, label: '30 days' },
            { id: '90d' as TimeRange, label: '90 days' },
          ]).map((r) => (
            <button
              key={r.id}
              onClick={() => setTimeRange(r.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                timeRange === r.id ? 'bg-white/10 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <StatCard
          icon={<Eye className="w-5 h-5 text-blue-400" />}
          label="Total Views"
          value={formatViews(totalViews)}
          sub={`${formatNumber(periodStats.periodViews)} in ${timeRange}`}
          trend={periodStats.growthPct}
          color="blue"
        />
        <StatCard
          icon={<Users className="w-5 h-5 text-green-400" />}
          label="Subscribers"
          value={formatNumber(subscriberCount)}
          sub={`${videos.length} videos published`}
          color="green"
        />
        <StatCard
          icon={<DollarSign className="w-5 h-5 text-amber-400" />}
          label="Total Earnings"
          value={`$${(totalEarnings + tipRevenue + ppvRevenue).toFixed(2)}`}
          sub={`$${availableBalance.toFixed(2)} available`}
          color="amber"
        />
        <StatCard
          icon={<TrendingUp className="w-5 h-5 text-purple-400" />}
          label="Avg Daily Views"
          value={formatViews(periodStats.avgDailyViews)}
          sub={`${formatNumber(likeCount)} total likes`}
          color="purple"
        />
      </div>

      {/* Monetization Eligibility Card */}
      <MonetizationCard
        subscriberCount={subscriberCount}
        watchTimeSeconds={watchTimeSeconds}
        minSubs={minSubs}
        minWatchSeconds={minWatchSeconds}
        monetizationStatus={monetizationStatus}
        applying={applying}
        applyError={applyError}
        onApply={async () => {
          if (!channel) return;
          setApplying(true);
          setApplyError(null);
          const { error } = await supabase.rpc('apply_for_monetization', {
            target_channel_id: channel.id,
          });
          setApplying(false);
          if (error) {
            setApplyError(error.message);
          } else {
            setMonetizationStatus('pending');
          }
        }}
      />

      {/* Main chart */}
      <div className="bg-white/5 rounded-2xl border border-white/10 p-5 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-white text-sm font-bold">Views Over Time</h3>
            <p className="text-gray-400 text-xs mt-0.5">Last {timeRange === '7d' ? '7' : timeRange === '30d' ? '30' : '90'} days</p>
          </div>
          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-1 text-xs font-medium ${periodStats.growthPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {periodStats.growthPct >= 0 ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
              {Math.abs(periodStats.growthPct).toFixed(1)}%
            </div>
          </div>
        </div>

        {/* SVG chart */}
        <div className="relative">
          <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-[180px] overflow-visible" preserveAspectRatio="none">
            <defs>
              <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
              </linearGradient>
            </defs>

            {/* Grid lines */}
            {[0, 0.25, 0.5, 0.75, 1].map((t) => (
              <line
                key={t}
                x1="0"
                y1={chartHeight * t}
                x2={chartWidth}
                y2={chartHeight * t}
                stroke="rgba(255,255,255,0.05)"
                strokeWidth="0.2"
              />
            ))}

            {/* Area */}
            <path d={areaPath} fill="url(#areaGradient)" />

            {/* Line */}
            <path d={linePath} fill="none" stroke="#3b82f6" strokeWidth="0.5" strokeLinejoin="round" strokeLinecap="round" />

            {/* Data points */}
            {chartData.map((p, i) => {
              const stepX = chartWidth / Math.max(chartData.length - 1, 1);
              const x = i * stepX;
              const y = chartHeight - (p.value / maxChartValue) * (chartHeight - 20) - 10;
              return (
                <circle
                  key={i}
                  cx={x.toFixed(2)}
                  cy={y.toFixed(2)}
                  r="0.8"
                  fill="#3b82f6"
                  className="hover:r-2 transition-all"
                />
              );
            })}
          </svg>

          {/* X-axis labels (show first, middle, last) */}
          <div className="flex justify-between mt-2 text-gray-500 text-[10px]">
            <span>{chartData[0]?.label ?? ''}</span>
            {chartData.length > 2 && <span>{chartData[Math.floor(chartData.length / 2)]?.label ?? ''}</span>}
            <span>{chartData[chartData.length - 1]?.label ?? ''}</span>
          </div>
        </div>
      </div>

      {/* Two-column section: Earnings breakdown + Top videos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Earnings breakdown */}
        <div className="bg-white/5 rounded-2xl border border-white/10 p-5">
          <div className="flex items-center gap-2 mb-4">
            <Wallet className="w-5 h-5 text-amber-400" />
            <h3 className="text-white text-sm font-bold">Earnings Breakdown</h3>
          </div>

          <div className="space-y-3">
            {/* PPV Revenue */}
            <EarningRow
              label="Pay-Per-View Sales"
              amount={ppvRevenue}
              icon={<VideoIcon className="w-4 h-4 text-amber-400" />}
              color="amber"
            />
            {/* Tip Revenue */}
            <EarningRow
              label="Creator Tips"
              amount={tipRevenue}
              sub={`${tipCount} tips received`}
              icon={<Star className="w-4 h-4 text-pink-400" />}
              color="pink"
            />
            {/* Ad revenue estimate */}
            <EarningRow
              label="Estimated Ad Revenue"
              amount={totalViews * 0.002}
              sub="Based on $2 CPM"
              icon={<TrendingUp className="w-4 h-4 text-green-400" />}
              color="green"
            />

            {/* Divider */}
            <div className="h-px bg-white/10 my-2" />

            {/* Totals */}
            <div className="flex items-center justify-between">
              <span className="text-white text-sm font-medium">Total Earnings</span>
              <span className="text-white text-base font-bold">
                ${(ppvRevenue + tipRevenue + totalViews * 0.002).toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-xs">Available Balance</span>
              <span className="text-green-400 text-sm font-medium">${availableBalance.toFixed(2)}</span>
            </div>
          </div>

          {/* Mini bar chart for earnings distribution */}
          <div className="mt-4 pt-4 border-t border-white/10">
            <p className="text-gray-400 text-xs mb-3">Revenue Distribution</p>
            <div className="flex h-3 rounded-full overflow-hidden bg-white/5">
              {(() => {
                const total = ppvRevenue + tipRevenue + totalViews * 0.002;
                if (total === 0) return <div className="flex-1 bg-white/5" />;
                const ppvPct = (ppvRevenue / total) * 100;
                const tipPct = (tipRevenue / total) * 100;
                const adPct = 100 - ppvPct - tipPct;
                return (
                  <>
                    {ppvPct > 0 && <div className="bg-amber-500 transition-all" style={{ width: `${ppvPct}%` }} />}
                    {tipPct > 0 && <div className="bg-pink-500 transition-all" style={{ width: `${tipPct}%` }} />}
                    {adPct > 0 && <div className="bg-green-500 transition-all" style={{ width: `${adPct}%` }} />}
                  </>
                );
              })()}
            </div>
            <div className="flex items-center gap-4 mt-2 flex-wrap">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-gray-400 text-[10px]">PPV</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-pink-500" />
                <span className="text-gray-400 text-[10px]">Tips</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span className="text-gray-400 text-[10px]">Ads</span>
              </div>
            </div>
          </div>
        </div>

        {/* Top performing videos */}
        <div className="bg-white/5 rounded-2xl border border-white/10 p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Play className="w-5 h-5 text-blue-400" />
              <h3 className="text-white text-sm font-bold">Top Performing Videos</h3>
            </div>
            <button
              onClick={() => channel && navigate({ name: 'channel', channelId: channel.id })}
              className="text-blue-400 text-xs hover:underline"
            >
              View all
            </button>
          </div>

          {topVideos.length === 0 ? (
            <div className="text-center py-8">
              <VideoIcon className="w-8 h-8 text-gray-600 mx-auto mb-2" />
              <p className="text-gray-400 text-sm">No videos yet</p>
              <button
                onClick={() => navigate({ name: 'upload' })}
                className="text-blue-400 text-xs mt-2 hover:underline"
              >
                Upload your first video
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {topVideos.map((v, i) => (
                <button
                  key={v.id}
                  onClick={() => navigate({ name: 'watch', videoId: v.id })}
                  className="w-full flex items-center gap-3 group text-left"
                >
                  <span className="text-gray-500 text-sm font-bold w-5 flex-shrink-0">{i + 1}</span>
                  <div className="w-16 h-10 rounded-lg overflow-hidden bg-black flex-shrink-0">
                    {v.thumbnail_url ? (
                      <img src={v.thumbnail_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <VideoIcon className="w-4 h-4 text-gray-600" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-xs font-medium truncate group-hover:opacity-80">{v.title}</p>
                    <p className="text-gray-400 text-xs">{formatViews(v.views)} views — {formatTimeAgo(v.created_at)}</p>
                  </div>
                  {v.is_ppv && (
                    <span className="text-amber-400 text-[10px] px-1.5 py-0.5 bg-amber-500/10 rounded flex-shrink-0">PPV</span>
                  )}
                  {v.is_short && (
                    <span className="text-red-400 text-[10px] px-1.5 py-0.5 bg-red-500/10 rounded flex-shrink-0">Short</span>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <QuickAction
          icon={<VideoIcon className="w-5 h-5" />}
          label="Upload Video"
          onClick={() => navigate({ name: 'upload' })}
          color="bg-blue-600 hover:bg-blue-700"
        />
        <QuickAction
          icon={<Users className="w-5 h-5" />}
          label="View Channel"
          onClick={() => channel && navigate({ name: 'channel', channelId: channel.id })}
          color="bg-green-600 hover:bg-green-700"
        />
        <QuickAction
          icon={<ShieldAlert className="w-5 h-5" />}
          label="Copyright"
          onClick={() => navigate({ name: 'copyright' })}
          color="bg-purple-600 hover:bg-purple-700"
        />
        <QuickAction
          icon={<BarChart3 className="w-5 h-5" />}
          label="Analytics"
          onClick={() => loadDashboard()}
          color="bg-amber-600 hover:bg-amber-700"
        />
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  sub,
  trend,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub: string;
  trend?: number;
  color: string;
}) {
  const colorMap: Record<string, string> = {
    blue: 'bg-blue-600/20',
    green: 'bg-green-600/20',
    amber: 'bg-amber-600/20',
    purple: 'bg-purple-600/20',
  };
  return (
    <div className="bg-white/5 rounded-xl p-4 border border-white/10">
      <div className="flex items-center justify-between mb-3">
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${colorMap[color]}`}>
          {icon}
        </div>
        {trend !== undefined && (
          <div className={`flex items-center gap-0.5 text-xs font-medium ${trend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {trend >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
            {Math.abs(trend).toFixed(1)}%
          </div>
        )}
      </div>
      <p className="text-white text-xl font-bold">{value}</p>
      <p className="text-gray-400 text-xs mt-0.5">{label}</p>
      <p className="text-gray-500 text-xs mt-1">{sub}</p>
    </div>
  );
}

function EarningRow({
  label,
  amount,
  sub,
  icon,
  color,
}: {
  label: string;
  amount: number;
  sub?: string;
  icon: React.ReactNode;
  color: string;
}) {
  const colorMap: Record<string, string> = {
    amber: 'bg-amber-600/20',
    pink: 'bg-pink-600/20',
    green: 'bg-green-600/20',
  };
  return (
    <div className="flex items-center gap-3">
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${colorMap[color]}`}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-white text-sm font-medium">{label}</p>
        {sub && <p className="text-gray-400 text-xs">{sub}</p>}
      </div>
      <span className="text-white text-sm font-bold flex-shrink-0">${amount.toFixed(2)}</span>
    </div>
  );
}

function QuickAction({
  icon,
  label,
  onClick,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  color: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-3 rounded-xl text-white text-sm font-medium transition-colors ${color}`}
    >
      {icon}
      {label}
    </button>
  );
}

function MonetizationCard({
  subscriberCount,
  watchTimeSeconds,
  minSubs,
  minWatchSeconds,
  monetizationStatus,
  applying,
  applyError,
  onApply,
}: {
  subscriberCount: number;
  watchTimeSeconds: number;
  minSubs: number;
  minWatchSeconds: number;
  monetizationStatus: string;
  applying: boolean;
  applyError: string | null;
  onApply: () => void;
}) {
  const subProgress = Math.min((subscriberCount / minSubs) * 100, 100);
  const watchProgress = Math.min((watchTimeSeconds / minWatchSeconds) * 100, 100);
  const subsMet = subscriberCount >= minSubs;
  const watchMet = watchTimeSeconds >= minWatchSeconds;
  const isEligible = subsMet && watchMet;
  const canApply = isEligible && monetizationStatus === 'not_applied';

  function formatWatchTime(seconds: number): string {
    if (seconds < 60) return `${Math.floor(seconds)}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${Math.floor(seconds % 60)}s`;
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${h}h ${m}m`;
  }

  const statusBadges: Record<string, { label: string; color: string }> = {
    not_applied: { label: 'Not Applied', color: 'bg-white/10 text-gray-400' },
    pending: { label: 'Pending Review', color: 'bg-amber-500/20 text-amber-400' },
    approved: { label: 'Approved', color: 'bg-green-500/20 text-green-400' },
    rejected: { label: 'Rejected', color: 'bg-red-500/20 text-red-400' },
  };
  const statusBadge = statusBadges[monetizationStatus] ?? statusBadges.not_applied;

  return (
    <div className="bg-white/5 rounded-2xl border border-white/10 p-5 mb-6">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-green-600/20 rounded-lg flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-green-400" />
          </div>
          <div>
            <h3 className="text-white text-sm font-bold">Monetization Eligibility</h3>
            <p className="text-gray-400 text-xs mt-0.5">Meet these goals to unlock monetization features</p>
          </div>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusBadge.color}`}>
          {statusBadge.label}
        </span>
      </div>

      {/* Requirement 1: Subscribers */}
      <div className="mb-5">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            {subsMet ? (
              <CheckCircle2 className="w-4 h-4 text-green-400" />
            ) : (
              <Lock className="w-4 h-4 text-gray-500" />
            )}
            <span className="text-white text-sm font-medium">Subscribers</span>
            <span className="text-gray-400 text-xs">— need at least {minSubs}</span>
          </div>
          <span className={`text-sm font-bold ${subsMet ? 'text-green-400' : 'text-gray-300'}`}>
            {subscriberCount} / {minSubs}
          </span>
        </div>
        <div className="h-2.5 rounded-full bg-white/10 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${subsMet ? 'bg-green-500' : 'bg-blue-500'}`}
            style={{ width: `${subProgress}%` }}
          />
        </div>
      </div>

      {/* Requirement 2: Watch Time */}
      <div className="mb-5">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            {watchMet ? (
              <CheckCircle2 className="w-4 h-4 text-green-400" />
            ) : (
              <Lock className="w-4 h-4 text-gray-500" />
            )}
            <span className="text-white text-sm font-medium flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              Watch Time
            </span>
            <span className="text-gray-400 text-xs">— need at least {formatWatchTime(minWatchSeconds)}</span>
          </div>
          <span className={`text-sm font-bold ${watchMet ? 'text-green-400' : 'text-gray-300'}`}>
            {formatWatchTime(watchTimeSeconds)} / {formatWatchTime(minWatchSeconds)}
          </span>
        </div>
        <div className="h-2.5 rounded-full bg-white/10 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${watchMet ? 'bg-green-500' : 'bg-blue-500'}`}
            style={{ width: `${watchProgress}%` }}
          />
        </div>
      </div>

      {/* Error message */}
      {applyError && (
        <div className="mb-3 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
          {applyError}
        </div>
      )}

      {/* Apply button or status messages */}
      {monetizationStatus === 'not_applied' && (
        <button
          onClick={onApply}
          disabled={!canApply || applying}
          className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all ${
            canApply
              ? 'bg-green-600 text-white hover:bg-green-700 shadow-lg shadow-green-600/20'
              : 'bg-white/10 text-gray-500 cursor-not-allowed'
          }`}
        >
          {applying ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Submitting Application...
            </>
          ) : canApply ? (
            <>
              <CheckCircle2 className="w-4 h-4" />
              Apply for Monetization
            </>
          ) : (
            <>
              <Lock className="w-4 h-4" />
              Unlock at {minSubs} subscribers & {formatWatchTime(minWatchSeconds)} watch time
            </>
          )}
        </button>
      )}

      {monetizationStatus === 'pending' && (
        <div className="flex items-center gap-2 p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl">
          <Loader2 className="w-4 h-4 text-amber-400 animate-spin" />
          <p className="text-amber-400 text-sm">Your application is under review. We'll notify you once it's approved.</p>
        </div>
      )}

      {monetizationStatus === 'approved' && (
        <div className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/30 rounded-xl">
          <CheckCircle2 className="w-4 h-4 text-green-400" />
          <p className="text-green-400 text-sm">Congratulations! Your channel is monetized. You can now earn from PPV, tips, and ads.</p>
        </div>
      )}

      {monetizationStatus === 'rejected' && (
        <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-xl">
          <ShieldAlert className="w-4 h-4 text-red-400" />
          <p className="text-red-400 text-sm">Your application was rejected. Please review our guidelines and try again later.</p>
        </div>
      )}
    </div>
  );
}
