import { useState, useEffect } from 'react';
import { ThumbsUp, ThumbsDown, Share2, Download, Scissors, Check, ArrowLeft, Heart, Lock, Users, Headphones } from 'lucide-react';
import { VideoSummarizer } from '@/components/VideoSummarizer';
import { TipModal } from '@/components/TipModal';
import { PPVModal } from '@/components/PPVModal';
import { CreatePartyModal } from '@/components/CreatePartyModal';
import { ClipMemeMaker } from '@/components/ClipMemeMaker';
import { supabase, type Video, type Comment, type Channel } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { useAudio } from '@/context/AudioContext';
import { formatViews, formatTimeAgo, formatNumber } from '@/lib/format';
import { VideoCardCompact } from '@/components/VideoCard';

export function WatchPage({ videoId }: { videoId: string }) {
  const { session, channel } = useAuth();
  const { navigate } = useRouter();
  const { play, currentTrack, isPlaying: audioPlaying } = useAudio();
  const [video, setVideo] = useState<Video | null>(null);
  const [related, setRelated] = useState<Video[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [commentText, setCommentText] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [subscriberCount, setSubscriberCount] = useState(0);
  const [showDescription, setShowDescription] = useState(false);
  const [showTipModal, setShowTipModal] = useState(false);
  const [showPPVModal, setShowPPVModal] = useState(false);
  const [showPartyModal, setShowPartyModal] = useState(false);
  const [showClipMaker, setShowClipMaker] = useState(false);
  const [hasPurchased, setHasPurchased] = useState(false);
  const [tipCount, setTipCount] = useState(0);

  useEffect(() => {
    async function fetchVideo() {
      setLoading(true);

      const { data: v } = await supabase
        .from('videos')
        .select('*, channel:channels(*)')
        .eq('id', videoId)
        .maybeSingle();
      if (!v) {
        setLoading(false);
        return;
      }
      setVideo(v as Video);

      if (v) {
        // Increment views
        await supabase.rpc('increment_video_views', { video_uuid: videoId });

        // Fetch like count
        const { count: likes } = await supabase
          .from('video_likes')
          .select('*', { count: 'exact', head: true })
          .eq('video_id', videoId);
        setLikeCount(likes ?? 0);

        // Fetch comments
        const { data: coms } = await supabase
          .from('comments')
          .select('*, channel:channels(*)')
          .eq('video_id', videoId)
          .order('created_at', { ascending: false });
        setComments((coms as Comment[]) ?? []);

        // Fetch related videos
        const { data: rel } = await supabase
          .from('videos')
          .select('*, channel:channels(*)')
          .neq('id', videoId)
          .eq('category', v.category)
          .order('created_at', { ascending: false })
          .limit(10);
        setRelated((rel as Video[]) ?? []);

        // Fetch tip count
        const { count: tips } = await supabase
          .from('tips')
          .select('*', { count: 'exact', head: true })
          .eq('video_id', videoId);
        setTipCount(tips ?? 0);

        // Fetch subscriber count
        const { count: subs } = await supabase
          .from('subscriptions')
          .select('*', { count: 'exact', head: true })
          .eq('channel_id', v.channel_id);
        setSubscriberCount(subs ?? 0);

        // Check if user liked this video
        if (channel) {
          const { data: existingLike } = await supabase
            .from('video_likes')
            .select('id')
            .eq('video_id', videoId)
            .eq('channel_id', channel.id)
            .maybeSingle();
          setLiked(!!existingLike);

          const { data: existingSub } = await supabase
            .from('subscriptions')
            .select('id')
            .eq('subscriber_id', channel.id)
            .eq('channel_id', v.channel_id)
            .maybeSingle();
          setSubscribed(!!existingSub);

          if (v.is_ppv) {
            const { data: purchase } = await supabase
              .from('ppv_purchases')
              .select('id')
              .eq('video_id', videoId)
              .eq('buyer_id', channel.id)
              .maybeSingle();
            setHasPurchased(!!purchase);
          }
        }
      }

      setLoading(false);
    }
    fetchVideo();
  }, [videoId, channel]);

  async function toggleLike() {
    if (!channel || !video) return;
    if (liked) {
      await supabase.from('video_likes').delete().eq('video_id', videoId).eq('channel_id', channel.id);
      setLiked(false);
      setLikeCount((c) => c - 1);
    } else {
      await supabase.from('video_likes').insert({ video_id: videoId, channel_id: channel.id });
      setLiked(true);
      setLikeCount((c) => c + 1);
    }
  }

  async function toggleSubscribe() {
    if (!channel || !video) return;
    if (channel.id === video.channel_id) return;
    if (subscribed) {
      await supabase
        .from('subscriptions')
        .delete()
        .eq('subscriber_id', channel.id)
        .eq('channel_id', video.channel_id);
      setSubscribed(false);
      setSubscriberCount((c) => c - 1);
    } else {
      await supabase
        .from('subscriptions')
        .insert({ subscriber_id: channel.id, channel_id: video.channel_id });
      setSubscribed(true);
      setSubscriberCount((c) => c + 1);
    }
  }

  async function postComment(e: React.FormEvent) {
    e.preventDefault();
    if (!channel || !commentText.trim()) return;
    const { data } = await supabase
      .from('comments')
      .insert({ video_id: videoId, channel_id: channel.id, text: commentText.trim() })
      .select('*, channel:channels(*)')
      .single();
    if (data) {
      setComments((c) => [data as Comment, ...c]);
      setCommentText('');
    }
  }

  if (loading) {
    return (
      <div className="px-6 py-4 animate-pulse">
        <div className="aspect-video max-w-4xl rounded-xl bg-white/10" />
        <div className="h-6 bg-white/10 rounded w-2/3 mt-4 max-w-4xl" />
        <div className="h-4 bg-white/10 rounded w-1/3 mt-2 max-w-4xl" />
      </div>
    );
  }

  if (!video) {
    return (
      <div className="px-6 py-20 text-center">
        <p className="text-white text-lg">Video not found</p>
        <button onClick={() => navigate({ name: 'home' })} className="text-blue-400 mt-2 hover:underline">
          Go home
        </button>
      </div>
    );
  }

  const isOwner = channel?.id === video.channel_id;
  const isPPV = video.is_ppv === true;
  const isLocked = isPPV && !isOwner && !hasPurchased;

  return (
    <div className="px-2 sm:px-4 lg:px-6 py-4 flex flex-col xl:flex-row gap-6 max-w-[1800px]">
      <div className="flex-1 min-w-0">
        <button
          onClick={() => navigate({ name: 'home' })}
          className="flex items-center gap-2 text-gray-400 hover:text-white mb-3 text-sm"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </button>

        <div className="aspect-video rounded-xl overflow-hidden bg-black relative">
          {isLocked ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 z-10">
              {video.thumbnail_url && (
                <img src={video.thumbnail_url} alt="" className="absolute inset-0 w-full h-full object-cover opacity-20" />
              )}
              <div className="relative z-10 flex flex-col items-center">
                <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mb-4 border border-amber-500/30">
                  <Lock className="w-8 h-8 text-amber-400" />
                </div>
                <p className="text-white text-lg font-bold mb-1">This is exclusive content</p>
                <p className="text-gray-400 text-sm mb-4">Unlock to watch the full video</p>
                <button
                  onClick={() => setShowPPVModal(true)}
                  className="flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-500 text-black text-sm font-bold hover:bg-amber-400 transition-colors"
                >
                  <Lock className="w-4 h-4" />
                  Unlock for ${(video.ppv_price ?? 0).toFixed(2)}
                </button>
              </div>
            </div>
          ) : (
            <video
              src={video.video_url}
              controls
              autoPlay
              className="w-full h-full"
              poster={video.thumbnail_url ?? undefined}
            />
          )}
        </div>

        <div className="flex items-center gap-2 flex-wrap mt-1">
          <h1 className="text-white text-lg sm:text-xl font-bold">{video.title}</h1>
          {isPPV && (
            <span className="flex items-center gap-1 px-2 py-0.5 bg-amber-500/20 text-amber-400 text-xs font-medium rounded">
              <Lock className="w-3 h-3" />
              ${(video.ppv_price ?? 0).toFixed(2)}
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 mt-2">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate({ name: 'channel', channelId: video.channel_id })}
              className="flex items-center gap-3 group"
            >
              <div className="w-10 h-10 rounded-full overflow-hidden bg-white/10 flex-shrink-0">
                {video.channel?.avatar_url && (
                  <img src={video.channel.avatar_url} alt="" className="w-full h-full object-cover" />
                )}
              </div>
              <div className="text-left">
                <p className="text-white text-sm font-medium group-hover:opacity-80">{video.channel?.name}</p>
                <p className="text-gray-400 text-xs">{formatNumber(subscriberCount)} subscribers</p>
              </div>
            </button>
            {!isOwner && (
              <button
                onClick={toggleSubscribe}
                disabled={!session}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  subscribed
                    ? 'bg-white/10 text-white hover:bg-white/20'
                    : 'bg-white text-black hover:bg-white/90'
                } ${!session ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {subscribed ? 'Subscribed' : 'Subscribe'}
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center bg-white/10 rounded-full overflow-hidden">
              <button
                onClick={toggleLike}
                disabled={!session}
                className={`flex items-center gap-2 px-4 py-2 hover:bg-white/10 transition-colors ${!session ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <ThumbsUp className={`w-5 h-5 ${liked ? 'fill-white text-white' : 'text-white'}`} />
                <span className="text-white text-sm">{formatNumber(likeCount)}</span>
              </button>
              <div className="w-px h-6 bg-white/20" />
              <button
                disabled={!session}
                className={`px-4 py-2 hover:bg-white/10 transition-colors ${!session ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <ThumbsDown className="w-5 h-5 text-white" />
              </button>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
              <Share2 className="w-5 h-5 text-white" />
              <span className="text-white text-sm hidden sm:block">Share</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
              <Download className="w-5 h-5 text-white" />
              <span className="text-white text-sm hidden sm:block">Download</span>
            </button>
            <button
              onClick={() => setShowClipMaker(true)}
              disabled={!session}
              className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors ${
                session ? 'bg-orange-600/20 hover:bg-orange-600/30 border border-orange-500/30' : 'bg-white/10 opacity-50 cursor-not-allowed'
              }`}
            >
              <Scissors className="w-5 h-5 text-orange-400" />
              <span className="text-orange-400 text-sm font-medium hidden sm:block">Clip</span>
            </button>
            <button
              onClick={() => {
                if (!video) return;
                play({
                  url: video.video_url,
                  title: video.title,
                  channelName: video.channel?.name ?? 'Unknown',
                  videoId: video.id,
                });
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors ${
                currentTrack?.videoId === video?.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
              title="Continue playing audio in background while browsing"
            >
              <Headphones className={`w-5 h-5 ${currentTrack?.videoId === video?.id && audioPlaying ? 'animate-pulse' : ''}`} />
              <span className="text-sm font-medium hidden sm:block">
                {currentTrack?.videoId === video?.id && audioPlaying ? 'Playing' : 'Background Audio'}
              </span>
            </button>
            <button
              onClick={() => setShowPartyModal(true)}
              disabled={!session}
              className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors ${
                session ? 'bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30' : 'bg-white/10 opacity-50 cursor-not-allowed'
              }`}
            >
              <Users className="w-5 h-5 text-purple-400" />
              <span className="text-purple-400 text-sm font-medium hidden sm:block">Watch Party</span>
            </button>
            {!isOwner && (
              <button
                onClick={() => setShowTipModal(true)}
                disabled={!session}
                className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors ${
                  session ? 'bg-pink-600/20 hover:bg-pink-600/30 border border-pink-500/30' : 'bg-white/10 opacity-50 cursor-not-allowed'
                }`}
              >
                <Heart className="w-5 h-5 text-pink-400 fill-pink-400" />
                <span className="text-pink-400 text-sm font-medium hidden sm:block">Tip</span>
                {tipCount > 0 && <span className="text-pink-400/60 text-xs">{tipCount}</span>}
              </button>
            )}
          </div>
        </div>

        <div className="mt-3 bg-white/5 rounded-xl p-3">
          <div className="flex items-center gap-3 text-xs text-gray-300 mb-2">
            <span className="font-medium text-white">{formatViews(video.views)}</span>
            <span>{formatTimeAgo(video.created_at)}</span>
            <span className="px-2 py-0.5 bg-white/10 rounded">{video.category}</span>
          </div>
          <p className={`text-white text-sm whitespace-pre-wrap ${showDescription ? '' : 'line-clamp-2'}`}>
            {video.description || 'No description provided.'}
          </p>
          {video.description && video.description.length > 100 && (
            <button
              onClick={() => setShowDescription(!showDescription)}
              className="text-gray-300 text-sm font-medium mt-1 hover:text-white"
            >
              {showDescription ? 'Show less' : '...more'}
            </button>
          )}
        </div>

        <VideoSummarizer videoId={videoId} />

        <div className="mt-6">
          <h2 className="text-white text-lg font-medium mb-4">
            {comments.length} Comments
          </h2>
          {session ? (
            <form onSubmit={postComment} className="flex gap-3 mb-6">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-white/10 flex-shrink-0">
                {channel?.avatar_url && (
                  <img src={channel.avatar_url} alt="" className="w-full h-full object-cover" />
                )}
              </div>
              <div className="flex-1">
                <input
                  type="text"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Add a comment..."
                  className="w-full bg-transparent border-b border-white/20 px-1 py-2 text-white text-sm focus:outline-none focus:border-white"
                />
                {commentText && (
                  <div className="flex justify-end gap-2 mt-2">
                    <button
                      type="button"
                      onClick={() => setCommentText('')}
                      className="px-3 py-1.5 rounded-full text-white text-sm hover:bg-white/10"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded-full bg-blue-600 text-white text-sm hover:bg-blue-700"
                    >
                      Comment
                    </button>
                  </div>
                )}
              </div>
            </form>
          ) : (
            <p className="text-gray-400 text-sm mb-6">Sign in to leave a comment.</p>
          )}

          <div className="space-y-4">
            {comments.map((comment) => (
              <div key={comment.id} className="flex gap-3">
                <button
                  onClick={() => navigate({ name: 'channel', channelId: comment.channel_id })}
                  className="w-10 h-10 rounded-full overflow-hidden bg-white/10 flex-shrink-0"
                >
                  {comment.channel?.avatar_url && (
                    <img src={comment.channel.avatar_url} alt="" className="w-full h-full object-cover" />
                  )}
                </button>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => navigate({ name: 'channel', channelId: comment.channel_id })}
                      className="text-white text-sm font-medium hover:opacity-80"
                    >
                      {comment.channel?.name}
                    </button>
                    <span className="text-gray-400 text-xs">{formatTimeAgo(comment.created_at)}</span>
                  </div>
                  <p className="text-white text-sm mt-1">{comment.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="xl:w-[400px] flex-shrink-0">
        <h2 className="text-white text-base font-medium mb-3">Related videos</h2>
        <div className="space-y-2">
          {related.map((rv) => (
            <VideoCardCompact key={rv.id} video={rv} />
          ))}
        </div>
      </div>

      {showTipModal && (
        <TipModal
          videoId={videoId}
          channelName={video.channel?.name ?? 'this creator'}
          onClose={() => setShowTipModal(false)}
        />
      )}

      {showPPVModal && (
        <PPVModal
          videoId={videoId}
          videoTitle={video.title}
          channelName={video.channel?.name ?? 'this creator'}
          price={video.ppv_price ?? 0}
          thumbnailUrl={video.thumbnail_url}
          onUnlocked={() => setHasPurchased(true)}
          onClose={() => setShowPPVModal(false)}
        />
      )}

      {showPartyModal && (
        <CreatePartyModal
          videoId={videoId}
          videoTitle={video.title}
          onClose={() => setShowPartyModal(false)}
        />
      )}

      {showClipMaker && (
        <ClipMemeMaker
          videoUrl={video.video_url}
          videoTitle={video.title}
          onClose={() => setShowClipMaker(false)}
        />
      )}
    </div>
  );
}
