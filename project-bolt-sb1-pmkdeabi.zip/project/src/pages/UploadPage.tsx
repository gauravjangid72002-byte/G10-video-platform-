import { useState } from 'react';
import { Upload, X, Loader2, Lock, DollarSign, ShieldCheck } from 'lucide-react';
import { supabase, CATEGORIES } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { ContentCheckModal } from '@/components/ContentCheckModal';

export function UploadPage() {
  const { channel, session } = useAuth();
  const { navigate } = useRouter();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Technology');
  const [videoUrl, setVideoUrl] = useState('');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [isPPV, setIsPPV] = useState(false);
  const [ppvPrice, setPpvPrice] = useState(2.99);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showContentCheck, setShowContentCheck] = useState(false);
  const [contentCheckPassed, setContentCheckPassed] = useState(false);

  if (!session || !channel) {
    return (
      <div className="px-6 py-20 text-center">
        <p className="text-white text-lg">Please sign in to upload videos</p>
        <button
          onClick={() => navigate({ name: 'signin' })}
          className="text-blue-400 mt-2 hover:underline"
        >
          Sign in
        </button>
      </div>
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim() || !videoUrl.trim() || !channel) return;

    // Run content check before upload
    if (!contentCheckPassed) {
      setShowContentCheck(true);
      return;
    }

    setUploading(true);
    setError(null);

    const { data, error: insertError } = await supabase
      .from('videos')
      .insert({
        channel_id: channel.id,
        title: title.trim(),
        description: description.trim(),
        video_url: videoUrl.trim(),
        thumbnail_url: thumbnailUrl.trim() || null,
        category,
        is_ppv: isPPV,
        ppv_price: isPPV ? ppvPrice : 0,
      })
      .select('id')
      .single();

    setUploading(false);

    if (insertError) {
      setError(insertError.message);
      return;
    }

    if (data) {
      navigate({ name: 'watch', videoId: data.id });
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-8">
      <h1 className="text-white text-2xl font-bold mb-6">Upload a video</h1>

      {error && (
        <div className="mb-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 text-sm">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="border-2 border-dashed border-white/20 rounded-xl p-8 text-center">
          <Upload className="w-12 h-12 text-gray-500 mx-auto mb-3" />
          <p className="text-white text-sm font-medium">Video URL</p>
          <p className="text-gray-400 text-xs mt-1 mb-4">Paste a direct video URL (mp4, webm, etc.)</p>
          <input
            type="url"
            value={videoUrl}
            onChange={(e) => setVideoUrl(e.target.value)}
            placeholder="https://example.com/video.mp4"
            required
            className="w-full max-w-md bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-white text-sm font-medium mb-2">Thumbnail URL (optional)</label>
          <input
            type="url"
            value={thumbnailUrl}
            onChange={(e) => setThumbnailUrl(e.target.value)}
            placeholder="https://example.com/thumbnail.jpg"
            className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
          />
          {thumbnailUrl && (
            <div className="mt-3 relative inline-block">
              <img
                src={thumbnailUrl}
                alt="Thumbnail preview"
                className="w-64 aspect-video rounded-lg object-cover"
              />
              <button
                type="button"
                onClick={() => setThumbnailUrl('')}
                className="absolute top-2 right-2 bg-black/70 rounded-full p-1"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          )}
        </div>

        <div>
          <label className="block text-white text-sm font-medium mb-2">Title <span className="text-red-400">*</span></label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Enter video title"
            required
            maxLength={100}
            className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
          />
          <p className="text-gray-500 text-xs mt-1">{title.length}/100</p>
        </div>

        <div>
          <label className="block text-white text-sm font-medium mb-2">Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Tell viewers about your video"
            rows={4}
            maxLength={5000}
            className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500 resize-none"
          />
        </div>

        <div>
          <label className="block text-white text-sm font-medium mb-2">Category</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
          >
            {CATEGORIES.filter((c) => c !== 'All').map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        {/* Pay-Per-View toggle */}
        <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-amber-500/20 rounded-lg flex items-center justify-center">
                <Lock className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <p className="text-white text-sm font-medium">Exclusive content</p>
                <p className="text-gray-400 text-xs">Lock this video behind a pay-per-view payment</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsPPV(!isPPV)}
              className={`relative w-11 h-6 rounded-full transition-colors ${isPPV ? 'bg-amber-500' : 'bg-white/20'}`}
            >
              <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${isPPV ? 'translate-x-5' : 'translate-x-0.5'}`} />
            </button>
          </div>

          {isPPV && (
            <div className="pt-2 border-t border-white/10">
              <label className="block text-white text-xs font-medium mb-2 uppercase tracking-wide">Unlock price (USD)</label>
              <div className="relative max-w-[160px]">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type="number"
                  min={0.99}
                  step={0.01}
                  value={ppvPrice}
                  onChange={(e) => setPpvPrice(Math.max(0.99, parseFloat(e.target.value) || 0))}
                  className="w-full bg-[#121212] border border-white/10 rounded-lg pl-9 pr-4 py-2 text-white text-sm focus:outline-none focus:border-amber-500"
                />
              </div>
              <p className="text-gray-500 text-xs mt-2">Viewers will see a lock overlay and pay this price to watch.</p>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate({ name: 'home' })}
            className="px-5 py-2.5 rounded-full bg-white/10 text-white text-sm font-medium hover:bg-white/20"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={uploading || !title.trim() || !videoUrl.trim()}
            className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {uploading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Uploading...
              </>
            ) : contentCheckPassed ? (
              'Publish video'
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                Check & Publish
              </>
            )}
          </button>
        </div>
      </form>

      {showContentCheck && (
        <ContentCheckModal
          title={title.trim()}
          videoUrl={videoUrl.trim()}
          onProceed={() => {
            setContentCheckPassed(true);
            setShowContentCheck(false);
          }}
          onBlock={() => {
            setShowContentCheck(false);
            setError('Upload cancelled due to content match. Review the matches and try again.');
          }}
          onClose={() => setShowContentCheck(false)}
        />
      )}
    </div>
  );
}
