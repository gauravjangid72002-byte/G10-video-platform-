import { useState, useEffect, useRef, useCallback } from 'react';
import {
  ArrowLeft,
  Users,
  Send,
  Play,
  Pause,
  Copy,
  Check,
  Loader2,
  Radio,
} from 'lucide-react';
import { supabase, type Video, type WatchPartyRoom, type WatchPartyMessage, type Channel } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { formatTimeAgo } from '@/lib/format';

export function WatchPartyPage({ roomId }: { roomId: string }) {
  const { channel, session } = useAuth();
  const { navigate } = useRouter();
  const [room, setRoom] = useState<WatchPartyRoom | null>(null);
  const [video, setVideo] = useState<Video | null>(null);
  const [messages, setMessages] = useState<WatchPartyMessage[]>([]);
  const [messageText, setMessageText] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [isHost, setIsHost] = useState(false);
  const [syncIndicator, setSyncIndicator] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const syncIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastSyncPushRef = useRef<number>(0);

  // Load room + video + messages
  useEffect(() => {
    async function loadRoom() {
      setLoading(true);
      const { data: roomData, error: roomErr } = await supabase
        .from('watch_party_rooms')
        .select('*')
        .eq('id', roomId)
        .maybeSingle();

      if (roomErr || !roomData) {
        // Try by room_code
        const { data: roomByCode } = await supabase
          .from('watch_party_rooms')
          .select('*')
          .eq('room_code', roomId.toUpperCase())
          .maybeSingle();

        if (!roomByCode) {
          setError('Watch party room not found.');
          setLoading(false);
          return;
        }
        const r = roomByCode as WatchPartyRoom;
        setRoom(r);
        setIsHost(channel?.id === r.host_id);
        loadVideoAndMessages(r);
        return;
      }

      const r = roomData as WatchPartyRoom;
      setRoom(r);
      setIsHost(channel?.id === r.host_id);
      loadVideoAndMessages(r);
    }

    async function loadVideoAndMessages(r: WatchPartyRoom) {
      const { data: v } = await supabase
        .from('videos')
        .select('*, channel:channels(*)')
        .eq('id', r.video_id)
        .maybeSingle();
      setVideo(v as Video);

      const { data: msgs } = await supabase
        .from('watch_party_messages')
        .select('*, sender:channels!watch_party_messages_sender_id_fkey(*)')
        .eq('room_id', r.id)
        .order('created_at', { ascending: true });
      setMessages((msgs as WatchPartyMessage[]) ?? []);
      setLoading(false);
    }

    loadRoom();
  }, [roomId, channel]);

  // Realtime: listen for room state changes (playback sync)
  useEffect(() => {
    if (!room) return;

    const channelSub = supabase
      .channel(`room-${room.id}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'watch_party_rooms', filter: `id=eq.${room.id}` },
        (payload) => {
          const updated = payload.new as WatchPartyRoom;
          setRoom(updated);
          setSyncIndicator(true);
          setTimeout(() => setSyncIndicator(false), 1000);

          // Sync local video player
          const vid = videoRef.current;
          if (vid && !isHost) {
            if (Math.abs(vid.currentTime - updated.playback_time) > 2) {
              vid.currentTime = updated.playback_time;
            }
            if (updated.is_playing && vid.paused) {
              vid.play().catch(() => {});
            } else if (!updated.is_playing && !vid.paused) {
              vid.pause();
            }
          }
        }
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'watch_party_messages', filter: `room_id=eq.${room.id}` },
        async (payload) => {
          const newMsg = payload.new as WatchPartyMessage;
          // Fetch sender info
          const { data: sender } = await supabase
            .from('channels')
            .select('*')
            .eq('id', newMsg.sender_id)
            .maybeSingle();
          setMessages((prev) => [...prev, { ...newMsg, sender: sender as Channel }]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channelSub);
    };
  }, [room, isHost]);

  // Host: periodically push playback state
  useEffect(() => {
    if (!room || !isHost) return;

    syncIntervalRef.current = setInterval(() => {
      const vid = videoRef.current;
      if (!vid) return;
      const now = Date.now();
      if (now - lastSyncPushRef.current < 3000) return;
      lastSyncPushRef.current = now;

      supabase
        .from('watch_party_rooms')
        .update({
          playback_time: vid.currentTime,
          is_playing: !vid.paused,
          last_sync_at: new Date().toISOString(),
        })
        .eq('id', room.id);
    }, 3000);

    return () => {
      if (syncIntervalRef.current) clearInterval(syncIntervalRef.current);
    };
  }, [room, isHost]);

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Host playback event handlers — push state on play/pause/seek
  const handlePlay = useCallback(() => {
    if (!room || !isHost) return;
    const vid = videoRef.current;
    supabase
      .from('watch_party_rooms')
      .update({ is_playing: true, playback_time: vid?.currentTime ?? 0, last_sync_at: new Date().toISOString() })
      .eq('id', room.id);
  }, [room, isHost]);

  const handlePause = useCallback(() => {
    if (!room || !isHost) return;
    const vid = videoRef.current;
    supabase
      .from('watch_party_rooms')
      .update({ is_playing: false, playback_time: vid?.currentTime ?? 0, last_sync_at: new Date().toISOString() })
      .eq('id', room.id);
  }, [room, isHost]);

  const handleSeek = useCallback(() => {
    if (!room || !isHost) return;
    const vid = videoRef.current;
    supabase
      .from('watch_party_rooms')
      .update({ playback_time: vid?.currentTime ?? 0, is_playing: !(vid?.paused ?? true), last_sync_at: new Date().toISOString() })
      .eq('id', room.id);
  }, [room, isHost]);

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!channel || !room || !messageText.trim()) return;
    const text = messageText.trim();
    setMessageText('');

    const { data } = await supabase
      .from('watch_party_messages')
      .insert({ room_id: room.id, sender_id: channel.id, text })
      .select('*, sender:channels!watch_party_messages_sender_id_fkey(*)')
      .single();

    if (data) {
      setMessages((prev) => [...prev, data as WatchPartyMessage]);
    }
  }

  function copyRoomCode() {
    if (room) {
      navigator.clipboard.writeText(room.room_code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  if (loading) {
    return (
      <div className="px-6 py-4 animate-pulse">
        <div className="aspect-video max-w-4xl rounded-xl bg-white/10" />
        <div className="h-6 bg-white/10 rounded w-2/3 mt-4 max-w-4xl" />
      </div>
    );
  }

  if (error || !room || !video) {
    return (
      <div className="px-6 py-20 text-center">
        <p className="text-white text-lg">{error || 'Room not found'}</p>
        <button onClick={() => navigate({ name: 'home' })} className="text-purple-400 mt-2 hover:underline">
          Go home
        </button>
      </div>
    );
  }

  return (
    <div className="px-2 sm:px-4 lg:px-6 py-4 flex flex-col xl:flex-row gap-6 max-w-[1800px]">
      <div className="flex-1 min-w-0">
        {/* Top bar */}
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => navigate({ name: 'home' })}
            className="flex items-center gap-2 text-gray-400 hover:text-white text-sm"
          >
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium ${
              syncIndicator ? 'bg-green-600/20 text-green-400' : 'bg-white/10 text-gray-400'
            }`}>
              <Radio className={`w-3.5 h-3.5 ${syncIndicator ? 'animate-pulse' : ''}`} />
              {syncIndicator ? 'Syncing' : 'Connected'}
            </div>
          </div>
        </div>

        {/* Video player */}
        <div className="aspect-video rounded-xl overflow-hidden bg-black relative">
          <video
            ref={videoRef}
            src={video.video_url}
            controls
            onPlay={handlePlay}
            onPause={handlePause}
            onSeeked={handleSeek}
            className="w-full h-full"
            poster={video.thumbnail_url ?? undefined}
          />
          {syncIndicator && (
            <div className="absolute top-3 right-3 px-3 py-1.5 bg-purple-600/80 backdrop-blur-sm rounded-full text-white text-xs font-medium flex items-center gap-1.5 animate-pulse">
              <Radio className="w-3 h-3" />
              Syncing playback...
            </div>
          )}
        </div>

        {/* Title + room info */}
        <h1 className="text-white text-lg sm:text-xl font-bold mt-3">{video.title}</h1>

        <div className="flex flex-wrap items-center gap-3 mt-3 bg-gradient-to-r from-purple-900/30 to-[#1a1a1a] border border-purple-500/20 rounded-xl p-4">
          <div className="w-10 h-10 bg-purple-600/20 rounded-lg flex items-center justify-center flex-shrink-0">
            <Users className="w-5 h-5 text-purple-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-medium">Watch Party Room</p>
            <p className="text-gray-400 text-xs">
              {isHost ? "You're the host — your playback controls sync to everyone." : 'Following host playback'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="px-4 py-2 bg-[#121212] border border-purple-500/30 rounded-lg">
              <span className="text-purple-400 text-lg font-bold tracking-[0.2em]">{room.room_code}</span>
            </div>
            <button
              onClick={copyRoomCode}
              className="p-2.5 bg-white/10 rounded-lg hover:bg-white/20 transition-colors"
              title="Copy room code"
            >
              {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-gray-300" />}
            </button>
          </div>
        </div>

        {/* Video meta */}
        <div className="mt-3 bg-white/5 rounded-xl p-3">
          <div className="flex items-center gap-3 text-xs text-gray-300 mb-2">
            <span className="px-2 py-0.5 bg-white/10 rounded">{video.category}</span>
            <span>{video.channel?.name}</span>
          </div>
          <p className="text-white text-sm">{video.description || 'No description provided.'}</p>
        </div>
      </div>

      {/* Live chat sidebar */}
      <div className="xl:w-[360px] flex-shrink-0 flex flex-col bg-[#1a1a1a] rounded-xl border border-white/10 h-[calc(100vh-100px)] sticky top-16">
        <div className="px-4 py-3 border-b border-white/10 flex items-center gap-2">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
          <h3 className="text-white text-sm font-bold">Live Chat</h3>
          <span className="text-gray-500 text-xs ml-auto">{messages.length} messages</span>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3 scrollbar-thin">
          {messages.length === 0 && (
            <div className="text-center py-8">
              <Send className="w-8 h-8 text-gray-600 mx-auto mb-2" />
              <p className="text-gray-500 text-sm">No messages yet</p>
              <p className="text-gray-600 text-xs mt-1">Be the first to say hi!</p>
            </div>
          )}
          {messages.map((msg) => {
            const isOwn = msg.sender_id === channel?.id;
            return (
              <div key={msg.id} className={`flex gap-2 ${isOwn ? 'flex-row-reverse' : ''}`}>
                <button
                  onClick={() => msg.sender_id && navigate({ name: 'channel', channelId: msg.sender_id })}
                  className="w-8 h-8 rounded-full overflow-hidden bg-white/10 flex-shrink-0"
                >
                  {msg.sender?.avatar_url && (
                    <img src={msg.sender.avatar_url} alt="" className="w-full h-full object-cover" />
                  )}
                </button>
                <div className={`flex-1 min-w-0 ${isOwn ? 'text-right' : ''}`}>
                  <div className={`flex items-center gap-2 ${isOwn ? 'justify-end' : ''}`}>
                    <span className="text-white text-xs font-medium">{msg.sender?.name ?? 'Unknown'}</span>
                    <span className="text-gray-500 text-[10px]">{formatTimeAgo(msg.created_at)}</span>
                  </div>
                  <p className={`text-sm mt-0.5 inline-block px-3 py-1.5 rounded-lg ${
                    isOwn ? 'bg-purple-600/30 text-purple-100' : 'bg-white/5 text-gray-200'
                  }`}>
                    {msg.text}
                  </p>
                </div>
              </div>
            );
          })}
          <div ref={chatEndRef} />
        </div>

        {/* Message input */}
        {session ? (
          <form onSubmit={sendMessage} className="px-3 py-3 border-t border-white/10 flex gap-2">
            <input
              type="text"
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Send a message..."
              maxLength={500}
              className="flex-1 bg-[#121212] border border-white/10 rounded-full px-4 py-2 text-white text-sm focus:outline-none focus:border-purple-500"
            />
            <button
              type="submit"
              disabled={!messageText.trim()}
              className="p-2 bg-purple-600 rounded-full hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex-shrink-0"
            >
              <Send className="w-4 h-4 text-white" />
            </button>
          </form>
        ) : (
          <div className="px-4 py-3 border-t border-white/10">
            <p className="text-gray-400 text-xs text-center">Sign in to chat</p>
          </div>
        )}
      </div>
    </div>
  );
}
