import { AuthProvider, useAuth } from '@/context/AuthContext';
import { RouterProvider, useRouter } from '@/context/RouterContext';
import { AudioProvider, useAudio } from '@/context/AudioContext';
import { Header } from '@/components/Header';
import { Sidebar } from '@/components/Sidebar';
import { AudioMiniPlayer } from '@/components/AudioMiniPlayer';
import { HomePage } from '@/pages/HomePage';
import { WatchPage } from '@/pages/WatchPage';
import { ChannelPage } from '@/pages/ChannelPage';
import { UploadPage } from '@/pages/UploadPage';
import { SearchPage } from '@/pages/SearchPage';
import { AuthPage } from '@/pages/AuthPage';
import { LibraryPage } from '@/pages/LibraryPage';
import { WatchPartyPage } from '@/pages/WatchPartyPage';
import { ShortsPage } from '@/pages/ShortsPage';
import { CopyrightDashboard } from '@/pages/CopyrightDashboard';
import { CreatorDashboard } from '@/pages/CreatorDashboard';
import { AdminPage } from '@/pages/AdminPage';

function AppContent() {
  const { page, sidebarOpen } = useRouter();
  const { loading } = useAuth();

  if (page.name === 'signin' || page.name === 'signup') {
    return <AuthPage mode={page.name} />;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0f0f0f] flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-white/20 border-t-white rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f0f0f]">
      <Header />
      <Sidebar />
      <main className={`pt-14 ${sidebarOpen ? 'ml-60' : 'ml-[72px]'} transition-all duration-200`}>
        {page.name === 'home' && <HomePage />}
        {page.name === 'watch' && <WatchPage videoId={page.videoId} />}
        {page.name === 'channel' && <ChannelPage channelId={page.channelId} />}
        {page.name === 'upload' && <UploadPage />}
        {page.name === 'search' && <SearchPage query={page.query} />}
        {page.name === 'library' && <LibraryPage />}
        {page.name === 'shorts' && <ShortsPage />}
        {page.name === 'copyright' && <CopyrightDashboard />}
        {page.name === 'dashboard' && <CreatorDashboard />}
        {page.name === 'admin' && <AdminPage />}
        {page.name === 'watchparty' && <WatchPartyPage roomId={page.roomId} />}
      </main>
      <AudioMiniPlayer />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AudioProvider>
        <RouterProvider>
          <AppContent />
        </RouterProvider>
      </AudioProvider>
    </AuthProvider>
  );
}

export default App;
