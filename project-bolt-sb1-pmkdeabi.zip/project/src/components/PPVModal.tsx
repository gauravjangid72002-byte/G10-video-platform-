import { useState } from 'react';
import { X, Lock, Check, Play, CreditCard, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

export function PPVModal({
  videoId,
  videoTitle,
  channelName,
  price,
  thumbnailUrl,
  onUnlocked,
  onClose,
}: {
  videoId: string;
  videoTitle: string;
  channelName: string;
  price: number;
  thumbnailUrl: string | null;
  onUnlocked: () => void;
  onClose: () => void;
}) {
  const { channel } = useAuth();
  const [status, setStatus] = useState<'idle' | 'processing' | 'success'>('idle');

  async function handlePurchase(e: React.FormEvent) {
    e.preventDefault();
    if (!channel) return;
    setStatus('processing');

    await new Promise((r) => setTimeout(r, 1500));

    const { error } = await supabase.from('ppv_purchases').insert({
      video_id: videoId,
      buyer_id: channel.id,
      price_paid: price,
    });

    if (error) {
      setStatus('idle');
      return;
    }

    setStatus('success');
    setTimeout(() => {
      onUnlocked();
      onClose();
    }, 1800);
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-[#1a1a1a] rounded-2xl border border-white/10 overflow-hidden">
        {status === 'success' ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-400" />
            </div>
            <h3 className="text-white text-lg font-bold">Access unlocked!</h3>
            <p className="text-gray-400 text-sm mt-1">You can now watch this video.</p>
          </div>
        ) : (
          <>
            {/* Preview header with thumbnail */}
            <div className="relative aspect-video bg-black">
              {thumbnailUrl ? (
                <img src={thumbnailUrl} alt={videoTitle} className="w-full h-full object-cover opacity-50" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-gray-800 to-black" />
              )}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 bg-black/60 rounded-full flex items-center justify-center backdrop-blur-sm border border-white/20">
                  <Lock className="w-7 h-7 text-white" />
                </div>
              </div>
              <button
                onClick={onClose}
                className="absolute top-3 right-3 p-1.5 bg-black/60 rounded-full hover:bg-black/80 transition-colors"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2 py-0.5 bg-amber-500/20 text-amber-400 text-xs font-medium rounded">
                    EXCLUSIVE
                  </span>
                  <span className="text-gray-500 text-xs">{channelName}</span>
                </div>
                <h3 className="text-white text-base font-bold leading-snug">{videoTitle}</h3>
              </div>

              <div className="bg-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 text-sm">Unlock price</span>
                  <span className="text-white text-2xl font-bold">${price.toFixed(2)}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-400">
                  <Play className="w-3.5 h-3.5" />
                  <span>Full video access — watch as many times as you want</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-400">
                  <Shield className="w-3.5 h-3.5" />
                  <span>One-time payment, no subscription</span>
                </div>
              </div>

              <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 flex items-start gap-2">
                <CreditCard className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <p className="text-gray-400 text-xs">
                  This is a simulated purchase for demo purposes. No real payment will be processed.
                </p>
              </div>

              <button
                onClick={handlePurchase}
                disabled={status === 'processing'}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-amber-500 text-black text-sm font-bold hover:bg-amber-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {status === 'processing' ? (
                  <>
                    <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                    Processing payment...
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    Unlock for ${price.toFixed(2)}
                  </>
                )}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
