import { useState, useRef, useEffect } from 'react';
import { X, Scissors, Play, Pause, Type, Plus, Download, Loader2, ChevronLeft, ChevronRight } from 'lucide-react';

type Overlay = {
  id: number;
  text: string;
  x: number;
  y: number;
  fontSize: number;
  color: string;
  bgColor: string;
};

export function ClipMemeMaker({
  videoUrl,
  videoTitle,
  onClose,
}: {
  videoUrl: string;
  videoTitle: string;
  onClose: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [clipStart, setClipStart] = useState(0);
  const [clipEnd, setClipEnd] = useState(10);
  const [overlays, setOverlays] = useState<Overlay[]>([]);
  const [selectedOverlay, setSelectedOverlay] = useState<number | null>(null);
  const [newText, setNewText] = useState('');
  const [exporting, setExporting] = useState(false);
  const [overlayIdCounter, setOverlayIdCounter] = useState(1);
  const dragRef = useRef<{ id: number; offsetX: number; offsetY: number } | null>(null);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onLoaded = () => {
      setDuration(v.duration);
      setClipEnd(Math.min(10, v.duration));
    };
    const onTime = () => setCurrentTime(v.currentTime);
    v.addEventListener('loadedmetadata', onLoaded);
    v.addEventListener('timeupdate', onTime);
    return () => {
      v.removeEventListener('loadedmetadata', onLoaded);
      v.removeEventListener('timeupdate', onTime);
    };
  }, []);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    // Loop within clip bounds
    if (currentTime >= clipEnd) {
      v.currentTime = clipStart;
    }
    if (currentTime < clipStart) {
      v.currentTime = clipStart;
    }
  }, [currentTime, clipStart, clipEnd]);

  function togglePlay() {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      v.currentTime = clipStart;
      v.play();
      setIsPlaying(true);
    } else {
      v.pause();
      setIsPlaying(false);
    }
  }

  function addOverlay() {
    if (!newText.trim()) return;
    setOverlays((prev) => [
      ...prev,
      {
        id: overlayIdCounter,
        text: newText.trim(),
        x: 50,
        y: 50,
        fontSize: 24,
        color: '#ffffff',
        bgColor: '#000000',
      },
    ]);
    setOverlayIdCounter((c) => c + 1);
    setNewText('');
  }

  function updateOverlay(id: number, patch: Partial<Overlay>) {
    setOverlays((prev) => prev.map((o) => (o.id === id ? { ...o, ...patch } : o)));
  }

  function removeOverlay(id: number) {
    setOverlays((prev) => prev.filter((o) => o.id !== id));
    setSelectedOverlay(null);
  }

  function handleOverlayMouseDown(e: React.MouseEvent, overlay: Overlay) {
    e.stopPropagation();
    setSelectedOverlay(overlay.id);
    const rect = (e.currentTarget.parentElement as HTMLElement).getBoundingClientRect();
    dragRef.current = {
      id: overlay.id,
      offsetX: e.clientX - rect.left - (overlay.x / 100) * rect.width,
      offsetY: e.clientY - rect.top - (overlay.y / 100) * rect.height,
    };
  }

  function handleMouseMove(e: React.MouseEvent) {
    if (!dragRef.current) return;
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = ((e.clientX - rect.left - dragRef.current.offsetX) / rect.width) * 100;
    const y = ((e.clientY - rect.top - dragRef.current.offsetY) / rect.height) * 100;
    updateOverlay(dragRef.current.id, {
      x: Math.max(0, Math.min(100, x)),
      y: Math.max(0, Math.min(100, y)),
    });
  }

  function handleMouseUp() {
    dragRef.current = null;
  }

  function exportClip() {
    setExporting(true);
    // Simulate export — in a real app this would use canvas + MediaRecorder
    setTimeout(() => {
      setExporting(false);
      onClose();
    }, 2000);
  }

  function formatTime(s: number): string {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
      <div className="w-full max-w-3xl bg-[#1a1a1a] rounded-2xl border border-white/10 overflow-hidden max-h-[95vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-orange-600/20 rounded-lg flex items-center justify-center">
              <Scissors className="w-4 h-4 text-orange-400" />
            </div>
            <h3 className="text-white text-sm font-bold">Clip / Meme Maker</h3>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        <div className="flex flex-col lg:flex-row gap-4 p-5 overflow-y-auto">
          {/* Video preview with overlays */}
          <div className="flex-1 min-w-0">
            <div
              className="relative aspect-video rounded-xl overflow-hidden bg-black select-none"
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            >
              <video
                ref={videoRef}
                src={videoUrl}
                className="w-full h-full object-contain"
                onClick={togglePlay}
              />

              {/* Overlays */}
              {overlays.map((o) => (
                <div
                  key={o.id}
                  onMouseDown={(e) => handleOverlayMouseDown(e, o)}
                  onClick={(e) => { e.stopPropagation(); setSelectedOverlay(o.id); }}
                  className={`absolute cursor-move whitespace-pre-wrap text-center font-bold px-2 py-1 rounded select-none ${
                    selectedOverlay === o.id ? 'ring-2 ring-blue-500' : ''
                  }`}
                  style={{
                    left: `${o.x}%`,
                    top: `${o.y}%`,
                    transform: 'translate(-50%, -50%)',
                    fontSize: `${o.fontSize}px`,
                    color: o.color,
                    backgroundColor: o.bgColor === 'transparent' ? 'transparent' : o.bgColor + 'cc',
                    maxWidth: '90%',
                  }}
                >
                  {o.text}
                </div>
              ))}

              {/* Play/pause overlay */}
              <button
                onClick={togglePlay}
                className="absolute inset-0 flex items-center justify-center pointer-events-none"
              >
                {!isPlaying && (
                  <div className="w-14 h-14 bg-black/50 rounded-full flex items-center justify-center backdrop-blur-sm">
                    <Play className="w-7 h-7 text-white fill-white ml-1" />
                  </div>
                )}
              </button>

              {/* Clip range indicator on timeline */}
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10">
                <div
                  className="absolute h-full bg-orange-500"
                  style={{ left: `${(clipStart / Math.max(duration, 1)) * 100}%`, width: `${((clipEnd - clipStart) / Math.max(duration, 1)) * 100}%` }}
                />
              </div>
            </div>

            {/* Timeline controls */}
            <div className="mt-3 space-y-2">
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <span>Clip: {formatTime(clipStart)} — {formatTime(clipEnd)}</span>
                <span className="ml-auto">Duration: {formatTime(clipEnd - clipStart)}</span>
              </div>

              {/* Start slider */}
              <div>
                <label className="text-gray-400 text-xs flex items-center gap-1 mb-1">
                  <ChevronLeft className="w-3 h-3" /> Start
                </label>
                <input
                  type="range"
                  min={0}
                  max={Math.max(duration - 1, 1)}
                  step={0.1}
                  value={clipStart}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    setClipStart(Math.min(v, clipEnd - 1));
                    if (videoRef.current) videoRef.current.currentTime = v;
                  }}
                  className="w-full accent-orange-500"
                />
              </div>

              {/* End slider */}
              <div>
                <label className="text-gray-400 text-xs flex items-center gap-1 mb-1">
                  End <ChevronRight className="w-3 h-3" />
                </label>
                <input
                  type="range"
                  min={1}
                  max={duration}
                  step={0.1}
                  value={clipEnd}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    setClipEnd(Math.max(v, clipStart + 1));
                  }}
                  className="w-full accent-orange-500"
                />
              </div>
            </div>
          </div>

          {/* Overlay editor sidebar */}
          <div className="lg:w-[280px] flex-shrink-0 space-y-4">
            <div>
              <p className="text-white text-sm font-medium mb-2 flex items-center gap-1.5">
                <Type className="w-4 h-4 text-orange-400" />
                Text Overlays
              </p>

              {/* Add new text */}
              <div className="flex gap-2 mb-3">
                <input
                  type="text"
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addOverlay()}
                  placeholder="Add text..."
                  maxLength={100}
                  className="flex-1 bg-[#121212] border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-orange-500"
                />
                <button
                  onClick={addOverlay}
                  className="p-2 bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors flex-shrink-0"
                >
                  <Plus className="w-4 h-4 text-white" />
                </button>
              </div>

              {/* Overlay list */}
              <div className="space-y-2 max-h-[200px] overflow-y-auto scrollbar-thin">
                {overlays.length === 0 ? (
                  <p className="text-gray-500 text-xs text-center py-4">No overlays yet. Add text to create a meme!</p>
                ) : (
                  overlays.map((o) => (
                    <div
                      key={o.id}
                      className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                        selectedOverlay === o.id ? 'border-blue-500 bg-blue-500/10' : 'border-white/10 bg-white/5'
                      }`}
                      onClick={() => setSelectedOverlay(o.id)}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-white text-xs truncate flex-1">{o.text}</span>
                        <button
                          onClick={(e) => { e.stopPropagation(); removeOverlay(o.id); }}
                          className="text-gray-400 hover:text-red-400 flex-shrink-0"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      {selectedOverlay === o.id && (
                        <div className="mt-2 space-y-2">
                          <div className="flex items-center gap-2">
                            <label className="text-gray-400 text-xs w-12">Size</label>
                            <input
                              type="range"
                              min={12}
                              max={48}
                              value={o.fontSize}
                              onChange={(e) => updateOverlay(o.id, { fontSize: parseInt(e.target.value) })}
                              className="flex-1 accent-blue-500"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <label className="text-gray-400 text-xs w-12">Text</label>
                            <input
                              type="color"
                              value={o.color}
                              onChange={(e) => updateOverlay(o.id, { color: e.target.value })}
                              className="w-8 h-7 rounded cursor-pointer bg-transparent border border-white/10"
                            />
                            <label className="text-gray-400 text-xs w-10">BG</label>
                            <input
                              type="color"
                              value={o.bgColor}
                              onChange={(e) => updateOverlay(o.id, { bgColor: e.target.value })}
                              className="w-8 h-7 rounded cursor-pointer bg-transparent border border-white/10"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Export */}
            <button
              onClick={exportClip}
              disabled={exporting}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-orange-600 text-white text-sm font-bold hover:bg-orange-700 disabled:opacity-50 transition-colors"
            >
              {exporting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Export Clip
                </>
              )}
            </button>
            <p className="text-gray-500 text-xs text-center">
              Clip from "{videoTitle}"
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
