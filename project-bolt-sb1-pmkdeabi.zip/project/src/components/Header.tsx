import { Menu, Search, Video as VideoIcon, Bell, UserCircle, X } from 'lucide-react';
import { useState } from 'react';
import { useRouter } from '@/context/RouterContext';
import { useAuth } from '@/context/AuthContext';

export function Header() {
  const { navigate, setSidebarOpen, sidebarOpen } = useRouter();
  const { session, channel, signOut } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [showUserMenu, setShowUserMenu] = useState(false);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate({ name: 'search', query: searchQuery.trim() });
    }
  }

  return (
    <header className="fixed top-0 left-0 right-0 h-14 bg-[#0f0f0f] z-50 flex items-center px-4 gap-2">
      <div className="flex items-center gap-2 min-w-fit">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-2 rounded-full hover:bg-white/10 transition-colors"
        >
          <Menu className="w-5 h-5 text-white" />
        </button>
        <button onClick={() => navigate({ name: 'home' })} className="flex items-center gap-1">
          <img src="/assets/file_00000000a39c82118fc703d90f470cbd.png" alt="G10" className="w-8 h-8 rounded-lg object-cover" />
          <span className="text-white font-bold text-lg hidden sm:block">G10</span>
        </button>
      </div>

      <form onSubmit={handleSearch} className="flex-1 max-w-2xl mx-auto flex items-center">
        <div className="flex-1 flex items-center">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search"
            className="w-full h-9 bg-[#121212] border border-[#303030] rounded-l-full px-4 text-white text-sm placeholder:text-gray-500 focus:outline-none focus:border-blue-500"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="h-9 px-3 bg-[#121212] border-y border-[#303030] hover:bg-[#222]"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          )}
          <button
            type="submit"
            className="h-9 px-5 bg-[#222] border border-l-0 border-[#303030] rounded-r-full hover:bg-[#303030] transition-colors"
          >
            <Search className="w-5 h-5 text-gray-300" />
          </button>
        </div>
      </form>

      <div className="flex items-center gap-2 min-w-fit">
        {session ? (
          <>
            <button
              onClick={() => navigate({ name: 'upload' })}
              className="flex items-center gap-1.5 px-3 h-9 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            >
              <VideoIcon className="w-5 h-5 text-white" />
              <span className="text-white text-sm font-medium hidden sm:block">Create</span>
            </button>
            <button className="p-2 rounded-full hover:bg-white/10 transition-colors relative">
              <Bell className="w-5 h-5 text-white" />
            </button>
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="w-8 h-8 rounded-full overflow-hidden bg-white/10 flex items-center justify-center"
              >
                {channel?.avatar_url ? (
                  <img src={channel.avatar_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <UserCircle className="w-8 h-8 text-gray-400" />
                )}
              </button>
              {showUserMenu && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowUserMenu(false)} />
                  <div className="absolute right-0 top-12 w-64 bg-[#282828] rounded-lg shadow-xl z-50 overflow-hidden">
                    <div className="p-4 border-b border-white/10 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-white/10 flex-shrink-0">
                        {channel?.avatar_url && (
                          <img src={channel.avatar_url} alt="" className="w-full h-full object-cover" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="text-white text-sm font-medium truncate">{channel?.name}</p>
                        <p className="text-gray-400 text-xs truncate">{channel?.handle}</p>
                      </div>
                    </div>
                    <div className="py-2">
                      <button
                        onClick={() => {
                          if (channel) navigate({ name: 'channel', channelId: channel.id });
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-4 py-2 text-white text-sm hover:bg-white/10"
                      >
                        Your channel
                      </button>
                      <button
                        onClick={() => {
                          navigate({ name: 'library' });
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-4 py-2 text-white text-sm hover:bg-white/10"
                      >
                        Library
                      </button>
                      <button
                        onClick={async () => {
                          await signOut();
                          setShowUserMenu(false);
                          navigate({ name: 'home' });
                        }}
                        className="w-full text-left px-4 py-2 text-white text-sm hover:bg-white/10 border-t border-white/10 mt-1 pt-3"
                      >
                        Sign out
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </>
        ) : (
          <button
            onClick={() => navigate({ name: 'signin' })}
            className="flex items-center gap-1.5 px-3 h-9 rounded-full border border-[#303030] hover:bg-blue-600/10 hover:border-blue-500 transition-colors"
          >
            <UserCircle className="w-6 h-6 text-white" />
            <span className="text-white text-sm font-medium">Sign in</span>
          </button>
        )}
      </div>
    </header>
  );
}
