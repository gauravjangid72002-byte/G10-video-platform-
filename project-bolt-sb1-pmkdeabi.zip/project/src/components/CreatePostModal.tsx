import { useState } from 'react';
import { X, Type, Image, BarChart3, Send, Loader2, Plus, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

type PostType = 'text' | 'image' | 'poll';

export function CreatePostModal({ onClose }: { onClose: () => void }) {
  const { channel } = useAuth();
  const [postType, setPostType] = useState<PostType>('text');
  const [textContent, setTextContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);
  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function addPollOption() {
    if (pollOptions.length < 5) {
      setPollOptions([...pollOptions, '']);
    }
  }

  function removePollOption(index: number) {
    if (pollOptions.length > 2) {
      setPollOptions(pollOptions.filter((_, i) => i !== index));
    }
  }

  function updatePollOption(index: number, value: string) {
    setPollOptions(pollOptions.map((o, i) => (i === index ? value : o)));
  }

  async function publish() {
    if (!channel) return;
    setError(null);

    if (postType === 'text' && !textContent.trim()) {
      setError('Please write something to post.');
      return;
    }
    if (postType === 'image' && !imageUrl.trim()) {
      setError('Please provide an image URL.');
      return;
    }
    if (postType === 'poll') {
      if (!pollQuestion.trim()) {
        setError('Please enter a poll question.');
        return;
      }
      if (pollOptions.filter((o) => o.trim()).length < 2) {
        setError('Please provide at least 2 poll options.');
        return;
      }
    }

    setPublishing(true);

    const insertData: any = {
      channel_id: channel.id,
      post_type: postType,
    };

    if (postType === 'text') {
      insertData.text_content = textContent.trim();
    } else if (postType === 'image') {
      insertData.text_content = textContent.trim() || null;
      insertData.image_url = imageUrl.trim();
    } else if (postType === 'poll') {
      insertData.poll_question = pollQuestion.trim();
      insertData.poll_options = pollOptions.filter((o) => o.trim());
      insertData.text_content = textContent.trim() || null;
    }

    const { error: insertError } = await supabase.from('community_posts').insert(insertData);

    setPublishing(false);

    if (insertError) {
      setError(insertError.message);
      return;
    }

    onClose();
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-[#1a1a1a] rounded-2xl border border-white/10 overflow-hidden max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 flex-shrink-0">
          <h3 className="text-white text-sm font-bold">Create Community Post</h3>
          <button onClick={onClose} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto">
          {/* Post type selector */}
          <div className="flex items-center gap-2 mb-4">
            {([
              { type: 'text' as PostType, label: 'Text', icon: Type },
              { type: 'image' as PostType, label: 'Image', icon: Image },
              { type: 'poll' as PostType, label: 'Poll', icon: BarChart3 },
            ]).map((t) => (
              <button
                key={t.type}
                onClick={() => setPostType(t.type)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                  postType === t.type ? 'bg-blue-600 text-white' : 'bg-white/5 text-gray-400 hover:text-white'
                }`}
              >
                <t.icon className="w-4 h-4" />
                {t.label}
              </button>
            ))}
          </div>

          {/* Text content (for all types) */}
          <div className="mb-3">
            <textarea
              value={textContent}
              onChange={(e) => setTextContent(e.target.value)}
              placeholder={postType === 'poll' ? 'Add some context (optional)...' : "What's on your mind?"}
              rows={postType === 'text' ? 4 : 2}
              maxLength={500}
              className="w-full bg-[#121212] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500 resize-none"
            />
            <p className="text-gray-500 text-xs mt-1 text-right">{textContent.length}/500</p>
          </div>

          {/* Image URL */}
          {postType === 'image' && (
            <div className="mb-3">
              <label className="block text-white text-xs font-medium mb-2 uppercase tracking-wide">Image URL</label>
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://example.com/image.jpg"
                className="w-full bg-[#121212] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
              />
              {imageUrl && (
                <div className="mt-3 relative inline-block">
                  <img src={imageUrl} alt="Preview" className="max-h-48 rounded-lg object-cover" />
                  <button
                    onClick={() => setImageUrl('')}
                    className="absolute top-2 right-2 bg-black/70 rounded-full p-1"
                  >
                    <X className="w-4 h-4 text-white" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Poll fields */}
          {postType === 'poll' && (
            <div className="mb-3 space-y-3">
              <div>
                <label className="block text-white text-xs font-medium mb-2 uppercase tracking-wide">Poll Question</label>
                <input
                  type="text"
                  value={pollQuestion}
                  onChange={(e) => setPollQuestion(e.target.value)}
                  placeholder="Ask your audience something..."
                  maxLength={200}
                  className="w-full bg-[#121212] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-white text-xs font-medium mb-2 uppercase tracking-wide">Options</label>
                <div className="space-y-2">
                  {pollOptions.map((opt, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-gray-400 text-xs flex-shrink-0">
                        {i + 1}
                      </div>
                      <input
                        type="text"
                        value={opt}
                        onChange={(e) => updatePollOption(i, e.target.value)}
                        placeholder={`Option ${i + 1}`}
                        maxLength={100}
                        className="flex-1 bg-[#121212] border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
                      />
                      {pollOptions.length > 2 && (
                        <button
                          onClick={() => removePollOption(i)}
                          className="p-1.5 text-gray-400 hover:text-red-400 flex-shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                {pollOptions.length < 5 && (
                  <button
                    onClick={addPollOption}
                    className="flex items-center gap-1.5 mt-2 text-blue-400 text-xs hover:underline"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add option
                  </button>
                )}
              </div>
            </div>
          )}

          {error && (
            <div className="mb-3 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-white/10 text-white text-sm font-medium hover:bg-white/20 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={publish}
              disabled={publishing}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-bold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {publishing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Publishing...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Post
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
