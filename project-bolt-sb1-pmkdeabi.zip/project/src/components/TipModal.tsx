import { useState } from 'react';
import { X, Heart, DollarSign, Check, Sparkles } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

const PRESET_AMOUNTS = [1, 2, 5, 10];

export function TipModal({
  videoId,
  channelName,
  onClose,
}: {
  videoId: string;
  channelName: string;
  onClose: () => void;
}) {
  const { channel } = useAuth();
  const [amount, setAmount] = useState(2);
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'processing' | 'success'>('idle');

  async function handleTip(e: React.FormEvent) {
    e.preventDefault();
    if (!channel) return;
    setStatus('processing');

    await new Promise((r) => setTimeout(r, 1200));

    const { error } = await supabase.from('tips').insert({
      video_id: videoId,
      tipper_id: channel.id,
      amount,
      message: message.trim(),
    });

    if (error) {
      setStatus('idle');
      return;
    }

    await supabase.rpc('increment_tip_total', {
      video_uuid: videoId,
      tip_amount: amount,
    });

    setStatus('success');
    setTimeout(onClose, 2500);
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#1a1a1a] rounded-2xl border border-white/10 overflow-hidden">
        {status === 'success' ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-400" />
            </div>
            <h3 className="text-white text-lg font-bold">Tip sent!</h3>
            <p className="text-gray-400 text-sm mt-1">
              You sent ${amount.toFixed(2)} to {channelName}
            </p>
            {message.trim() && (
              <p className="text-gray-300 text-sm mt-3 italic">"{message.trim()}"</p>
            )}
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-pink-600/20 rounded-lg flex items-center justify-center">
                  <Heart className="w-4 h-4 text-pink-400 fill-pink-400" />
                </div>
                <div>
                  <h3 className="text-white text-sm font-bold">Super Thanks</h3>
                  <p className="text-gray-400 text-xs">Tip {channelName}</p>
                </div>
              </div>
              <button onClick={onClose} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
                <X className="w-4 h-4 text-gray-400" />
              </button>
            </div>

            <form onSubmit={handleTip} className="p-5 space-y-5">
              <div>
                <label className="block text-white text-xs font-medium mb-2 uppercase tracking-wide">Amount</label>
                <div className="grid grid-cols-4 gap-2">
                  {PRESET_AMOUNTS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setAmount(preset)}
                      className={`py-2.5 rounded-lg text-sm font-medium transition-all ${
                        amount === preset
                          ? 'bg-pink-600 text-white border border-pink-500'
                          : 'bg-white/5 text-gray-300 border border-white/10 hover:bg-white/10'
                      }`}
                    >
                      ${preset}
                    </button>
                  ))}
                </div>
                <div className="mt-2 relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="number"
                    min={0.5}
                    step={0.5}
                    value={amount}
                    onChange={(e) => setAmount(Math.max(0.5, parseFloat(e.target.value) || 0))}
                    className="w-full bg-[#121212] border border-white/10 rounded-lg pl-9 pr-4 py-2 text-white text-sm focus:outline-none focus:border-pink-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white text-xs font-medium mb-2 uppercase tracking-wide">
                  Message <span className="text-gray-500 normal-case">(optional)</span>
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Add a nice message for the creator..."
                  rows={2}
                  maxLength={200}
                  className="w-full bg-[#121212] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-pink-500 resize-none"
                />
              </div>

              <div className="bg-pink-600/10 border border-pink-500/20 rounded-lg p-3 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-pink-400 flex-shrink-0 mt-0.5" />
                <p className="text-gray-400 text-xs">
                  This is a simulated tip for demo purposes. No real payment will be processed.
                </p>
              </div>

              <button
                type="submit"
                disabled={status === 'processing' || amount < 0.5}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-pink-600 text-white text-sm font-bold hover:bg-pink-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {status === 'processing' ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>Send ${amount.toFixed(2)} Tip</>
                )}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
