import { useState, useEffect } from 'react';
import { MessageSquare, Image as ImageIcon, BarChart3, Plus, Heart, Share2, Check } from 'lucide-react';
import { supabase, type CommunityPost, type Channel } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { formatTimeAgo } from '@/lib/format';
import { CreatePostModal } from '@/components/CreatePostModal';

export function CommunityPosts({ channelId }: { channelId: string }) {
  const { channel, session } = useAuth();
  const { navigate } = useRouter();
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [voting, setVoting] = useState<string | null>(null);

  const isOwner = channel?.id === channelId;

  useEffect(() => {
    loadPosts();
  }, [channelId]);

  async function loadPosts() {
    setLoading(true);
    const { data, error } = await supabase
      .from('community_posts')
      .select('*, channel:channels(*)')
      .eq('channel_id', channelId)
      .order('created_at', { ascending: false })
      .limit(20);

    if (error || !data) {
      setLoading(false);
      return;
    }

    const postsData = data as CommunityPost[];

    // Fetch vote counts and user votes for polls
    if (channel) {
      await Promise.all(
        postsData.map(async (post) => {
          if (post.post_type === 'poll') {
            const { data: votes } = await supabase
              .from('community_poll_votes')
              .select('option_index, voter_id')
              .eq('post_id', post.id);

            const options = post.poll_options ?? [];
            const counts = new Array(options.length).fill(0);
            let userVote: number | null = null;
            (votes ?? []).forEach((v: any) => {
              if (v.option_index >= 0 && v.option_index < counts.length) {
                counts[v.option_index]++;
              }
              if (v.voter_id === channel.id) {
                userVote = v.option_index;
              }
            });
            post.voteCounts = counts;
            post.totalVotes = counts.reduce((a, b) => a + b, 0);
            post.userVote = userVote;
          }
        })
      );
    }

    setPosts(postsData);
    setLoading(false);
  }

  async function vote(post: CommunityPost, optionIndex: number) {
    if (!channel) return;
    if (post.userVote !== null && post.userVote !== undefined) return;

    setVoting(post.id);

    const { error } = await supabase
      .from('community_poll_votes')
      .insert({ post_id: post.id, voter_id: channel.id, option_index: optionIndex });

    if (!error) {
      setPosts((prev) =>
        prev.map((p) => {
          if (p.id !== post.id) return p;
          const counts = [...(p.voteCounts ?? [])];
          counts[optionIndex] = (counts[optionIndex] ?? 0) + 1;
          return { ...p, voteCounts: counts, totalVotes: (p.totalVotes ?? 0) + 1, userVote: optionIndex };
        })
      );
    }

    setVoting(null);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-6 h-6 border-2 border-white/20 border-t-blue-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="mt-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white text-lg font-medium">Community</h3>
        {isOwner && (
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-blue-600 text-white text-xs font-medium hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            New Post
          </button>
        )}
      </div>

      {posts.length === 0 ? (
        <div className="text-center py-12 bg-white/5 rounded-xl">
          <MessageSquare className="w-10 h-10 text-gray-600 mx-auto mb-2" />
          <p className="text-gray-400 text-sm">No community posts yet</p>
          {isOwner ? (
            <button
              onClick={() => setShowCreate(true)}
              className="text-blue-400 text-xs mt-2 hover:underline"
            >
              Create your first post
            </button>
          ) : (
            <p className="text-gray-600 text-xs mt-1">Check back later for updates from this creator.</p>
          )}
        </div>
      ) : (
        <div className="space-y-4 max-w-2xl">
          {posts.map((post) => {
            const ch = post.channel as Channel | undefined;
            return (
              <div key={post.id} className="bg-white/5 rounded-xl border border-white/10 p-4">
                {/* Author header */}
                <div className="flex items-center gap-3 mb-3">
                  <button
                    onClick={() => navigate({ name: 'channel', channelId: post.channel_id })}
                    className="w-9 h-9 rounded-full overflow-hidden bg-white/10 flex-shrink-0"
                  >
                    {ch?.avatar_url && <img src={ch.avatar_url} alt="" className="w-full h-full object-cover" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium">{ch?.name}</p>
                    <p className="text-gray-400 text-xs">{formatTimeAgo(post.created_at)}</p>
                  </div>
                  {post.post_type === 'poll' && (
                    <span className="flex items-center gap-1 text-xs text-blue-400 bg-blue-600/10 px-2 py-1 rounded">
                      <BarChart3 className="w-3 h-3" />
                      Poll
                    </span>
                  )}
                  {post.post_type === 'image' && (
                    <span className="flex items-center gap-1 text-xs text-green-400 bg-green-600/10 px-2 py-1 rounded">
                      <ImageIcon className="w-3 h-3" />
                      Image
                    </span>
                  )}
                </div>

                {/* Text content */}
                {post.text_content && (
                  <p className="text-gray-200 text-sm whitespace-pre-wrap mb-3">{post.text_content}</p>
                )}

                {/* Image */}
                {post.post_type === 'image' && post.image_url && (
                  <div className="rounded-xl overflow-hidden mb-3 max-w-md">
                    <img src={post.image_url} alt="" className="w-full h-auto" />
                  </div>
                )}

                {/* Poll */}
                {post.post_type === 'poll' && post.poll_question && (
                  <div className="mb-3">
                    <p className="text-white text-sm font-medium mb-3">{post.poll_question}</p>
                    <div className="space-y-2">
                      {(post.poll_options ?? []).map((opt, i) => {
                        const counts = post.voteCounts ?? [];
                        const total = post.totalVotes ?? 0;
                        const pct = total > 0 ? ((counts[i] ?? 0) / total) * 100 : 0;
                        const hasVoted = post.userVote !== null && post.userVote !== undefined;
                        const isMyChoice = post.userVote === i;

                        return (
                          <button
                            key={i}
                            onClick={() => vote(post, i)}
                            disabled={hasVoted || !session || voting === post.id}
                            className={`w-full relative overflow-hidden rounded-lg border transition-all text-left ${
                              isMyChoice ? 'border-blue-500' : 'border-white/10 hover:border-white/20'
                            } ${hasVoted || !session ? 'cursor-default' : 'cursor-pointer'}`}
                          >
                            {hasVoted && (
                              <div
                                className="absolute inset-0 bg-blue-600/15 transition-all"
                                style={{ width: `${pct}%` }}
                              />
                            )}
                            <div className="relative flex items-center justify-between px-3 py-2.5">
                              <span className={`text-sm ${isMyChoice ? 'text-blue-400 font-medium' : 'text-gray-200'}`}>
                                {opt}
                              </span>
                              {hasVoted && (
                                <div className="flex items-center gap-2">
                                  {isMyChoice && <Check className="w-3.5 h-3.5 text-blue-400" />}
                                  <span className="text-gray-400 text-xs">{pct.toFixed(0)}%</span>
                                </div>
                              )}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                    {post.poll_question && (
                      <p className="text-gray-500 text-xs mt-2">
                        {post.totalVotes ?? 0} vote{(post.totalVotes ?? 0) !== 1 ? 's' : ''}
                        {hasVotedCheck(post) ? ' — Thanks for voting!' : session ? '' : ' — Sign in to vote'}
                      </p>
                    )}
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center gap-4 pt-2 border-t border-white/5">
                  <button className="flex items-center gap-1.5 text-gray-400 text-xs hover:text-white transition-colors">
                    <Heart className="w-4 h-4" />
                    Like
                  </button>
                  <button className="flex items-center gap-1.5 text-gray-400 text-xs hover:text-white transition-colors">
                    <MessageSquare className="w-4 h-4" />
                    Comment
                  </button>
                  <button className="flex items-center gap-1.5 text-gray-400 text-xs hover:text-white transition-colors">
                    <Share2 className="w-4 h-4" />
                    Share
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showCreate && (
        <CreatePostModal
          onClose={() => {
            setShowCreate(false);
            loadPosts();
          }}
        />
      )}
    </div>
  );
}

function hasVotedCheck(post: CommunityPost): boolean {
  return post.userVote !== null && post.userVote !== undefined;
}
