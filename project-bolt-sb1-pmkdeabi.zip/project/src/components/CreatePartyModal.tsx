import { useState } from 'react';
import { X, Users, Plus, ArrowRight, Loader2, Copy, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';

function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export function CreatePartyModal({
  videoId,
  videoTitle,
  onClose,
}: {
  videoId: string;
  videoTitle: string;
  onClose: () => void;
}) {
  const { channel } = useAuth();
  const { navigate } = useRouter();
  const [mode, setMode] = useState<'choose' | 'create' | 'join'>('choose');
  const [joinCode, setJoinCode] = useState('');
  const [createdCode, setCreatedCode] = useState('');
  const [createdRoomId, setCreatedRoomId] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCreate() {
    if (!channel) return;
    setLoading(true);
    setError(null);
    const code = generateRoomCode();
    const { data, error: insertError } = await supabase
      .from('watch_party_rooms')
      .insert({
        host_id: channel.id,
        video_id: videoId,
        room_code: code,
        is_playing: false,
        playback_time: 0,
      })
      .select('id, room_code')
      .single();

    setLoading(false);

    if (insertError || !data) {
      setError('Failed to create room. Please try again.');
      return;
    }

    setCreatedCode(data.room_code);
    setCreatedRoomId(data.id);
    setMode('create');
  }

  async function handleJoin() {
    if (!joinCode.trim()) return;
    setLoading(true);
    setError(null);

    const { data, error: queryError } = await supabase
      .from('watch_party_rooms')
      .select('id')
      .eq('room_code', joinCode.trim().toUpperCase())
      .maybeSingle();

    setLoading(false);

    if (queryError || !data) {
      setError('Room not found. Check the code and try again.');
      return;
    }

    navigate({ name: 'watchparty', roomId: data.id });
    onClose();
  }

  function copyCode() {
    navigator.clipboard.writeText(createdCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#1a1a1a] rounded-2xl border border-white/10 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-purple-600/20 rounded-lg flex items-center justify-center">
              <Users className="w-4 h-4 text-purple-400" />
            </div>
            <h3 className="text-white text-sm font-bold">Watch Party</h3>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        <div className="p-5">
          {mode === 'choose' && (
            <div className="space-y-3">
              <p className="text-gray-400 text-sm mb-4">
                Watch videos together with friends in perfect sync, with live chat.
              </p>
              <button
                onClick={handleCreate}
                disabled={loading || !channel}
                className="w-full flex items-center gap-3 p-4 rounded-xl bg-purple-600/20 border border-purple-500/30 hover:bg-purple-600/30 transition-colors text-left disabled:opacity-50"
              >
                <div className="w-10 h-10 bg-purple-600/30 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Plus className="w-5 h-5 text-purple-400" />
                </div>
                <div className="flex-1">
                  <p className="text-white text-sm font-medium">Create a room</p>
                  <p className="text-gray-400 text-xs">Start a watch party for this video</p>
                </div>
              </button>
              <button
                onClick={() => setMode('join')}
                className="w-full flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors text-left"
              >
                <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <ArrowRight className="w-5 h-5 text-gray-300" />
                </div>
                <div className="flex-1">
                  <p className="text-white text-sm font-medium">Join with a code</p>
                  <p className="text-gray-400 text-xs">Enter a 6-character room code</p>
                </div>
              </button>
              {!channel && (
                <p className="text-amber-400/80 text-xs text-center pt-2">Sign in to create or join a watch party.</p>
              )}
            </div>
          )}

          {mode === 'create' && (
            <div className="text-center space-y-4">
              <div className="w-14 h-14 bg-green-600/20 rounded-full flex items-center justify-center mx-auto">
                <Check className="w-7 h-7 text-green-400" />
              </div>
              <div>
                <p className="text-white text-sm font-medium">Your room is ready!</p>
                <p className="text-gray-400 text-xs mt-1">Share this code with friends to invite them:</p>
              </div>
              <div className="flex items-center justify-center gap-2">
                <div className="px-6 py-3 bg-[#121212] border-2 border-purple-500/40 rounded-xl">
                  <span className="text-purple-400 text-2xl font-bold tracking-[0.3em]">{createdCode}</span>
                </div>
                <button
                  onClick={copyCode}
                  className="p-3 bg-white/10 rounded-xl hover:bg-white/20 transition-colors"
                >
                  {copied ? <Check className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5 text-gray-300" />}
                </button>
              </div>
              {copied && <p className="text-green-400 text-xs">Code copied to clipboard!</p>}
              <p className="text-gray-500 text-xs px-4">
                Watching: "{videoTitle}"
              </p>
              <button
                onClick={() => {
                  navigate({ name: 'watchparty', roomId: createdRoomId });
                  onClose();
                }}
                className="w-full py-3 rounded-xl bg-purple-600 text-white text-sm font-bold hover:bg-purple-700 transition-colors"
              >
                Enter Watch Party
              </button>
            </div>
          )}

          {mode === 'join' && (
            <div className="space-y-4">
              <button
                onClick={() => setMode('choose')}
                className="text-gray-400 text-xs hover:text-white transition-colors"
              >
                Back
              </button>
              <div>
                <label className="block text-white text-xs font-medium mb-2 uppercase tracking-wide">Room Code</label>
                <input
                  type="text"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  placeholder="ABC123"
                  maxLength={6}
                  autoFocus
                  className="w-full bg-[#121212] border border-white/10 rounded-lg px-4 py-3 text-white text-lg text-center tracking-[0.3em] font-bold focus:outline-none focus:border-purple-500"
                />
              </div>
              {error && <p className="text-red-400 text-sm">{error}</p>}
              <button
                onClick={handleJoin}
                disabled={loading || joinCode.length < 6}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-purple-600 text-white text-sm font-bold hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Joining...
                  </>
                ) : (
                  'Join Party'
                )}
              </button>
            </div>
          )}

          {mode === 'choose' && loading && (
            <div className="flex items-center justify-center py-4">
              <Loader2 className="w-5 h-5 text-purple-400 animate-spin" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
