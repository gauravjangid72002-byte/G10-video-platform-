import { Play, Pause, X, Volume2 } from 'lucide-react';
import { useAudio } from '@/context/AudioContext';

export function AudioMiniPlayer() {
  const { currentTrack, isPlaying, volume, toggle, stop, setVolume } = useAudio();

  if (!currentTrack) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 bg-[#1a1a1a] border border-white/10 rounded-2xl shadow-2xl overflow-hidden w-[320px] animate-in slide-in-from-bottom-4">
      <div className="flex items-center gap-3 p-3">
        {/* Play/pause button */}
        <button
          onClick={toggle}
          className="w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-700 flex items-center justify-center flex-shrink-0 transition-colors"
        >
          {isPlaying ? (
            <Pause className="w-5 h-5 text-white fill-white" />
          ) : (
            <Play className="w-5 h-5 text-white fill-white ml-0.5" />
          )}
        </button>

        {/* Track info */}
        <div className="flex-1 min-w-0">
          <p className="text-white text-xs font-medium truncate">{currentTrack.title}</p>
          <p className="text-gray-400 text-xs truncate">{currentTrack.channelName}</p>
        </div>

        {/* Volume control */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <Volume2 className="w-4 h-4 text-gray-400" />
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={volume}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
            className="w-16 accent-blue-500"
          />
        </div>

        {/* Stop/close */}
        <button
          onClick={stop}
          className="p-1.5 text-gray-400 hover:text-white hover:bg-white/10 rounded-full transition-colors flex-shrink-0"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Equalizer animation bar */}
      {isPlaying && (
        <div className="flex items-end gap-0.5 h-1 px-3 pb-1">
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((i) => (
            <div
              key={i}
              className="flex-1 bg-blue-500/60 rounded-sm"
              style={{
                height: `${20 + Math.sin(i * 2 + Date.now() / 200) * 40 + 40}%`,
                animation: `eqbar 0.${5 + (i % 3)}s ease-in-out infinite alternate`,
              }}
            />
          ))}
        </div>
      )}

      <style>{`
        @keyframes eqbar {
          0% { height: 20%; }
          100% { height: 100%; }
        }
      `}</style>
    </div>
  );
}
