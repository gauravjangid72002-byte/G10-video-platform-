import { useRouter } from '@/context/RouterContext';
import type { Video } from '@/lib/supabase';
import { formatViews, formatTimeAgo } from '@/lib/format';
import { Lock } from 'lucide-react';

function PPVBadge({ price }: { price: number }) {
  return (
    <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-1 bg-black/80 backdrop-blur-sm rounded text-amber-400 text-xs font-medium">
      <Lock className="w-3 h-3" />
      ${price.toFixed(2)}
    </div>
  );
}

export function VideoCard({ video }: { video: Video }) {
  const { navigate } = useRouter();

  return (
    <div
      onClick={() => navigate({ name: 'watch', videoId: video.id })}
      className="cursor-pointer group"
    >
      <div className="relative aspect-video rounded-xl overflow-hidden bg-[#1a1a1a]">
        {video.thumbnail_url ? (
          <img
            src={video.thumbnail_url}
            alt={video.title}
            className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-200"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <svg viewBox="0 0 24 24" className="w-12 h-12 text-gray-600 fill-current">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        )}
        {video.is_ppv && video.ppv_price != null && <PPVBadge price={video.ppv_price} />}
      </div>
      <div className="flex gap-3 mt-3">
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate({ name: 'channel', channelId: video.channel_id });
          }}
          className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0 bg-white/10"
        >
          {video.channel?.avatar_url && (
            <img src={video.channel.avatar_url} alt="" className="w-full h-full object-cover" />
          )}
        </button>
        <div className="flex-1 min-w-0">
          <h3 className="text-white text-sm font-medium line-clamp-2 leading-snug">
            {video.title}
          </h3>
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigate({ name: 'channel', channelId: video.channel_id });
            }}
            className="block text-gray-400 text-xs mt-1 hover:text-white transition-colors"
          >
            {video.channel?.name}
          </button>
          <p className="text-gray-400 text-xs">
            {formatViews(video.views)} • {formatTimeAgo(video.created_at)}
          </p>
        </div>
      </div>
    </div>
  );
}

export function VideoCardCompact({ video }: { video: Video }) {
  const { navigate } = useRouter();

  return (
    <div
      onClick={() => navigate({ name: 'watch', videoId: video.id })}
      className="cursor-pointer group flex gap-2"
    >
      <div className="relative aspect-video w-40 flex-shrink-0 rounded-lg overflow-hidden bg-[#1a1a1a]">
        {video.thumbnail_url ? (
          <img
            src={video.thumbnail_url}
            alt={video.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <svg viewBox="0 0 24 24" className="w-8 h-8 text-gray-600 fill-current">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        )}
        {video.is_ppv && video.ppv_price != null && <PPVBadge price={video.ppv_price} />}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="text-white text-sm font-medium line-clamp-2 leading-snug">
          {video.title}
        </h3>
        <p className="text-gray-400 text-xs mt-1">{video.channel?.name}</p>
        <p className="text-gray-400 text-xs">
          {formatViews(video.views)} • {formatTimeAgo(video.created_at)}
        </p>
      </div>
    </div>
  );
}
