import { useState, useRef, useEffect } from 'react';
import { Sparkles, ChevronDown, ChevronUp, Clock, ListChecks, Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Chapter {
  title: string;
  start_time: number;
  end_time: number;
  description: string;
}

interface SummaryData {
  summary: string;
  chapters: Chapter[];
  key_points: string[];
  cached: boolean;
}

export function VideoSummarizer({ videoId }: { videoId: string }) {
  const [data, setData] = useState<SummaryData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(true);
  const [activeChapter, setActiveChapter] = useState<number | null>(null);
  const fetchedRef = useRef<string | null>(null);

  useEffect(() => {
    if (fetchedRef.current === videoId) return;
    fetchedRef.current = videoId;
    setData(null);
    setError(null);
    loadSummary();
  }, [videoId]);

  async function loadSummary() {
    setLoading(true);
    setError(null);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/video-summarizer`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ videoId }),
      });

      if (!response.ok) {
        throw new Error(`Failed to generate summary (${response.status})`);
      }

      const json = await response.json();
      if (json.error) {
        throw new Error(json.error);
      }

      setData({
        summary: json.summary,
        chapters: json.chapters ?? [],
        key_points: json.key_points ?? [],
        cached: json.cached ?? false,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate summary');
    } finally {
      setLoading(false);
    }
  }

  async function regenerate() {
    fetchedRef.current = null;
    setLoading(true);
    setError(null);
    setData(null);
    try {
      // Delete cached summary first
      await supabase.from('video_summaries').delete().eq('video_id', videoId);
      await loadSummary();
    } catch {
      setError('Failed to regenerate summary');
      setLoading(false);
    }
  }

  function formatTimestamp(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  function seekToChapter(start: number, index: number) {
    const video = document.querySelector('video');
    if (video) {
      video.currentTime = start;
      setActiveChapter(index);
    }
  }

  return (
    <div className="mt-3 bg-gradient-to-br from-blue-950/40 to-[#1a1a1a] border border-blue-500/20 rounded-xl overflow-hidden">
      {/* Header bar */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/5 transition-colors"
      >
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-blue-600/30 rounded-lg flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-blue-400" />
          </div>
          <span className="text-white text-sm font-medium">AI Video Summary</span>
          {data?.cached && (
            <span className="text-blue-400/60 text-xs ml-1">cached</span>
          )}
        </div>
        {expanded ? (
          <ChevronUp className="w-4 h-4 text-gray-400" />
        ) : (
          <ChevronDown className="w-4 h-4 text-gray-400" />
        )}
      </button>

      {expanded && (
        <div className="px-4 pb-4 space-y-4">
          {loading && (
            <div className="flex items-center gap-3 py-8 justify-center">
              <Loader2 className="w-5 h-5 text-blue-400 animate-spin" />
              <span className="text-gray-300 text-sm">Analyzing video content...</span>
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-red-400 text-sm">{error}</p>
                <button
                  onClick={regenerate}
                  className="text-red-300 text-xs mt-1 hover:underline"
                >
                  Try again
                </button>
              </div>
            </div>
          )}

          {data && !loading && !error && (
            <>
              {/* Summary text */}
              <div>
                <p className="text-gray-200 text-sm leading-relaxed">{data.summary}</p>
              </div>

              {/* Key points */}
              {data.key_points.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <ListChecks className="w-4 h-4 text-blue-400" />
                    <h4 className="text-white text-xs font-semibold uppercase tracking-wide">Key Points</h4>
                  </div>
                  <ul className="space-y-1.5">
                    {data.key_points.map((point, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
                        <span className="text-blue-400 mt-1 flex-shrink-0">•</span>
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Auto-chapters */}
              {data.chapters.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-4 h-4 text-blue-400" />
                    <h4 className="text-white text-xs font-semibold uppercase tracking-wide">Auto Chapters</h4>
                  </div>
                  <div className="space-y-1">
                    {data.chapters.map((chapter, i) => (
                      <button
                        key={i}
                        onClick={() => seekToChapter(chapter.start_time, i)}
                        className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                          activeChapter === i
                            ? 'bg-blue-600/20 border border-blue-500/30'
                            : 'hover:bg-white/5 border border-transparent'
                        }`}
                      >
                        <span className="text-blue-400 text-xs font-mono flex-shrink-0 w-10">
                          {formatTimestamp(chapter.start_time)}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-white text-sm font-medium truncate">{chapter.title}</p>
                          <p className="text-gray-400 text-xs truncate">{chapter.description}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Regenerate button */}
              <div className="flex justify-end pt-1">
                <button
                  onClick={regenerate}
                  className="flex items-center gap-1.5 text-gray-400 hover:text-white text-xs transition-colors"
                >
                  <RefreshCw className="w-3 h-3" />
                  Regenerate
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
