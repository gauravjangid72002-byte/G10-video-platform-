import { useState, useEffect } from 'react';
import { X, Loader2, AlertTriangle, Check, ShieldCheck, FileVideo, ChevronRight } from 'lucide-react';
import { supabase, type Video } from '@/lib/supabase';

type MatchResult = {
  video: Video;
  score: number;
  reasons: string[];
};

export function ContentCheckModal({
  title,
  videoUrl,
  onProceed,
  onBlock,
  onClose,
}: {
  title: string;
  videoUrl: string;
  onProceed: () => void;
  onBlock: () => void;
  onClose: () => void;
}) {
  const [phase, setPhase] = useState<'scanning' | 'results' | 'clean'>('scanning');
  const [matches, setMatches] = useState<MatchResult[]>([]);
  const [scanStep, setScanStep] = useState(0);

  const scanSteps = [
    'Analyzing video metadata...',
    'Checking against Content ID database...',
    'Comparing visual fingerprints...',
    'Scanning audio signatures...',
    'Cross-referencing title and description...',
  ];

  useEffect(() => {
    async function runContentCheck() {
      // Simulate scan steps
      for (let i = 0; i < scanSteps.length; i++) {
        setScanStep(i);
        await new Promise((r) => setTimeout(r, 700));
      }

      // Fetch all existing videos to compare against
      const { data: existingVideos } = await supabase
        .from('videos')
        .select('*, channel:channels(*)')
        .neq('video_url', videoUrl)
        .limit(50);

      if (!existingVideos || existingVideos.length === 0) {
        setPhase('clean');
        return;
      }

      const found: MatchResult[] = [];
      const lowerTitle = title.toLowerCase();

      existingVideos.forEach((v) => {
        const existing = v as Video;
        let score = 0;
        const reasons: string[] = [];

        // Title similarity check
        const existingTitle = existing.title.toLowerCase();
        if (existingTitle === lowerTitle && title.length > 5) {
          score += 60;
          reasons.push('Exact title match');
        } else if (existingTitle.includes(lowerTitle) || lowerTitle.includes(existingTitle)) {
          if (title.length > 10) {
            score += 35;
            reasons.push('Similar title detected');
          }
        }

        // URL similarity check
        if (existing.video_url === videoUrl) {
          score += 80;
          reasons.push('Identical video source URL');
        }

        // Same channel duplicate URL
        if (existing.video_url === videoUrl) {
          score = Math.max(score, 95);
        }

        // Partial URL match
        if (videoUrl && existing.video_url) {
          const urlParts = videoUrl.split('/').pop()?.split('.')[0] ?? '';
          const existingUrlParts = existing.video_url.split('/').pop()?.split('.')[0] ?? '';
          if (urlParts.length > 5 && existingUrlParts.length > 5 && urlParts === existingUrlParts) {
            score += 70;
            reasons.push('Matching video file fingerprint');
          }
        }

        if (score >= 30) {
          found.push({ video: existing, score: Math.min(score, 99), reasons });
        }
      });

      found.sort((a, b) => b.score - a.score);
      setMatches(found);
      setPhase(found.length > 0 ? 'results' : 'clean');
    }

    runContentCheck();
  }, [title, videoUrl]);

  function handleProceed() {
    // Record matches in database if we have a video ID — but since we don't yet,
    // we just proceed. Matches would be recorded after video insert.
    onProceed();
  }

  const hasHighMatch = matches.some((m) => m.score >= 80);
  const hasMediumMatch = matches.some((m) => m.score >= 50 && m.score < 80);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-[#1a1a1a] rounded-2xl border border-white/10 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600/20 rounded-lg flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
            </div>
            <h3 className="text-white text-sm font-bold">Content ID Check</h3>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        <div className="p-5">
          {phase === 'scanning' && (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Loader2 className="w-6 h-6 text-blue-400 animate-spin" />
                <div>
                  <p className="text-white text-sm font-medium">Scanning your video...</p>
                  <p className="text-gray-400 text-xs mt-0.5">{scanSteps[scanStep]}</p>
                </div>
              </div>

              {/* Scan progress bar */}
              <div className="space-y-2">
                {scanSteps.map((step, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                      i < scanStep ? 'bg-green-600/20' : i === scanStep ? 'bg-blue-600/20' : 'bg-white/5'
                    }`}>
                      {i < scanStep ? (
                        <Check className="w-3 h-3 text-green-400" />
                      ) : i === scanStep ? (
                        <Loader2 className="w-3 h-3 text-blue-400 animate-spin" />
                      ) : (
                        <div className="w-1.5 h-1.5 bg-gray-600 rounded-full" />
                      )}
                    </div>
                    <span className={`text-xs ${i <= scanStep ? 'text-gray-300' : 'text-gray-600'}`}>
                      {step}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {phase === 'clean' && (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-green-600/20 rounded-full flex items-center justify-center mx-auto">
                <Check className="w-8 h-8 text-green-400" />
              </div>
              <div>
                <p className="text-white text-base font-bold">No matches found</p>
                <p className="text-gray-400 text-sm mt-1">
                  Your video passed the Content ID check. No duplicate or copyrighted content detected.
                </p>
              </div>
              <button
                onClick={handleProceed}
                className="w-full py-3 rounded-xl bg-green-600 text-white text-sm font-bold hover:bg-green-700 transition-colors"
              >
                Continue with upload
              </button>
            </div>
          )}

          {phase === 'results' && (
            <div className="space-y-4">
              <div className={`flex items-start gap-3 p-4 rounded-xl ${
                hasHighMatch ? 'bg-red-500/10 border border-red-500/30' : 'bg-amber-500/10 border border-amber-500/30'
              }`}>
                <AlertTriangle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                  hasHighMatch ? 'text-red-400' : 'text-amber-400'
                }`} />
                <div>
                  <p className={`text-sm font-medium ${
                    hasHighMatch ? 'text-red-400' : 'text-amber-400'
                  }`}>
                    {hasHighMatch ? 'High similarity detected' : 'Potential matches found'}
                  </p>
                  <p className="text-gray-400 text-xs mt-1">
                    {hasHighMatch
                      ? 'This video may be a duplicate of existing content. Review the matches below before proceeding.'
                      : 'Some similarities were found. Review carefully before uploading.'}
                  </p>
                </div>
              </div>

              {/* Match list */}
              <div className="space-y-2 max-h-[280px] overflow-y-auto scrollbar-thin">
                {matches.map((match, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/10"
                  >
                    <div className="w-16 h-10 rounded-lg overflow-hidden bg-black flex-shrink-0">
                      {match.video.thumbnail_url ? (
                        <img src={match.video.thumbnail_url} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <FileVideo className="w-4 h-4 text-gray-600" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-xs font-medium truncate">{match.video.title}</p>
                      <p className="text-gray-400 text-xs">{match.video.channel?.name}</p>
                      <div className="flex items-center gap-1 mt-1">
                        {match.reasons.map((r, j) => (
                          <span key={j} className="text-[10px] text-gray-500 bg-white/5 px-1.5 py-0.5 rounded">
                            {r}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="flex-shrink-0 text-right">
                      <div className={`text-lg font-bold ${
                        match.score >= 80 ? 'text-red-400' : match.score >= 50 ? 'text-amber-400' : 'text-yellow-400'
                      }`}>
                        {match.score.toFixed(0)}%
                      </div>
                      <div className="text-[10px] text-gray-500">match</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-1">
                <button
                  onClick={onBlock}
                  className="flex-1 py-3 rounded-xl bg-white/10 text-white text-sm font-medium hover:bg-white/20 transition-colors"
                >
                  Cancel upload
                </button>
                {!hasHighMatch ? (
                  <button
                    onClick={handleProceed}
                    className="flex-1 py-3 rounded-xl bg-amber-600 text-white text-sm font-bold hover:bg-amber-700 transition-colors"
                  >
                    Proceed anyway
                  </button>
                ) : (
                  <button
                    onClick={handleProceed}
                    className="flex-1 py-3 rounded-xl bg-red-600/80 text-white text-sm font-bold hover:bg-red-600 transition-colors"
                  >
                    Override & upload
                  </button>
                )}
              </div>
              {hasHighMatch && (
                <p className="text-gray-500 text-xs text-center">
                  Overriding will flag this video for review and may result in a copyright claim.
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
