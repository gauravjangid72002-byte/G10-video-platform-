import { Home, Compass, PlaySquare, ThumbsUp, History, Video as VideoIcon, Clock, ListVideo, Home as HomeIcon, Users, Zap, ShieldAlert, BarChart3, ShieldCheck } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';
import { useAuth } from '@/context/AuthContext';
import { supabase, CATEGORIES } from '@/lib/supabase';
import { useState, useEffect } from 'react';
import type { Channel } from '@/lib/supabase';

export function Sidebar() {
  const { navigate, sidebarOpen } = useRouter();
  const { session, channel } = useAuth();
  const [subscriptions, setSubscriptions] = useState<Channel[]>([]);

  useEffect(() => {
    if (session && channel) {
      supabase
        .from('subscriptions')
        .select('channel_id, channels!subscriptions_channel_id_fkey(*)')
        .eq('subscriber_id', channel.id)
        .then(({ data }) => {
          if (data) {
            setSubscriptions(data.map((s: any) => s.channels as Channel));
          }
        });
    }
  }, [session, channel]);

  const navItems = [
    { icon: Home, label: 'Home', action: () => navigate({ name: 'home' }) },
    { icon: Zap, label: 'Shorts', action: () => navigate({ name: 'shorts' }) },
    { icon: Compass, label: 'Explore', action: () => navigate({ name: 'home' }) },
    { icon: PlaySquare, label: 'Subscriptions', action: () => navigate({ name: 'library' }) },
    { icon: Users, label: 'Watch Party', action: () => navigate({ name: 'home' }) },
    { icon: ShieldAlert, label: 'Copyright', action: () => navigate({ name: 'copyright' }) },
    { icon: BarChart3, label: 'Dashboard', action: () => navigate({ name: 'dashboard' }) },
  ];

  const adminItems = channel?.role === 'admin' ? [
    { icon: ShieldCheck, label: 'Admin Panel', action: () => navigate({ name: 'admin' }) },
  ] : [];

  const libraryItems = [
    { icon: History, label: 'History', action: () => navigate({ name: 'library' }) },
    { icon: PlaySquare, label: 'Your videos', action: () => channel && navigate({ name: 'channel', channelId: channel.id }) },
    { icon: Clock, label: 'Watch later', action: () => navigate({ name: 'library' }) },
    { icon: ThumbsUp, label: 'Liked videos', action: () => navigate({ name: 'library' }) },
  ];

  if (!sidebarOpen) {
    return (
      <aside className="fixed left-0 top-14 bottom-0 w-[72px] bg-[#0f0f0f] z-40 overflow-y-auto py-2">
        {navItems.map((item) => (
          <button
            key={item.label}
            onClick={item.action}
            className="w-full flex flex-col items-center gap-1 py-4 px-1 hover:bg-white/10 transition-colors"
          >
            <item.icon className="w-5 h-5 text-white" />
            <span className="text-white text-[10px]">{item.label}</span>
          </button>
        ))}
        <button
          onClick={() => navigate({ name: 'library' })}
          className="w-full flex flex-col items-center gap-1 py-4 px-1 hover:bg-white/10 transition-colors"
        >
          <ListVideo className="w-5 h-5 text-white" />
          <span className="text-white text-[10px]">You</span>
        </button>
        {adminItems.map((item) => (
          <button
            key={item.label}
            onClick={item.action}
            className="w-full flex flex-col items-center gap-1 py-4 px-1 hover:bg-white/10 transition-colors"
          >
            <item.icon className="w-5 h-5 text-red-400" />
            <span className="text-red-400 text-[10px]">{item.label}</span>
          </button>
        ))}
      </aside>
    );
  }

  return (
    <aside className="fixed left-0 top-14 bottom-0 w-60 bg-[#0f0f0f] z-40 overflow-y-auto pb-8 scrollbar-thin">
      <div className="py-3 border-b border-white/10">
        {navItems.map((item) => (
          <button
            key={item.label}
            onClick={item.action}
            className="w-full flex items-center gap-5 px-6 py-2.5 hover:bg-white/10 transition-colors"
          >
            <item.icon className="w-5 h-5 text-white flex-shrink-0" />
            <span className="text-white text-sm">{item.label}</span>
          </button>
        ))}
      </div>

      {session && (
        <div className="py-3 border-b border-white/10">
          <p className="px-6 py-1 text-gray-400 text-sm font-medium">You</p>
          {libraryItems.map((item) => (
            <button
              key={item.label}
              onClick={item.action}
              className="w-full flex items-center gap-5 px-6 py-2.5 hover:bg-white/10 transition-colors"
            >
              <item.icon className="w-5 h-5 text-white flex-shrink-0" />
              <span className="text-white text-sm">{item.label}</span>
            </button>
          ))}
        </div>
      )}

      {session && adminItems.length > 0 && (
        <div className="py-3 border-b border-white/10">
          <p className="px-6 py-1 text-red-400 text-sm font-medium">Admin</p>
          {adminItems.map((item) => (
            <button
              key={item.label}
              onClick={item.action}
              className="w-full flex items-center gap-5 px-6 py-2.5 hover:bg-white/10 transition-colors"
            >
              <item.icon className="w-5 h-5 text-red-400 flex-shrink-0" />
              <span className="text-red-400 text-sm">{item.label}</span>
            </button>
          ))}
        </div>
      )}

      {session && subscriptions.length > 0 && (
        <div className="py-3 border-b border-white/10">
          <p className="px-6 py-1 text-gray-400 text-sm font-medium">Subscriptions</p>
          {subscriptions.map((sub) => (
            <button
              key={sub.id}
              onClick={() => navigate({ name: 'channel', channelId: sub.id })}
              className="w-full flex items-center gap-5 px-6 py-2.5 hover:bg-white/10 transition-colors"
            >
              <div className="w-6 h-6 rounded-full overflow-hidden flex-shrink-0 bg-white/10">
                {sub.avatar_url && (
                  <img src={sub.avatar_url} alt="" className="w-full h-full object-cover" />
                )}
              </div>
              <span className="text-white text-sm truncate">{sub.name}</span>
            </button>
          ))}
        </div>
      )}

      <div className="py-3 border-b border-white/10">
        <p className="px-6 py-1 text-gray-400 text-sm font-medium">Explore</p>
        {CATEGORIES.filter((c) => c !== 'All').map((cat) => (
          <button
            key={cat}
            onClick={() => navigate({ name: 'home' })}
            className="w-full flex items-center gap-5 px-6 py-2.5 hover:bg-white/10 transition-colors"
          >
            <HomeIcon className="w-5 h-5 text-white flex-shrink-0" />
            <span className="text-white text-sm">{cat}</span>
          </button>
        ))}
      </div>

      <div className="px-6 py-4 text-gray-500 text-xs">
        <p>About</p>
        <p className="mt-2">© 2024 G10</p>
      </div>
    </aside>
  );
}
