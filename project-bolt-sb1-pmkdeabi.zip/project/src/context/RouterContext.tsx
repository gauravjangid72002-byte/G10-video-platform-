import { createContext, useContext, useState, type ReactNode } from 'react';

type Page =
  | { name: 'home' }
  | { name: 'watch'; videoId: string }
  | { name: 'channel'; channelId: string }
  | { name: 'upload' }
  | { name: 'shorts' }
  | { name: 'search'; query: string }
  | { name: 'signin' }
  | { name: 'signup' }
  | { name: 'library' }
  | { name: 'copyright' }
  | { name: 'dashboard' }
  | { name: 'admin' }
  | { name: 'watchparty'; roomId: string };

type RouterContextType = {
  page: Page;
  navigate: (page: Page) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
};

const RouterContext = createContext<RouterContextType | undefined>(undefined);

export function RouterProvider({ children }: { children: ReactNode }) {
  const [page, setPage] = useState<Page>({ name: 'home' });
  const [sidebarOpen, setSidebarOpen] = useState(true);

  function navigate(p: Page) {
    setPage(p);
    window.scrollTo(0, 0);
  }

  return (
    <RouterContext.Provider value={{ page, navigate, sidebarOpen, setSidebarOpen }}>
      {children}
    </RouterContext.Provider>
  );
}

export function useRouter() {
  const ctx = useContext(RouterContext);
  if (!ctx) throw new Error('useRouter must be used within RouterProvider');
  return ctx;
}
