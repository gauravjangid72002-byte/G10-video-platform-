import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase, type Channel } from '@/lib/supabase';

type AuthContextType = {
  session: Session | null;
  channel: Channel | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, name: string, handle: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshChannel: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [channel, setChannel] = useState<Channel | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session) {
        loadChannel(data.session.user.id);
      } else {
        setLoading(false);
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess);
      if (sess) {
        (async () => {
          await loadChannel(sess.user.id);
        })();
      } else {
        setChannel(null);
        setLoading(false);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadChannel(userId: string) {
    const { data } = await supabase
      .from('channels')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    setChannel(data as Channel | null);
    setLoading(false);
  }

  async function refreshChannel() {
    if (session) {
      await loadChannel(session.user.id);
    }
  }

  async function signIn(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  }

  async function signUp(email: string, password: string, name: string, handle: string) {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) return { error: error.message };

    if (data.user) {
      const { error: channelError } = await supabase
        .from('channels')
        .insert({ id: data.user.id, name, handle: '@' + handle.replace(/^@/, '') });
      if (channelError) return { error: channelError.message };
    }

    return { error: null };
  }

  async function signOut() {
    await supabase.auth.signOut();
    setChannel(null);
  }

  return (
    <AuthContext.Provider value={{ session, channel, loading, signIn, signUp, signOut, refreshChannel }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
