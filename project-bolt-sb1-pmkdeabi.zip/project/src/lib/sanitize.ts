/**
 * Input sanitization utilities to protect against XSS and injection attacks.
 * These run client-side as a first line of defense; the database RLS policies
 * and SECURITY DEFINER functions enforce server-side security.
 */

/**
 * Strip HTML tags and dangerous characters from a string.
 * Removes <, >, script tags, event handlers, and javascript: URIs.
 */
export function sanitizeText(input: string): string {
  if (!input) return '';
  return input
    .replace(/<script[^>]*>.*?<\/script>/gi, '')
    .replace(/<[^>]+>/g, '')
    .replace(/javascript:/gi, '')
    .replace(/on\w+\s*=/gi, '')
    .trim();
}

/**
 * Sanitize a URL — only allow http/https protocols.
 * Rejects javascript:, data:, vbscript:, and other dangerous schemes.
 */
export function sanitizeUrl(url: string): string {
  if (!url) return '';
  const trimmed = url.trim();
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  // Allow relative URLs
  if (trimmed.startsWith('/') && !trimmed.startsWith('//')) return trimmed;
  return '';
}

/**
 * Validate and clamp a number to a safe range.
 */
export function sanitizeNumber(value: number, min: number, max: number): number {
  const n = Number(value);
  if (isNaN(n)) return min;
  return Math.max(min, Math.min(max, n));
}

/**
 * Truncate text to a maximum length to prevent oversized inputs.
 */
export function truncateText(input: string, maxLength: number): string {
  if (!input) return '';
  return input.length > maxLength ? input.slice(0, maxLength) : input;
}

/**
 * Combined sanitization for user-generated text content (comments, posts, descriptions).
 * Strips HTML, limits length, and removes dangerous patterns.
 */
export function sanitizeUserContent(input: string, maxLength: number = 2000): string {
  return truncateText(sanitizeText(input), maxLength);
}
