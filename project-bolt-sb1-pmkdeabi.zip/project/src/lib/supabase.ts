import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Channel = {
  id: string;
  name: string;
  handle: string;
  avatar_url: string | null;
  banner_url: string | null;
  bio: string;
  created_at: string;
  subscriber_count?: number;
  video_count?: number;
  strike_count?: number;
  is_restricted?: boolean;
  total_earnings?: number;
  available_balance?: number;
  lifetime_views?: number;
  watch_time_seconds?: number;
  monetization_status?: string;
  role?: string;
  is_blocked?: boolean;
  blocked_reason?: string | null;
};

export type Video = {
  id: string;
  channel_id: string;
  title: string;
  description: string;
  thumbnail_url: string | null;
  video_url: string;
  category: string;
  views: number;
  created_at: string;
  channel?: Channel;
  like_count?: number;
  comment_count?: number;
  is_ppv?: boolean;
  ppv_price?: number;
  tip_total?: number;
  is_short?: boolean;
};

export type ContentMatch = {
  id: string;
  video_id: string;
  match_video_id: string;
  match_score: number;
  status: string;
  created_at: string;
  match_video?: Video;
};

export type CopyrightClaim = {
  id: string;
  video_id: string;
  claimant_id: string;
  reason: string;
  claim_type: string;
  status: string;
  counter_text: string | null;
  counter_submitted_at: string | null;
  resolved_at: string | null;
  created_at: string;
  video?: Video;
  claimant?: Channel;
};

export type CopyrightStrike = {
  id: string;
  channel_id: string;
  claim_id: string;
  reason: string;
  status: string;
  created_at: string;
  claim?: CopyrightClaim;
};

export type WatchPartyRoom = {
  id: string;
  host_id: string;
  video_id: string;
  room_code: string;
  playback_time: number;
  is_playing: boolean;
  last_sync_at: string;
  created_at: string;
};

export type WatchPartyMessage = {
  id: string;
  room_id: string;
  sender_id: string;
  text: string;
  created_at: string;
  sender?: Channel;
};

export type Tip = {
  id: string;
  video_id: string;
  tipper_id: string;
  amount: number;
  message: string;
  created_at: string;
};

export type PPVPurchase = {
  id: string;
  video_id: string;
  buyer_id: string;
  price_paid: number;
  created_at: string;
};

export type Comment = {
  id: string;
  video_id: string;
  channel_id: string;
  text: string;
  created_at: string;
  channel?: Channel;
};

export type VideoLike = {
  id: string;
  video_id: string;
  channel_id: string;
  created_at: string;
};

export type Subscription = {
  id: string;
  subscriber_id: string;
  channel_id: string;
  created_at: string;
};

export type DailyAnalytics = {
  id: string;
  channel_id: string;
  date: string;
  total_views: number;
  total_subscribers: number;
  total_earnings: number;
  new_views: number;
  new_subscribers: number;
  new_earnings: number;
  video_count: number;
};

export type CommunityPost = {
  id: string;
  channel_id: string;
  post_type: string;
  text_content: string | null;
  image_url: string | null;
  poll_question: string | null;
  poll_options: string[] | null;
  created_at: string;
  channel?: Channel;
  voteCounts?: number[];
  totalVotes?: number;
  userVote?: number | null;
};

export const CATEGORIES = [
  'All',
  'Technology',
  'Food',
  'Gaming',
  'Travel',
  'Fitness',
  'Music',
];

export type MonetizationCriteria = {
  min_subscribers: number;
  min_watch_time_seconds: number;
};
